// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The interface of __NAME__: the shell's frame (menus, tool strip, document tabs, panels, Terminal, Messages, status
// bar, welcome screen and the Help dialogs) with no domain features yet. The domain goes in source/engine and in the
// work surface of public/center.html; documents are created and opened in createDocument() and open().
import config from "../../forge.config.json";
import type { ForgeDesktopBridge } from "forge-shell/desktop/bridge";
import { helpMenu, menuShortcutGroups, showAbout, showLicenses, showShortcuts, showWhatsNew, type InfoOptions } from "forge-shell/app/about";
import { createBottomTabs } from "forge-shell/app/bottom-tabs";
import { commandHelp, generalHelp, helpAlias, invalidUsage, type HelpCatalog } from "forge-shell/app/command-help";
import type { CommandSpec } from "forge-shell/app/command-spec";
import { applyDesktopClasses } from "forge-shell/app/desktop-classes";
import { createEmptyState } from "forge-shell/app/empty-state";
import { MessageLog, MessagesPanel } from "forge-shell/app/messages";
import { collectShortcuts, drawsMenubar, matchesKey, renderMenubar, shortcutText, titleBarColors, type MenuNode } from "forge-shell/app/menus";
import { createPanelLayout } from "forge-shell/app/panel-layout";
import { settingsStorageKey, terminalHistoryStorageKey } from "forge-shell/app/profile";
import { autosaveMenu, createRecentFiles, parseAutosave, recentMenu, type AutosaveChoice } from "forge-shell/app/saving";
import { createSettingsStore } from "forge-shell/app/settings";
import { shellPreferenceCommand } from "forge-shell/app/shell-preferences";
import { StatusBar } from "forge-shell/app/status-bar";
import { DocumentTabs, type TabDocument } from "forge-shell/app/tabs";
import { TerminalPanel, type ConsoleResult } from "forge-shell/app/terminal";
import { runSharedCommand, sharedCommands, sharedHelpDetails, sharedHelpGroups, type StandardAction } from "forge-shell/app/shared-commands";
import { standardItem, zoomItems } from "forge-shell/app/standard-items";
import { setTip } from "forge-shell/app/tips";
import { TOOL_ICONS } from "forge-shell/app/tool-icons";
import { generalPage, showSettings, terminalPage, updatesPage, visiblePages, type SettingsPage } from "forge-shell/app/settings-dialog";
import { createToolStrip } from "forge-shell/app/tool-strip";

declare const __APP_LOGO__: string;
declare const __FORGE_VERSION__: string;
declare global { interface Window { forge?: ForgeDesktopBridge } }

const desktop = window.forge ?? null;
const platform = desktop?.platform ?? (navigator.platform.includes("Mac") ? "darwin" : "browser");
const $ = (id: string) => document.getElementById(id)!;
// The GitHub repository whose releases the update check reads (`identity.repository`); without it there is no check.
const repository = (config.identity as { repository?: string }).repository;
const info: InfoOptions = { productName: config.identity.name, purpose: config.identity.purpose, logo: __APP_LOGO__.trimEnd(), version: __FORGE_VERSION__ };

// MARK: settings

interface Settings {
  appearance: "dark" | "light" | "pride";
  showInspector: boolean; inspectorSide: "left" | "right"; inspectorWidth: number;
  showBottomPanel: boolean; bottomPanelHeight: number; terminalFontSize: number;
  autosave: AutosaveChoice;
}
const DEFAULTS: Settings = { appearance: "dark", showInspector: true, inspectorSide: "right", inspectorWidth: 246, showBottomPanel: true, bottomPanelHeight: 246, terminalFontSize: 12, autosave: "off" };
const number = (value: unknown, fallback: number) => (typeof value === "number" && Number.isFinite(value) ? value : fallback);
const store = createSettingsStore<Settings>(settingsStorageKey(config), DEFAULTS, (stored) => ({
  appearance: stored.appearance === "light" || stored.appearance === "pride" ? stored.appearance : "dark",
  showInspector: stored.showInspector !== false, inspectorSide: stored.inspectorSide === "left" ? "left" : "right",
  inspectorWidth: number(stored.inspectorWidth, DEFAULTS.inspectorWidth), showBottomPanel: stored.showBottomPanel !== false,
  bottomPanelHeight: number(stored.bottomPanelHeight, DEFAULTS.bottomPanelHeight), terminalFontSize: number(stored.terminalFontSize, 12),
  autosave: parseAutosave(stored.autosave) ?? "off",
}));
const { settings } = store;
const messages = new MessageLog();
const recent = createRecentFiles(`${config.identity.id}.recent`);

// MARK: documents

// The open documents, in tab order. This frame has no document type yet: createDocument() and open() are where the
// application makes and reads them.
const documents: TabDocument[] = [];
let active: TabDocument | null = null;

function createDocument(): void {
  messages.add("info", `${config.identity.name} has no ${config.document.plural} yet: createDocument() in source/app/main.ts makes them.`);
  refreshMessages();
}
function open(): void {
  messages.add("info", `${config.identity.name} has no ${config.document.plural} yet: open() in source/app/main.ts reads them.`);
  refreshMessages();
}

// MARK: menus and actions

const nativeAppMenu = !!desktop && platform === "darwin";
function menus(): MenuNode[] {
  const hasDocument = !!active;
  return [
    { label: "File", submenu: [
      // The standard items take their label and key from the shell (`standardItem`), the same in every application.
      standardItem("file.new", { noun: config.document.noun }),
      standardItem("file.open"),
      recentMenu(recent.list()),
      { separator: true },
      standardItem("file.save", {}, { enabled: hasDocument }),
      standardItem("file.saveAs", {}, { enabled: hasDocument }),
      autosaveMenu(settings.autosave),
      { separator: true },
      standardItem("file.close", {}, { enabled: hasDocument }),
      // On macOS the native menu moves Settings… to the app menu, after About.
      { separator: true }, standardItem("app.settings"),
    ] },
    { label: "Edit", submenu: [
      // Undo and Redo act on text fields until the application has documents with their own history.
      standardItem("edit.undo", {}, { role: "undo" }), standardItem("edit.redo", {}, { role: "redo" }),
      { separator: true },
      standardItem("edit.cut"), standardItem("edit.copy"), standardItem("edit.paste"),
      { separator: true },
      standardItem("edit.selectAll"),
    ] },
    { label: "View", submenu: [
      // Zoom in, Zoom out, Fit (Cmd+0) and Actual size (Cmd+1); the work surface zooms in run().
      ...zoomItems(hasDocument),
      { separator: true },
      standardItem("view.inspector", {}, { checked: settings.showInspector }),
      standardItem("view.bottomPanel", {}, { checked: settings.showBottomPanel }),
      { separator: true },
      { label: "Appearance", submenu: (["dark", "light"] as const).map((value) => ({ id: `view.theme.${value}`, label: value === "dark" ? "Dark" : "Light", checked: settings.appearance === value })) },
      ...(desktop ? [{ separator: true }, standardItem("view.fullScreen"), { role: "toggleDevTools", label: "Developer tools" }] : []),
    ] },
    helpMenu(config.identity.name, nativeAppMenu),
  ];
}

function run(id: string): void {
  if (id === "file.new") createDocument();
  else if (id === "file.save" || id === "file.saveAs" || id === "file.close") return; // no documents yet
  else if (id === "view.zoomIn" || id === "view.zoomOut" || id === "view.fit" || id === "view.actualSize") return; // the work surface zooms here
  else if (id === "file.open") open();
  else if (id === "file.recent.clear") { recent.clear(); refreshMenus(); }
  else if (id.startsWith("file.recent.")) open();
  else if (id.startsWith("file.autosave.")) { const choice = parseAutosave(id.slice(14)); if (choice) store.updateSettings({ autosave: choice }); }
  else if (id === "view.inspector") store.updateSettings({ showInspector: !settings.showInspector });
  else if (id === "view.bottomPanel") store.updateSettings({ showBottomPanel: !settings.showBottomPanel });
  else if (id.startsWith("view.theme.")) store.updateSettings({ appearance: id.slice(11) as Settings["appearance"] });
  else if (id === "about") showAbout(info);
  else if (id === "about.whatsNew") void showWhatsNew(info);
  else if (id === "about.shortcuts") showShortcuts(info, menuShortcutGroups(menus(), (key) => shortcutText(key)));
  else if (id === "about.licenses") void showLicenses(info);
  else if (id === "app.settings") showSettings({ pages: settingsPages() });
}

// MARK: frame

applyDesktopClasses(desktop ?? undefined);
const strip = createToolStrip($("toolstrip"), run);
strip.group([strip.tool({ id: "undo", label: "Undo", icon: TOOL_ICONS.undo, shortcut: "CmdOrCtrl+Z" }), strip.tool({ id: "redo", label: "Redo", icon: TOOL_ICONS.redo, shortcut: "CmdOrCtrl+Shift+Z" })], "", "history");
strip.finish();
const status = new StatusBar($("statusbar"), () => selectBottom("messages"));
const applyLayout = createPanelLayout({ center: $("center"), inspector: $("inspector"), inspectorSplit: $("inspector-split"), bottom: $("bottom"), bottomSplit: $("bottom-split"),
  settings, defaults: { inspectorWidth: DEFAULTS.inspectorWidth, bottomPanelHeight: DEFAULTS.bottomPanelHeight }, save: (change) => store.updateSettings(change),
  afterApply: () => { document.body.dataset.theme = settings.appearance; document.body.dataset.inspectorSide = settings.inspectorSide; } });
// The Messages tab's one action, shown at the right of the tab bar only while Messages is selected; MessagesPanel runs it.
const clear = Object.assign(document.createElement("button"), { className: "tab-action messages-clear", textContent: "Clear" });
setTip(clear, "Clear the messages.");
const messagesPanel = new MessagesPanel($("messages-pane"), { subjectName: () => null, selectSubject: () => {} }, clear);
messagesPanel.setLog(messages);
const selectBottom = createBottomTabs<"terminal" | "messages">($("bottom-tabs"), [
  { name: "terminal", element: $("terminal-pane"), onSelect: () => terminal.show() },
  { name: "messages", element: $("messages-pane"), onSelect: () => { messages.markSeen(); refreshMessages(); } },
]);
$("bottom-tabs").append(clear);
function refreshMessages(): void {
  messagesPanel.refresh(true);
  status.render({ stateLabel: "Ready", stateColor: "var(--text3)", summary: "", detail: active?.name ?? "", hint: null, unseenProblems: messages.unseen, readouts: [] });
}

const documentTabs = new DocumentTabs<TabDocument>($("doc-tabs"), {
  newTitle: `${config.document.tabs.newTitle} (${shortcutText("CmdOrCtrl+N")})`, closeTitle: `${config.document.tabs.closeTitle} (${shortcutText("CmdOrCtrl+W")})`,
  onNew: createDocument, onActivate: (document) => { active = document; renderDocuments(); }, onClose: () => {},
});
// With no document open, the welcome screen takes the work surface's place and the document controls are dimmed.
const emptyState = createEmptyState($("center"), { ...config.document.welcome, newShortcut: shortcutText("CmdOrCtrl+N"), openShortcut: shortcutText("CmdOrCtrl+O"), onNew: createDocument, onOpen: open });
function renderDocuments(): void {
  documentTabs.render(documents, active);
  emptyState.hidden = documents.length > 0;
  document.body.classList.toggle("no-docs", documents.length === 0);
  refreshMenus();
}

// MARK: Terminal

// The command registry: the shell's shared commands for the actions this app has, then the app's own commands. Validation,
// help and completion come from it. The domain's commands join APP_COMMANDS and are run in execute().
const ACTIONS: StandardAction[] = ["file.new", "file.open", "file.save", "file.saveAs", "file.close", "view.zoomIn", "view.zoomOut", "view.fit", "view.actualSize", "about", "about.whatsNew", "about.shortcuts", "about.licenses", "app.settings"];
const SHARED = sharedCommands(ACTIONS, { autosave: true });
const APP_COMMANDS: CommandSpec[] = [];
const COMMANDS: CommandSpec[] = [...SHARED.map((entry) => entry.spec), ...APP_COMMANDS];
const catalog: HelpCatalog = {
  commands: COMMANDS, helpCommands: COMMANDS, details: sharedHelpDetails(SHARED), welcomeForms: {}, welcomeTopics: {}, noDocumentMessage: `Open a ${config.document.noun} first.`,
  // Commands that need a document are listed only while one is open.
  availableOnWelcome: new Set([...SHARED.filter((entry) => !entry.document).map((entry) => entry.spec.name), ...APP_COMMANDS.map((command) => command.name)]),
  groups: sharedHelpGroups(SHARED),
};

async function execute(line: string): Promise<ConsoleResult> {
  const text = helpAlias(line) ?? line.trim();
  const [command = "", ...rest] = text.split(/\s+/);
  const arg = rest.join(" ");
  const entry = COMMANDS.find((item) => item.name === command);
  if (!entry) return { lines: [`Unknown command: ${command}. Type help to list commands.`] };
  if (!entry.args.test(arg)) return invalidUsage(entry);
  if (command === "help") return arg ? commandHelp(arg, documents.length === 0, catalog) : generalHelp(documents.length === 0, catalog);
  if (command === "clear") return { clear: true };
  return runSharedCommand(command, arg, {
    run, actions: ACTIONS, hasDocument: documents.length > 0, noun: config.document.noun, productName: config.identity.name, version: info.version,
    recent: () => recent.list(), openSettings: (page) => { showSettings({ pages: settingsPages(), page }); }, settingsPages: () => visiblePages(settingsPages()).map((page) => page.id), fontSize: () => settings.terminalFontSize, setFontSize: (size) => store.updateSettings({ terminalFontSize: size }),
  }) ?? shellPreferenceCommand(command, arg, { settings, update: (change) => store.updateSettings(change), panes: ["terminal", "messages"], selectPane: selectBottom }) ?? invalidUsage(entry);
}
function complete(line: string): string[] {
  const [command = "", ...rest] = line.trimStart().split(/\s+/);
  const available = documents.length ? COMMANDS : COMMANDS.filter((item) => catalog.availableOnWelcome.has(item.name));
  if (!rest.length) return available.map((item) => item.name).filter((name) => name.startsWith(command));
  const entry = available.find((item) => item.name === command);
  return (entry?.choices ?? []).filter((choice) => choice.startsWith(rest.join(" "))).map((choice) => `${command} ${choice}`);
}
const terminal = new TerminalPanel($("terminal-pane"), __APP_LOGO__, __FORGE_VERSION__, { execute, complete }, {
  appName: config.identity.name, tagline: config.identity.purpose, historyStorageKey: terminalHistoryStorageKey(config),
  fontSize: () => settings.terminalFontSize, setFontSize: (size) => store.updateSettings({ terminalFontSize: size }), onFontSizeChange: (listener) => store.onSettingsChange(listener),
});
selectBottom("terminal");

// MARK: menus on screen, and shortcuts where no native menu takes them

const drawn = drawsMenubar(platform, !!desktop);
function refreshMenus(): void {
  if (desktop && !drawn) desktop.setMenu(menus());
  else { renderMenubar($("menubar"), menus(), run, { titleBar: !!desktop }); desktop?.setTitleBar(titleBarColors()); }
}
store.onSettingsChange(() => { applyLayout(); refreshMenus(); });
desktop?.onCommand(run);
document.addEventListener("keydown", (event) => {
  if (event.defaultPrevented || (desktop && !drawn)) return;
  const shortcut = collectShortcuts(menus()).find((item) => matchesKey(event, item.key));
  if (shortcut) { event.preventDefault(); run(shortcut.id); }
});
applyLayout();
renderDocuments();
refreshMessages();

// At launch, a newer release is offered at the top of the welcome screen (Update and restart on the desktop).
const updateStorageKey = `${config.identity.id}.updates`;
const updateOptions = { platform, install: desktop ? (asset: Parameters<NonNullable<typeof desktop>["installUpdate"]>[0]) => desktop.installUpdate(asset) : undefined,
  onProgress: desktop ? (listener: (progress: { done: number; total: number }) => void) => desktop.onUpdateProgress(listener) : undefined, storageKey: updateStorageKey };

/** Settings (Cmd+,): the shell's General, Terminal and Updates pages; the application's own pages go between them. */
function settingsPages(): SettingsPage[] {
  return [
    generalPage({ settings, update: (change) => store.updateSettings(change) }),
    terminalPage({ fontSize: () => settings.terminalFontSize, setFontSize: (size) => store.updateSettings({ terminalFontSize: size }) }),
    ...(repository ? [updatesPage({ info, repository, ...updateOptions })] : []),
  ];
}
