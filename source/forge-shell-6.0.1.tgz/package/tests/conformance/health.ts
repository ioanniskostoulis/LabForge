import assert from "node:assert/strict";
import { test } from "node:test";
import { createHealthTracker, healthCommand, healthPage, showHealthBreakReminder, type HealthTracker } from "../../source/app/health";

test("health reminder reports, sets and disables the daily active-use threshold", () => {
  let hours: number | null = 4;
  const tracker = {
    reminderAfterHours: () => hours,
    setReminderAfterHours: (value: number | null) => { hours = value; },
  } as HealthTracker;
  assert.deepEqual(healthCommand("", tracker), { lines: ["Break reminder set for after 4 hours."] });
  assert.deepEqual(healthCommand("reminder 2", tracker), { lines: ["Break reminder set for after 2 hours."] });
  assert.equal(hours, 2);
  assert.deepEqual(healthCommand("reminder off", tracker), { lines: ["Break reminders disabled."] });
  assert.equal(hours, null);
  assert.deepEqual(healthCommand("", tracker), { lines: ["Break reminders are off."] });
});

test("health reminder command refuses unsupported thresholds and extra arguments", () => {
  const tracker = { reminderAfterHours: () => 4, setReminderAfterHours() {} } as HealthTracker;
  assert.deepEqual(healthCommand("reminder 1", tracker), { lines: ["Break reminder takes off, 2, 3, 4, 5 or 6."] });
  assert.deepEqual(healthCommand("reminder 2 later", tracker), { lines: ["Usage: health reminder <off|2|3|4|5|6>."] });
  assert.deepEqual(healthCommand("other 2", tracker), { lines: ["Usage: health reminder <off|2|3|4|5|6>."] });
});

test("the Health page exposes the same supported reminder values and Terminal command", () => {
  const tracker = { reminderAfterHours: () => 4, setReminderAfterHours() {} } as HealthTracker;
  const page = healthPage(tracker);
  const reminder = page.sections[1].rows[0];
  assert.equal(reminder.kind, "select");
  if (reminder.kind !== "select") throw new Error("Health reminder must be a select row.");
  assert.equal(reminder.default, "4");
  assert.deepEqual(reminder.choices.map(([value]) => value), ["off", "2", "3", "4", "5", "6"]);
  assert.equal(reminder.command!(reminder.value()), "health reminder 4");
});

test("health reminder choice survives tracker reload", () => {
  const previous = { document: globalThis.document, window: globalThis.window, requestAnimationFrame: globalThis.requestAnimationFrame };
  const listeners = new Map<string, EventListener>();
  const documentStub = {
    visibilityState: "hidden",
    hasFocus: () => false,
    addEventListener: (name: string, listener: EventListener) => listeners.set(name, listener),
    removeEventListener: (name: string) => { listeners.delete(name); },
  } as unknown as Document;
  const windowStub = {
    setInterval: () => 1,
    clearInterval() {},
    addEventListener() {},
    removeEventListener() {},
  } as unknown as Window & typeof globalThis;
  globalThis.document = documentStub;
  globalThis.window = windowStub;
  globalThis.requestAnimationFrame = (() => 1) as typeof requestAnimationFrame;
  const values = new Map<string, string>();
  const storage = { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => { values.set(key, value); } };
  try {
    const first = createHealthTracker({ storageKey: "health", storage, now: () => 1 });
    first.setReminderAfterHours(6);
    first.dispose();
    const second = createHealthTracker({ storageKey: "health", storage, now: () => 1 });
    assert.equal(second.reminderAfterHours(), 6);
    second.dispose();
  } finally {
    globalThis.document = previous.document;
    globalThis.window = previous.window;
    globalThis.requestAnimationFrame = previous.requestAnimationFrame;
  }
});

test("taking a short break closes the reminder before requesting the host close flow", () => {
  class FakeElement {
    className = "";
    innerHTML = "";
    textContent = "";
    children: FakeElement[] = [];
    listeners = new Map<string, () => void>();
    removed = false;
    setAttribute() {}
    append(...items: FakeElement[]) { this.children.push(...items); }
    addEventListener(name: string, listener: () => void) { this.listeners.set(name, listener); }
    removeEventListener() {}
    remove() { this.removed = true; }
    focus() {}
  }
  const previous = { document: globalThis.document, HTMLElement: globalThis.HTMLElement };
  const body = new FakeElement();
  const documentStub = {
    activeElement: null,
    body,
    createElement: () => new FakeElement(),
    getElementById: () => null,
    addEventListener() {},
    removeEventListener() {},
  } as unknown as Document;
  const events: string[] = [];
  globalThis.document = documentStub;
  globalThis.HTMLElement = FakeElement as unknown as typeof HTMLElement;
  try {
    const backdrop = showHealthBreakReminder(4, () => events.push("closed"), () => events.push("take-break"));
    const dialog = backdrop.children[0];
    const actions = dialog.children[0];
    actions.children[0].listeners.get("click")!();
    assert.equal(backdrop.removed, true);
    assert.deepEqual(events, ["closed", "take-break"]);
  } finally {
    globalThis.document = previous.document;
    globalThis.HTMLElement = previous.HTMLElement;
  }
});
