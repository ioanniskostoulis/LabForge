import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");

test("settings selects stay above the modal backdrop", () => {
  assert.match(css, /\.select-popup \{[^}]*z-index: 300;/);
});

test("settings rows reflow command hints in narrow windows", () => {
  assert.match(css, /@media \(max-width: 760px\) \{[\s\S]*\.settings-main \{ grid-template-columns: 140px minmax\(0, 1fr\); \}/);
  assert.match(css, /\.settings-page \.generator-field \.settings-command \{ grid-column: 2; justify-self: start; text-align: left; \}/);
  assert.match(css, /\.settings-page \.settings-check \.settings-command \{ grid-column: 1; justify-self: start; text-align: left; \}/);
});
