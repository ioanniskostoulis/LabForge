# Forge application guidelines: shell

Part of [GUIDELINES.md](GUIDELINES.md), sections 4 and 5.

## 4. Shared shell and geometry

The desktop shell is ordered as tool strip, document-tab row (for document-based applications), central work surface, inspector, bottom panel, status bar and overlay root. The inspector and the bottom panel, with their visibility controls, belong to every Forge application, even when a document has no editable properties. The desktop menu is native; a browser edition renders the same menu definition in a menu bar of 26 px above the strip. An application without documents has no document tabs and defines its centre context in the profile. Terminal and Messages are the required bottom utilities, and an application-specific domain pane such as Scopes or Figures lies between them.

| Element | Geometry or conditional rule |
|---|---|
| Tool strip | 36 px high; on macOS desktop 42 px with 96 px of left padding for the window buttons and a drag region; in macOS full screen 12 px of left padding |
| Toolbar button | 32 × 26 px, 4 px radius; action icon 16 × 16 px with a 1.25 px visible line (Lucide, drawn on a grid widened to 26.67 units so the glyph fills 75 % of the box, stroke 2.08); domain icons are sized by the profile |
| Toolbar separator | 1 × 20 px hairline, 6 px side margins (8 px on macOS desktop) |
| Document-tab row (when used) | 30 px high, 6 px left padding, horizontal scroll with a hidden scrollbar |
| Document tab (when used) | Width 90 to 220 px, 12 px left and 6 px right padding, 6 px gap; close control 18 × 18 px; active top accent line 2 px high, flush with the tab face between its borders; dirty dot 6 px |
| Bottom tab row | 26 px high, 12 px horizontal padding per tab, active bottom accent line 2 px |
| Bottom panel | Default and minimum 246 px high, maximum 640 px; a short window shrinks a taller panel to leave 140 px of central workspace, but never below 246 px |
| Inspector | Default and minimum 246 px wide, maximum 420 px, on the right |
| Splitter | 1 px visible, pointer hit area extended by 4 px on each side; a double click restores the recorded default |
| Scrollbars | Thin 8 px scrollbars with a transparent track and a rounded neutral thumb blended from `--panel` and `--text` (60 % and 40 %), so pane separators do not show through. The thumb has a soft shadow and no visible outline. Hover and drag brighten it without changing its width; the colour transition takes 120 ms. macOS may still control whether overlay scrollbars auto-hide. |
| Closing by dragging | The inspector and the bottom panel never become smaller than their default size: a drag below it holds them at that size, and they close when the drag takes them more than 96 px beyond it (`dragOutcome`, `CLOSE_PAST`). The panel hides with the normal 150 ms transition as soon as the pointer passes that point and reappears if the pointer returns before release. Release while closed saves the panel as hidden (the View menu item is unchecked), and the panel reopens at its last size from View, its shortcut or Terminal. A drag back inside the range never changes the saved size beyond its limits. |
| Inspector section | 12 px padding, 10 px gap, 1 px bottom border; the heading is a button with a chevron and keyboard focus |
| Property field | Label and a 108 px value column, 8 px gap, input or closed select 22 px high |
| Panel button | 24 px high, 4 px radius; the foreground and background states are given in section 6 |
| Status bar | 24 px high, 12 px horizontal padding, 14 px gap, 11 px mono text |
| Narrow window | The centre column clips its contents to its own bounds instead of drawing them under the inspector (`#center { overflow: hidden }`). The shared code editor takes its pane's width, never its longest line's, so long lines scroll inside it. Its find bar keeps the search field at least 120 px wide; in an editor narrower than 480 px it spans the editor less 8 px each side, and below 360 px it has two rows, the field and Close above, the options, count and arrows below. A Terminal wordmark wider than the pane scrolls on its own, and the transcript stays in place. The welcome actions wrap and are centred, with 16 px of side padding. The bottom tabs scroll sideways without a visible scrollbar, as the document tabs do, and keep their size (`flex: none`). The mode label of the tool strip is hidden below a window width of 1200 px. |

### Inspector philosophy

The inspector is for the thing being worked on. It is not a place for settings or commands.

The inspector is grouped by subject. Each section is about one part of the work, and everything that concerns that part sits in it, in the order a person uses it. The grouping of the earlier layouts is the model: a build section with its own action and settings, a files section, a simulation section that holds the run controls with its speed and display settings, a circuit section for the model, a tolerance section for the seed, and a read-only section for the part under the pointer.

| Rule | Specification |
|---|---|
| Grouped by subject | A section names the thing it is about (Builder, Files, Simulation, Circuit, Tolerance, Part under pointer, or the application's own noun such as Image or Steps). Its contents are the settings and readouts of that thing, and nothing from another subject. |
| Actions first | A section's own actions are its first row: a button group of one to three text buttons (or, for run controls, the standard icons) across the full content width, one of them primary when it is the main action. A section with no action has none. |
| Settings in their section | A setting belongs to the section of the subject it changes, not to a section of its own. Toggles that change the subject (such as Bibliography or Preview PDF) sit at the foot of the section they affect, as checkbox rows with the 10 px gap between rows. |
| Readouts | Read-only values (Name, Time, Parts, counts, measured values) sit in the section of their subject, above the settings. |
| Order | Sections follow the order in which the work is done: the one that builds or runs comes first, then the files, then the model, then the detail. A section that is only information, such as the part under the pointer, comes last. |
| Applies or absent | A section that does not apply to the selection or document is left out, not greyed out. |
| No pages | The inspector has no page switch, chips or tabs. All sections are one list, in the order above. |
| Folds | Every section keeps its heading and fold. The profile records the initial folds (section 4, Inspector headings). |
| Icons | Text only, unless the action has a standard symbol in the shell's icon list. |
| Decision test | A control belongs to one place: it changes the selection or document (inspector); it changes the app for every document (Settings); it is a one-shot action (menus or toolbar); or it is a command someone could type (Terminal). |

The earlier rule of a `General` first section with two or three document actions (section 4, `fillGeneralSection`) is superseded by this grouping. An application names its sections for their subject and does not add a General section.

### Inspector rows, buttons and options

The inspector geometry of the shell applies in every Forge application. At the default inspector width of 246 px a section has 12 px of padding on each side and therefore 222 px of content width. Its contents form a vertical flex column with a gap of 10 px, and sections have a 1 px `--separator` bottom border. The dimensions are unchanged by content, selection, theme or window size, and a field or button is not sized by its label: long labels wrap in the label column while the control keeps its fixed width and height.

| Item | Layout and size | Text, colour and interaction |
|---|---|---|
| Section heading | Full section width including the 12 px side padding; heading button with 12 px padding and a 5 px icon–text gap; chevron 10 × 10 px, 1.4 px stroke, left margin −2 px | 10 px, weight 600, 0.6 px tracking, uppercase by CSS, `--text2`. Hover and focus brighten the title to `--text-strong` and the chevron to `--accent-light` without filling the heading. An expanded chevron points down and a collapsed one points right. |
| Read-only label and value row | Flex row, `justify-content: space-between`, minimum gap 8 px, full content width (`createRow`) | Label 12 px UI `--text2`; value 12 px UI `--text`, right-aligned by layout and truncated with an ellipsis on one line. Used for Name, Time, counts and measured values; the detail of a value (its window, its method) is the row's tooltip and not a second line. Values are never set in a card or tile inside the inspector. |
| Item under the pointer | A section of its own whose lines describe the item under the pointer or selected (`createInfoLines`): the name first in weight-600 11 px UI `--text`, then one value per line in 11 px mono `--text2`, 3 px apart and selectable; with no item, one quiet sentence such as `Hover or click a part.` The section title may name the state (`Part under pointer`, `Selected part`). | The lines follow hover and selection; nothing in them is editable. |
| Editable text and select row | Grid `minmax(0,1fr) 108px`, column gap 8 px, vertically centred; at 246 px the label column is 106 px and the control 108 px | Label 12 px UI `--text2`, wrapping; text input 11.5 px mono; select 12 px UI. The case and units of options are preserved. A select is not widened for a long choice and the control of another row is not shortened. |
| Text input and select control | Exactly 108 × 22 px in the standard row, `box-sizing: border-box`, 4 px radius, 1 px `--separator` border, 6 px horizontal padding | `--well` fill, `--text` value. Focus uses an `--accent` border and a 1 px ring. The selected label stays within the control width. `createSelectControl` draws the choices in the shell's menu popup: the same surface, row spacing, hover, keyboard focus and viewport clamping as other menus. The selected option uses `--accent-fill` without a check mark. Up and Down move among choices; Home and End move to the first and last; Enter or Space chooses; Escape closes and returns focus. A select never opens an operating-system option menu. |
| Checkbox row | Grid `auto minmax(0,1fr)`, checkbox and label in one row with an 8 px gap. The box stays 13 × 13 px in both states. In Dark it uses a 3 px radius, `--control` fill and `--text3` border unchecked; checked, it has a 1 px `--accent-fill` border and background, with a centred white check of 11 × 11 px | Label 12 px UI `--text2`. Light uses the native checkbox with the shared accent. Focus remains visible; a disabled box uses `--text3` and does not toggle. |
| Button group | Flex row across the full content width, 6 px gap; every button has `flex: 1` and a height of exactly 24 px, radius 4 px. Two or three buttons share the width equally; a single button fills it. | 12 px UI, weight 500, centred label. A button shows text only, unless its action has a standard symbol in the shell's icon list (play, pause, step, reset, stop and the like); then the icon sits before the label with a 5 px gap. An action without a standard symbol, such as Measurements, is text only. Ordinary fill `--control` with `--text`; primary fill `--accent-fill` with `--accent-foreground`. Hover, focus and disabled states follow section 6. Built with `createButtonGroup` and `createButton`. The first section of an inspector holds the main actions of the document in one such group. |
| Slider row | Vertical stack with a 5 px gap between readout and track. The readout is a flex row with the label on the left and an 11 px mono value on the right. The slider area is 16 px high; track and fill start 6 px from the top and are 4 px high; the normal thumb is 8 × 14 px, 1 px from the top. | Track `--well`, fill `--accent`, thumb `--text`; when disabled, fill and thumb are `--text3`. The Light thumb is 10 px wide, white, with a 1 px `#929292` border. |
| Range slider row (`rangeSliderRow`) | The slider row with two thumbs on one track and both ends on the readout line (`20 – 80`), each end editable in place. Without wrap an end stops at the other; with `wrap` (a circular range such as hue) the low end may lie above the high end, and the fill covers both spans to the ends of the track. The step defaults to the power of ten below 1/100 of the span (`rangeStep`). | Colours as the slider row. A drag, a key step, a typed end and a double-click reset are each one undo step; the reset returns to the full range unless the application gives another. Each thumb is a `slider` for assistive technology and takes the arrow keys (one step), Page Up and Page Down (ten steps), Home and End. The tip of an end is `Enter the low end, from 0 to 255.` |
| Colour picker (`createColourPicker`) | A hue ring (220 px, the content width less 1 px each side; 18 px wide) around a triangle whose corners, 5 px inside the ring, are the hue, white and black; a point in the triangle sets saturation and brightness. Below it a 12 px swatch bar, 98 % of the content width and centred, of the chosen colour (and of the target, when there is one), then a row per model: Hex, RGB, HSB and Lab (CIELAB, D65), the label 12 px UI `--text2` and the value 11 px mono `--text`, as the slider readout. | The marks are white with a dark edge (`--picker-mark`, `--picker-mark-edge`); the area around the samples is `--accent` at 25 %. The tolerance ring around the target is dashed, its radius a share of the triangle's side. Each model's value is typed in place (`COLOUR_MODEL_TIPS`); a grey keeps the hue it had. A drag is one undo step through `onCommit`; the arrow keys move saturation and brightness by 1 %, Page Up and Page Down the hue by 5°. |

Adjacent field rows share the same right edge and the same 108 px control width. All inspector buttons are 24 px high, including a full-width action such as `Recommend settings…` or `New seed`; ordinary fields and buttons receive no width or height overrides per application, and a multiline textarea occupies its own full-width row. The unit of a row belongs to its displayed or editable value (`25 °C`, `5 µs`, `0.1%`) and not to a second, misaligned label. A choice list uses the domain terms of the application, while its closed control, typography, selection and spacing follow this rule. On the empty screen the inspector geometry is unchanged: its children receive `opacity: 0.35` and `pointer-events: none`, and no row is collapsed, removed or resized.

### Persistence and the empty screen

Appearance, pane visibility, pane sizes and the inspector side are saved as application preferences. Document data and any view settings that must reopen with it are saved in the document. Message logs, command history, pointer location and the state of running animations are transient and are not stored in the document. Section 10 (Remembered settings) lists each remembered value and how it is stored. A visible document tab shows a dirty mark until the save succeeds. Closing unsaved work offers save, discard and cancel, and a failed or cancelled save keeps the window open.

When no document or project is open, the centre shows the New and Open actions of the application.

| Element | Specification |
|---|---|
| Heading | 15 px semibold, `--text2` |
| Supporting text | 11 px, `--text3` |
| Spacing | 8 px between action buttons, 14 px vertical gap between welcome elements |
| Surface | `--empty-sheet` with a dotted grid of 16 px in `--empty-grid-dot` and a major grid of 128 px in `--empty-grid-line` (section 2). The geometry is set once, by tokens on `body` that every appearance shares: a dot and a major line meet `--empty-grid-origin` (40 px) from the top left corner, then every `--empty-grid-dot-step` (16 px) and `--empty-grid-line-step` (128 px), with dots of `--empty-grid-dot-radius` (1.1 px) and lines of `--empty-grid-line-width` (1 px). The CSS of `#empty-state` holds no length of its own: its dot tile starts half a step before the origin (40 − 16 / 2 = 32 px). A canvas that draws the same sheet reads the colours and the geometry from the same tokens (`sheetGrid()`) and draws them with `drawSheetGrid(ctx, width, height, grid, view)`: at the default view it is the welcome screen pixel for pixel; with a `Viewport` the grid follows the content and its steps scale, dots and lines keep their size on screen, and a family under 4 px apart is left out. The tests `the welcome surface takes its sheet and grid from the theme tokens, not from colours of its own`, `the welcome grid's geometry is the tokens', set once for every appearance, and the CSS has no length of its own` and `at the default view the canvas sheet is the welcome screen: lines from 40 px every 128 px, dots on 40 px every 16 px` enforce it. |
| Inspector, tool-strip contents, bottom tabs other than Terminal | Visible, with `opacity: 0.35` and `pointer-events: none`; the Terminal tab and the application-level Terminal commands remain available |
| Status bar | Contents hidden with `visibility: hidden`; the height is retained |
| Menus | Document-only actions are present and disabled |

A domain that requires a different empty surface records it in the profile. Normal opacity, pointer behaviour and status contents are restored when a document opens. An application without documents defines its equivalent inactive context in the profile. When an application keeps several files within one project, the profile states whether the top tabs represent projects or internal files; one tab row never serves both without a distinct label and close and save rule.


### Code editor

An application that edits code or text uses the shared editor (`createCodeEditor`, or `codeEditorSetup` in its own CodeMirror view) and its find bar (`createFindBar`, `FindController`). CodeMirror is an optional peer dependency of the shell: an application that does not use the editor never loads it.

| Part | Rule |
|---|---|
| Base | Line numbers, the active line (`--text` at 5 %, 4 px radius), history, bracket matching (`--text` at 14 % with an outline; an unmatched bracket outlined in `--error`), indentation on input, Tab to indent, 13 px mono (`--editor-size`) at a line height of 1.5, on `--well` |
| Caret | 1.5 px in `--accent-light`. It blinks at CodeMirror's 1.2 s rate with an eased fade instead of on and off, stays solid while typing, and glides 80 ms to its next position. Under reduced motion it blinks on and off and jumps. |
| Selection | One rounded shape in `--selection` (`roundedSelection`), with the shell's selection geometry; a selected empty line shows a 6 px stub. |
| Find bar | At the top right of the editor: the query, the match-case, whole-word and pattern toggles, `n of m` (or `No results`, `Invalid pattern`), previous, next and close, and a replace row opened by its chevron with Replace (Return) and Replace all (Cmd or Ctrl+Return). Matches are the accent at 22 %, the current one at 45 %. Esc closes it. Typing in the query selects the first match at or after the start of the selection, so the match already selected stays selected as the query grows (`matchFrom`); Return and the arrows move to the next or previous one. |
| Syntax | The tokens of "Syntax colours"; brackets may be coloured by depth (`cm-bracket-1` to `3`) or dimmed by depth (`cm-bracket-dim-1` to `6`). |

The tests `every syntax kind has highlighting tags, no tag has two colours, and each tag gets its kind's class`, `a query typed in the find bar keeps the match under the selection as it grows, and wraps` and `the find bar counts the matches of its query and which one is selected` check the editor.

### Syntax colours

The shared code editor (`code-editor.ts`) colours code with these tokens, through the classes `syntax-<kind>` that `shellHighlightStyle` gives the Lezer highlighting tags (`SYNTAX_TAGS`). Each colour has at least 4.5:1 contrast on `--well`, the editor background, in its appearance.

| Token | Dark | Light | Use |
|---|---|---|---|
| `--syntax-keyword` | `#f97583` | `#c62a3c` | Keywords and literal words (`if`, `true`, `null`) |
| `--syntax-name` | `#79b8ff` | `#005cc5` | Function, class, macro and command names |
| `--syntax-string` | `#9ecbff` | `#032f62` | Strings, characters, regular expressions and escapes |
| `--syntax-number` | `#ffab70` | `#b35000` | Numbers, units and constants |
| `--syntax-comment` | `#8b949e` | `#6a737d` | Comments and meta lines |
| `--syntax-type` | `#b392f0` | `#6f42c1` | Types, namespaces, attributes and annotations |
| `--syntax-operator` | `#c9c9c9` | `#444d56` | Operators, punctuation and separators |
| `--syntax-heading` | `#e1e4e8` | `#24292e` | Headings and strong text (bold) |
| `--syntax-link` | `#79b8ff` | `#005cc5` | Links and URLs (underlined) |
| `--syntax-invalid` | `#ff7b72` | `#b31d28` | Invalid code |
| `--syntax-bracket-1` | `#e5c07b` | `#8a5a00` | Brackets at depth 1, 4, 7 … |
| `--syntax-bracket-2` | `#c678dd` | `#a626a4` | Brackets at depth 2, 5, 8 … |
| `--syntax-bracket-3` | `#56b6c2` | `#0b7380` | Brackets at depth 3, 6, 9 … |
| `--syntax-bracket-dim` | `#f3e9a8` | `#7a6a10` | Dimmed brackets, fading with depth (opacity 1 to 0.42) |

### Selecting and rearranging content

Content (parts on a canvas, points of a plot, scopes, rows, tabs) is selected and rearranged the same way in every application (`content-selection.ts`, `reorder.ts`, `viewport.ts`).

| Part | Rule |
|---|---|
| Colour | Selected and hovered content, its handles and the selection box use `--pick` (cyan), never the accent, which marks the interface's own selection (menus, tabs, tree rows). |
| Click and drag | A pointer that moves 5 px or more from where it went down starts a drag (`DRAG_THRESHOLD`, `dragStarted`); less is a click. |
| Selection box | A drag on empty space draws a box: `--pick` at 12 % fill with a 1 px outline dashed 4 and 3 px at any zoom (`SELECTION_BOX`, `drawSelectionBox`). It takes the items wholly inside it (`boxHits`; `touch` takes those it touches, for an application that needs it). |
| Modifiers | Shift adds to the selection, Cmd on macOS or Ctrl on Windows toggles, and a plain click or box replaces it (`selectionMode`, `nextSelection`). Esc clears the selection. |
| Rearranging | A dragged item stays in place; a 2 px line in `--accent-light` shows where it lands (`attachReorder`), the list scrolls within 24 px of its ends, a drop that would not move it shows no line, and Esc cancels. In a row or column the item lands before the item whose middle the pointer has not passed (`dropIndex`); on a grid of panels it lands on the side of the target within 20 % of its width (at most 40 px), otherwise above or below its middle (`dropEdge`). Document tabs rearrange this way when the application gives `onReorder`. |
| Pan and zoom | A canvas maps content to the view with `Viewport`: zoom keeps the point under the pointer still, between 0.05× and 12×, and Fit centres the selection, or all the content when nothing is selected (`fitBounds`), without magnifying beyond 2.5×; Cmd+0 and Space tapped twice both fit. |
| Wheel | `wheelIntent` reads a wheel event: a trackpad's two-finger scroll pans and its pinch zooms by `exp(−deltaY × 0.03)`, three times the fingers' own scale (a Ctrl + scroll step in pixels under 50 px is a pinch, though Chromium gives it the ±120 legacy delta of a mouse notch); a mouse wheel zooms 1.15× per notch at the pointer, at most 6 notches an event, and Cmd or Ctrl with a mouse wheel zooms by the same notch (a notch of 100 px would otherwise zoom 2.7×); Shift with the wheel pans sideways. The tests `Ctrl or Cmd with a mouse wheel zooms one notch at a time, as the plain wheel does` and `a pinch zooms by its distance, in small steps` enforce it. |

The tests `a selection box takes the items wholly inside it, or those it touches, whichever way it was dragged`, `Shift adds to the selection, Cmd or Ctrl toggles, and a plain click or box replaces it`, `a drag starts after 5 px, and a drop lands on the side within 20 % (at most 40 px) or above and below the middle`, `a dragged item lands before the item whose middle it has not passed, and moving keeps the others in order` and `the viewport zooms about the pointer within its limits and fits a rectangle without over-magnifying` enforce the rules.

### Panes, dialogs and form blocks

The pieces an application builds around its work come from the shell, so that they look and behave the same in every application.

| Piece | Rule |
|---|---|
| Splitter | Two panes side by side or one above the other (`createSplitter`): a 1 px `--separator` line with a 9 px pointer target, each pane at least 160 px (`splitShare`), a double click restores the default share, and the focused divider moves 2 % per arrow key. A drag ends when the pointer is released, cancelled or loses its capture, and then saves the share once. |
| View header | The header of a view beside the main work (`createViewHeader`): 28 px on `--raised`, the unsaved dot of the document tabs, the title, the view's icon actions and the close control at the right. It carries no editable or read-only icon: a file's status is shown in the file tree only. |
| Review and apply | Proposed changes before they are applied (`askToApply`): what was found, a table of each change (current and proposed, the proposed value in `--accent-light`, unchanged rows in `--text3`), Apply (Return) and Cancel (Esc) in the platform's order. |
| Choice | A question with two or more answers, as Finder's Replace, Keep both or Cancel (`askToChoose`): a title sentence, the detail in sentences, and the answers in the platform's order (`dialogButtonOrder`). Exactly one answer is Cancel, which Escape chooses; at most one is primary, which Return chooses (a focused button presses itself); an answer may have a Cmd or Ctrl letter, as ⌘D for Don't save (`choiceProblems` rejects anything else). It is drawn in the page, so it works the same in the browser preview; an application never uses a native message box. |
| Settings | One dialog for the application's settings (`showSettings({ pages })`, `app.settings`, Cmd+,, and `settings [page]` in the Terminal), in the frame of the Help dialogs: titled SETTINGS in capitals in `--text` on a slim `--raised` band, with **Restore defaults** (the page shown; enabled while a row is not at its default) at the bottom left and Close at the bottom right. Below the title, the sidebar of pages on `--raised` (each with the shell's 16 px icon, `UI_ICONS`, the chosen one `--accent-fill`) and the page on `--panel`, laid out as the options of the Plots and Tables panes: uppercase group titles, a 132 px label and a 22 px control on each select row, and read-only values in the monospace face. A visible label or heading beginning with a capital T receives a 1 px optical left shift, which aligns its apparent stem with D and E. Checkbox rows start at the group edge, with the checkbox and label 8 px apart, so an empty label column never indents a list of options. Every changing row is a `select` or `check` `SettingRow` and supplies its `command`; the application registers that command in its Terminal. The command sits in a 12 to 18-character, right-aligned `--text3` mono column after a 12 px gap (`theme dark`, `inspector right`, `font 12`); longer commands wrap at a meaningful character instead of being cut off. An `element` row contains display-only material such as a chart and cannot contain settings controls. A compact first group may set `heading: false`; otherwise the first untitled group takes the page title. Every row takes effect at once, without Apply. The shell gives General (`generalPage`), Terminal (`terminalPage`) and Updates (`updatesPage`); an application adds its own pages as data (`SettingsPage`, a row's `command` and `default`), and a page without rows is left out. Up and Down move between pages, Tab stays inside, Escape or Close closes it. Every application has it, with at least General, Terminal and (with a repository) Updates; `check-app` refuses one without it (`settingsProblems`). |
| Health and activity | When an application opts in with `createHealthTracker({ storageKey })`, `healthPage(tracker)` records active foreground use locally, while the window is visible, focused and recently used. The Activity heatmap keeps up to 400 days, names the months beneath every Daily, Weekly and Cumulative view, and labels the current total as `Active today`. Collection has no on-off control. The standard `Break reminder` select is on by default at 4 hours and offers Off or a 2 to 6 hour threshold. `healthCommand(arg, tracker)` runs the matching `health reminder <off|2|3|4|5|6>` Terminal command. When that threshold is crossed, the shell shows a non-blocking dialog with an accent-coloured plant mark at the left, title and copy beside it, and its actions below, once per local day. `createHealthTracker({ onTakeBreak })` calls the optional host callback after `Take a short break` closes the dialog; a desktop application passes its normal close request so unsaved work uses the standard Save, Discard or Cancel flow. Without the callback, the browser dialog only dismisses. Usage data remains in that application's local storage. |
| Progress bar | Any long task shows the setup's own line (`createProgressBar`): `[=========|          ]  42%  Downloading 21.4 MB of 45.8 MB` in the monospace face, 30 places, the filled part in `--accent-light`, its end turning `| / - \` every 110 ms (`>` under reduced motion), the label in `--text2`, which goes under the bar where the line is too narrow. It is a `progressbar` with its value for assistive technology. |
| Generator pane | A bottom-panel pane beside the Terminal that makes something from a few options (`GeneratorPane`, from `forge-shell/app/generator-pane`). The options sit on `--panel` at the left, a third to a half of the pane and never under 280 px (`fitOptions`), in titled groups of a 76 px label and a 22 px control, on-off options as checkboxes side by side; a problem in them is one sentence under them. The Code tile (the shared editor, its line count and Save) and the Preview tile (its zoom, `Building…` in `--accent-light` or `Failed` in `--error`, and Fit) share the rest, each at least 220 px (`fitCode`), with 32 px headers. Both splitters move by drag or 16 px per arrow key and restore the default on a double click; the shares are the application's preferences. While there is nothing to read (`idle`), every group but the first greys out and both tiles say why. The application gives the options as data (`GeneratorGroup`), writes the code from them and builds the preview: an image, a table or its own element (`PreviewContent`), shown by `PreviewStage`, which cannot be moved away from what it shows (smaller content stays inside the tile, larger content keeps covering it, 16 px margin; `keepInView`) and draws its 1 px `--accent-light` focus ring above the content. Each document keeps its own options, code and undo history for the session. |
| Table picker | A searchable table to pick from (`askToPick`): the search field filters as it is typed, keeping the rows that contain every word (`filterRows`); Up and Down move, a click or Return picks one row, or ticks rows with `multiple`, and the action and Cancel follow the platform's order. |
| Form blocks | A checkbox row (`createCheckRow`), chips for one of a few choices, drawn as a button group (24 px, radius 4 px, sharing the width; the chosen chip in `--accent-fill` with `--accent-foreground`, the others `--control` with `--text`), with the arrow keys moving between them (`createChips`), a tile for a content region beside the work (`createTile`, see Tiles; not for values in the inspector), a group heading (`createGroupHeading`) and a problem line under a field in `--error` (`setProblem`). |
| Outline | A document's structure (`renderOutline`): numbered by level (`outlineNumbers`: `1`, `1.1`, `1.2`, `2`), indented 12 px per level, the current entry in `--accent-fill`. |
| Text styles | `.link-button`, a link that runs an action, in `--accent-light` and underlined; `.hint-text`, quiet supporting text in `--text3` at 11 px. |

The tests `a divider keeps each pane at least 160 px, and an area too small for both splits in half`, `an outline is numbered by level, and a deeper level restarts when a shallower one advances` and `a table picker keeps the rows that contain every word typed, ignoring case` enforce the rules. The tests `a generator pane's options take a third to a half of it, never under 280 px, and the tiles share the rest`, `a preview is built once typing pauses, from the newest code, and a build overtaken by newer code is dropped`, `a plot or image fits whole and centred, a table fits its width from the top, and neither is blown up` and `the Terminal opens a generator pane, and reads and sets its options in the query, change and already forms` enforce the generator pane.

### Saving

Saving works the same in every application (`saving.ts`).

| Part | Rule |
|---|---|
| Writing | `saveDocument` asks for the path first and makes the text after it (`serialize(document, path)`, `path` null for a browser download), once per place written, so that a document that stores paths relative to itself is written once and correctly. A cancelled dialog writes nothing and reports nothing; a format the document cannot be saved in is reported after the path is chosen, and nothing is written. A path chosen without the extension is offered once more in the dialog, corrected, so that the system asks before replacing a file of that name; a second answer without it writes nothing and reports `Couldn't save: the name must end in .<extension>.` |
| Autosave | A preference with four choices (`AUTOSAVE_CHOICES`): **Off**, the default; **After 1 minute** and **After 5 minutes**, which save a document that long after its last edit, the pause restarting at each edit (a pause still running when autosave is turned off saves nothing); and **When the window loses focus**. File › Autosave lists them with the current one checked (`autosaveMenu`), and the shared Terminal verb `autosave [off\|1m\|5m\|focus]` reads or sets it (`shellPreferenceCommand`, when the settings have `autosave`; it answers `Autosave is off.`, `Autosave set to after 1 minute.` or `Autosave takes off, 1m, 5m or focus.`). An untitled document is never autosaved: it has no file yet, and recovery keeps it instead (`createAutosave`). |
| Recovery | While a document has unsaved edits its text is kept as a draft in the application's storage, and cleared when it is saved or its changes are discarded (`createRecovery`). After a crash the next launch offers the drafts, all ticked: **Restore** reopens the ticked ones and **Cancel** keeps them for the next launch (`askToRecover`). Drafts older than seven days are dropped. |
| Export | `exportFiles(host, items)`: one file goes through the export dialog, which offers the application's formats and opens on the item's own (`exportDialog`); several go into a folder chosen in the folder dialog (`exportFolder`). In that folder a taken name is asked about (Replace, Keep both as the primary answer, or Cancel), written under a free name (`name-1.png`, `freeName`), or replaced after a confirmation, as the application's overwrite choice says (`OVERWRITE_CHOICES`: Ask, New name, Replace; `planExport`). The desktop writes bytes only to a path or folder an export dialog of the same window approved (`registerExportIpc`); a write into a folder that was not confirmed as a replacement is exclusive, so a file is never replaced by surprise; a project file and an original are refused whatever was approved (`exportProblem`). The browser preview downloads the files. |
| Open recent | File › Open recent lists the last ten files opened or saved, newest first and without duplicates (`addRecent`, `createRecentFiles`); where two files share a name, the folder follows it (`notes.txt — lab`, `recentLabels`); a separator and **Clear menu** end the list, and an empty list shows `No recent files` (`recentMenu`). On the desktop each file is also added to the system's recent documents (`addRecentDocument`). |

The tests `the text is made once, after the dialog, for the path it is written to`, `a Save dialog answered twice without the extension writes nothing`, `a pause still running when autosave is turned off saves nothing`, `cancelled dialog and unsupported format keep a document unsaved, and nothing is written`, `autosave is off by default, or saves 1 or 5 minutes after the last edit, or when the window loses focus`, `autosave restarts its pause at each edit, never saves an untitled document, and saves on blur only when asked`, `recovery keeps one draft per document, clears it on save, drops drafts older than 7 days and lists the newest first` and `Open recent keeps ten files, newest first, without duplicates, named with their folder where names repeat` enforce the rules.

### Order and placement

Things every application shows are ordered and placed the same way (`layout-order.ts`).

| Element | Rule |
|---|---|
| Tool strip groups | Left to right: history (Undo, Redo), clipboard, view (zoom, fit), the application's tools, search at the right (`TOOL_GROUP_ORDER`). `strip.group(items, className, kind)` places a group by its kind, whatever order the application adds it in, and a separator follows each group. |
| Dialog buttons | In the platform's order (`dialogButtonOrder`, `dialogActions`). macOS: the destructive choice (Don't save) at the left, a gap, then Cancel and the primary action at the right. Windows: right-aligned, the primary action first, then the destructive choice and Cancel last. Return chooses the primary action and Esc chooses Cancel on both. |
| Close controls | A close control (×) is always at the top right of what it closes: a document tab's at its right end, shown on hover and on the active tab; a panel's, a popover's, a side view's and a banner's at the top right. It is never at the left on either platform. |

The tests `tool strip groups take the shared order whatever order an application adds them in` and `dialog buttons follow the platform: macOS ends with Cancel and the primary action, Windows starts with it` enforce the order.

## 5. Motion

Motion is limited to state changes in chrome. The initial layout appears without an entrance animation. Under `prefers-reduced-motion: reduce` the final state is applied immediately and the focus and visibility behaviour is preserved. A repeated action cancels or replaces the running animation.

| Transition | Duration | Easing | Property |
|---|---:|---|---|
| Document tab added or removed (when used) | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Width, side padding, border width and opacity |
| Active document accent line | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Transform and width; fractional tab bounds are measured and only the tab borders are excluded throughout the motion |
| Dirty dot | 150 ms | `ease-out` | Background colour |
| Active bottom-tab line | 150 ms | `ease` | Transform and width |
| Inspector section chevron | 150 ms | `ease` | Rotation from 0° (closed) to 90° (open) |
| Inspector section height | 150 ms | `cubic-bezier(0.2, 0, 0, 1)` | Height after a heading click |
| Inspector and bottom panel show and hide | 150 ms | CSS `ease` | Width or height and opacity; a closed pane becomes hidden and inert |

Decorative looping animation of the chrome is not used. Data animation, such as a simulation trace or a progress indicator, belongs to the profile and has a pause or off rule where the user can control it.

