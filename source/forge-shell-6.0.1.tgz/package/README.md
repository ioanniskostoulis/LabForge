# Forge shell

The shell is the shared interface package of the Forge desktop applications and the single source of truth for their appearance. Applications differ only in their characteristic colour. The package contains no circuit or simulation code; each application supplies its domain objects through small interfaces.

The package is source-only. An application bundles its TypeScript with its own code and pins an exact release archive (`forge-shell-<version>.tgz`). A local file dependency serves during development.

## Command

| Command | Purpose |
|---|---|
| `forge-shell check-app` | Checks a built application against its profile, the installed package and the style rules |
| `forge-shell package-config` | Writes the Electron Builder configuration |
| `forge-shell dmg-background` | Draws the macOS disk image window |
| `forge-shell new-app` | Creates a complete empty application from a name, a file extension and one accent colour |
| `forge-shell wordmark` | Writes the text wordmark of an application in the family lettering |
| `forge-shell brand-css` | Generates the checked accent stylesheet |
| `forge-shell installer` | Stages the Windows setup around an unpacked desktop build |
| `forge-shell licenses` | Prints the licence text of every production dependency |
| `forge-shell workflows` | Writes the four build workflows of an application into `.github/workflows/` |
| `forge-shell release-notes` | Prints the changelog section of the current version |

`forge-shell --help` lists the options. Application build targets may also call the exported script functions.

## Documentation

| Document | Content |
|---|---|
| [GUIDELINES.md](documentation/GUIDELINES.md) | The interface contract of every Forge application and the shell boundary |
| [PROJECT-STRUCTURE.md](documentation/PROJECT-STRUCTURE.md) | Repository layout and minimum checks |
| [TERMINAL.md](documentation/TERMINAL.md) | The exact rules of Terminal commands and their help |
| [UPDATING.md](documentation/UPDATING.md) | Releasing the shell, updating an application, shared workflows |
| [INSTALLER.md](documentation/INSTALLER.md) | The Windows setup: build, installation, uninstallation |
| [COMPATIBILITY.md](documentation/COMPATIBILITY.md) | The document models supported |
| [DEVELOPMENT.md](documentation/DEVELOPMENT.md) | Running, testing and changing the package |

## Modules

The entry points `forge-shell/app`, `forge-shell/desktop/main` and `forge-shell/desktop/preload` re-export their modules. Each module is also importable by subpath.

### Application (`forge-shell/app/…`)

| Module | Content |
|---|---|
| `profile` | Typed application identity and document data; storage-key helpers |
| `command-spec`, `command-help` | Command types; help, usage, aliases and syntax checks |
| `console-tabs`, `shell-preferences` | Shared Terminal verbs for tabs, panels, inspector and appearance |
| `terminal`, `messages`, `listing` | The command console, per-document message logs, aligned lists and tables |
| `menus`, `context-menu` | Browser menus, accelerators, context menus and field popovers |
| `dialogs`, `about`, `empty-state`, `sheet-grid` | Save prompts, information dialogs, the welcome view and its sheet drawn on a canvas |
| `tabs`, `documents`, `actions` | Document tabs, tab naming and routing, shared action dispatch |
| `file-open`, `file-save`, `external-change` | File selection, saving, and the decision for a file changed on disk |
| `file-tree` | The project file tree: selection, keyboard, drag and drop, rename |
| `code-editor`, `find-bar` | The shared code editor (CodeMirror, an optional peer dependency) and its find bar |
| `rename`, `selection-shape` | Rename in place; the rounded text selection |
| `status-bar`, `panel-layout`, `bottom-tabs` | Status row, resizable and closable panels, utility tabs |
| `inspector-sections`, `inspector-widgets`, `select-control`, `unit-field`, `builders` | Inspector chrome, the first section, sliders, shell-drawn select menus, unit fields, buttons, rows and list lines |
| `range-slider`, `colour-picker`, `colour-models` | The range slider, the colour picker and its colour models (hex, RGB, HSB, CIELAB) |
| `tool-strip`, `tool-button`, `tool-icons`, `tool-flyout`, `tool-search`, `tool-modes`, `eyedropper`, `tips` | The toolbar, its icons, optional modules and tooltips |
| `fonts`, `desktop-classes`, `motion`, `wheel`, `settings`, `text-input`, `workspace-keys` | Font stacks, platform classes, motion, input and persistence helpers |

### Desktop (`forge-shell/desktop/…`)

| Module | Content |
|---|---|
| `bridge` | Common preload IPC methods |
| `ipc-main`, `window-state`, `files`, `full-screen` | Main-process registration, close state, file opening, full-screen forwarding |
| `native-menu` | Renderer menu definitions converted to native menus |

### Styles, templates and scripts

| Path | Content |
|---|---|
| `styles/tokens.css`, `styles/shell.css` | Shared colour, type, shape and motion tokens; the chrome |
| `templates/app/index.html` | The page frame with the application's centre and domain-pane slots |
| `templates/new-app/` | The files of a new application, with placeholders filled in by `forge-shell new-app` |
| `scripts/theme`, `build`, `web`, `serve` | Accent derivation and checks, build, live preview and server |
| `scripts/package-config`, `dmg-background`, `build-installer`, `file-icon`, `artifact-name` | Packaging configuration, the disk image window, the Windows setup, document icons, release file names |
| `scripts/check-app`, `style-lint`, `check-release`, `licenses`, `release-notes` | Conformance, style lint, release verification, licence texts, release notes |
| `scripts/workflows`, `new-app`, `version-hook`, `cache-key`, `release-shell` | Build workflows, new applications, version hook, cache keys, the release command |
| `.github/workflows/` | The shell's builders (Check shell, Build package, Publish release, Clear all) ; the four build workflows of an application are written by `forge-shell workflows` |

## Verification

`npm run check` and `npm test` run in the standalone repository. The conformance suite covers the guideline tables, contrast, document-tab rules, save flow, the desktop bridge, native menus, preference verbs, release helpers, the installer and the construction of a second application profile. Interface and platform checks remain before a release.
