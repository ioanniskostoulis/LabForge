// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { UI_ICONS } from "./tool-icons";
import type { SettingsPage } from "./settings-dialog";
import type { ConsoleResult } from "./terminal";

const IDLE_AFTER_MS = 5 * 60_000;
const SAVE_EVERY_MS = 15_000;
const MAX_DAYS = 400;
const DEFAULT_THRESHOLD_HOURS = 4;
const THRESHOLD_CHOICES = [2, 3, 4, 5, 6] as const;
type ReminderHours = typeof THRESHOLD_CHOICES[number];

export interface HealthDay { date: string; seconds: number }
export interface HealthPreferences { reminderAfterHours: number | null; days: HealthDay[]; remindedDate?: string }
export interface HealthTracker {
  reminderAfterHours(): number | null;
  setReminderAfterHours(hours: number | null): void;
  days(): readonly HealthDay[];
  activeSecondsToday(): number;
  subscribe(listener: () => void): () => void;
  dispose(): void;
}

export interface HealthTrackerOptions {
  /** A unique per-application key. Usage data stays in that application's local storage. */
  storageKey: string;
  storage?: Pick<Storage, "getItem" | "setItem">;
  /** Testable wall clock; defaults to `Date.now`. */
  now?: () => number;
  /** Request the host's normal close flow when the person chooses a break. */
  onTakeBreak?: () => void;
}

const localDate = (time: number): string => {
  const date = new Date(time);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};

const isReminderHours = (value: unknown): value is ReminderHours => THRESHOLD_CHOICES.includes(value as ReminderHours);

/** Read the current reminder choice, accepting the key used by the first Health release. */
const storedReminderHours = (saved: Partial<HealthPreferences> & { enabled?: boolean; thresholdHours?: number }): number | null => {
  if (saved.enabled === false || saved.reminderAfterHours === null) return null;
  if (isReminderHours(saved.reminderAfterHours)) return saved.reminderAfterHours;
  if (isReminderHours(saved.thresholdHours)) return saved.thresholdHours;
  return DEFAULT_THRESHOLD_HOURS;
};

function readPreferences(key: string, storage: Pick<Storage, "getItem" | "setItem">): HealthPreferences {
  try {
    const saved = JSON.parse(storage.getItem(key) ?? "null") as (Partial<HealthPreferences> & { enabled?: boolean; thresholdHours?: number }) | null;
    const days = Array.isArray(saved?.days) ? saved.days.filter((day): day is HealthDay =>
      typeof day?.date === "string" && Number.isFinite(day.seconds) && day.seconds >= 0) : [];
    return {
      // Earlier versions linked collection and reminders. Keep a former off choice as reminders off, but resume collection.
      reminderAfterHours: storedReminderHours(saved ?? {}),
      days: days.slice(-MAX_DAYS),
      ...(typeof saved?.remindedDate === "string" ? { remindedDate: saved.remindedDate } : {}),
    };
  } catch { return { reminderAfterHours: DEFAULT_THRESHOLD_HOURS, days: [] }; }
}

/** Start counting foreground time while the window is visible, focused and recently used. */
export function createHealthTracker(options: HealthTrackerOptions): HealthTracker {
  const storage = options.storage ?? localStorage;
  const now = options.now ?? Date.now;
  const preferences = readPreferences(options.storageKey, storage);
  const listeners = new Set<() => void>();
  let lastActivity = now();
  let lastTick = now();
  let disposed = false;
  let reminder: HTMLElement | null = null;

  const dayRecord = (date: string): HealthDay => {
    let record = preferences.days.find((day) => day.date === date);
    if (!record) { record = { date, seconds: 0 }; preferences.days.push(record); }
    return record;
  };
  const save = () => {
    preferences.days = preferences.days.slice(-MAX_DAYS);
    try { storage.setItem(options.storageKey, JSON.stringify(preferences)); } catch { /* Storage can be unavailable in private or embedded contexts. */ }
    listeners.forEach((listener) => listener());
  };
  const engaged = (time: number) => document.visibilityState === "visible" && document.hasFocus() && time - lastActivity < IDLE_AFTER_MS;

  const remindIfDue = (time: number) => {
    const today = localDate(time);
    const activeSeconds = dayRecord(today).seconds;
    if (preferences.reminderAfterHours !== null && preferences.remindedDate !== today && activeSeconds >= preferences.reminderAfterHours * 3600) {
      preferences.remindedDate = today;
      save();
      showReminder();
    }
  };

  const showReminder = () => {
    if (reminder || preferences.reminderAfterHours === null) return;
    reminder = showHealthBreakReminder(preferences.reminderAfterHours, () => { reminder = null; }, options.onTakeBreak);
  };

  const tick = () => {
    if (disposed) return;
    const end = now();
    if (engaged(end)) {
      let cursor = lastTick;
      while (cursor < end) {
        const date = localDate(cursor);
        const nextDate = new Date(cursor); nextDate.setHours(24, 0, 0, 0);
        const segmentEnd = Math.min(end, nextDate.getTime());
        dayRecord(date).seconds += (segmentEnd - cursor) / 1000;
        cursor = segmentEnd;
      }
      remindIfDue(end);
      save();
    }
    lastTick = end;
  };
  const activity = () => { tick(); lastActivity = now(); };
  const visibility = () => { tick(); if (document.visibilityState === "visible") lastActivity = now(); };
  const interval = window.setInterval(tick, SAVE_EVERY_MS);
  document.addEventListener("visibilitychange", visibility);
  window.addEventListener("focus", visibility);
  window.addEventListener("blur", tick);
  for (const event of ["pointerdown", "keydown", "wheel"] as const) window.addEventListener(event, activity, { passive: true });
  requestAnimationFrame(() => { if (!disposed) remindIfDue(now()); });

  return {
    reminderAfterHours: () => preferences.reminderAfterHours,
    setReminderAfterHours(value) {
      if (value === null || THRESHOLD_CHOICES.includes(value as typeof THRESHOLD_CHOICES[number])) {
        preferences.reminderAfterHours = value;
        if (value === null) preferences.remindedDate = undefined;
        save();
        if (value !== null) remindIfDue(now());
      }
    },
    days: () => preferences.days.map((day) => ({ ...day })),
    activeSecondsToday: () => preferences.days.find((day) => day.date === localDate(now()))?.seconds ?? 0,
    subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); },
    dispose() {
      tick(); disposed = true; window.clearInterval(interval); document.removeEventListener("visibilitychange", visibility);
      window.removeEventListener("focus", visibility); window.removeEventListener("blur", tick);
      for (const event of ["pointerdown", "keydown", "wheel"] as const) window.removeEventListener(event, activity);
      reminder?.remove(); reminder = null; listeners.clear();
    },
  };
}

/** Show the standard local-use break prompt. Applications normally receive it from `createHealthTracker`. */
export function showHealthBreakReminder(hours: number, onClose: () => void = () => {}, onTakeBreak: () => void = () => {}): HTMLElement {
  const backdrop = Object.assign(document.createElement("div"), { className: "modal-backdrop info health-reminder" });
  const dialog = Object.assign(document.createElement("section"), { className: "about health-reminder-dialog" });
  dialog.setAttribute("role", "dialog"); dialog.setAttribute("aria-modal", "true"); dialog.setAttribute("aria-labelledby", "health-reminder-title");
  dialog.innerHTML = `<div class="health-reminder-copy"><div class="health-plant" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none"><path d="M24 41V22m0 11c-8 0-13-5-13-13 8 0 13 5 13 13Zm0-7c0-9 5-15 14-15 0 9-5 15-14 15ZM15 41h18" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div class="health-reminder-message"><h2 id="health-reminder-title">A little break can help.</h2><p>You have been active for ${hours} hours today. Take a moment to stretch, rest your eyes, or get a drink.</p></div></div>`;
  const actions = Object.assign(document.createElement("div"), { className: "health-reminder-actions" });
  const rest = Object.assign(document.createElement("button"), { type: "button", className: "panel-button primary", textContent: "Take a short break" });
  const continueButton = Object.assign(document.createElement("button"), { type: "button", className: "panel-button", textContent: "Keep working" });
  const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    document.removeEventListener("keydown", keys, true);
    backdrop.remove();
    onClose();
  };
  const keys = (event: KeyboardEvent) => {
    if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); close(); previousFocus?.focus(); }
  };
  rest.addEventListener("click", () => { close(); onTakeBreak(); });
  continueButton.addEventListener("click", close);
  actions.append(rest, continueButton); dialog.append(actions); backdrop.append(dialog);
  backdrop.addEventListener("mousedown", (event) => { if (event.target === backdrop) close(); });
  (document.getElementById("overlay-root") ?? document.body).append(backdrop);
  document.addEventListener("keydown", keys, true);
  rest.focus();
  return backdrop;
}

/** Run the `health reminder` Terminal command that backs the Health page. */
export function healthCommand(arg: string, tracker: HealthTracker): ConsoleResult {
  const [setting, value, extra] = arg.trim().split(/\s+/);
  if (!setting) return { lines: [tracker.reminderAfterHours() === null ? "Break reminders are off." : `Break reminder set for after ${tracker.reminderAfterHours()} hours.`] };
  if (setting !== "reminder" || !value || extra) return { lines: ["Usage: health reminder <off|2|3|4|5|6>."] };
  if (value === "off") { tracker.setReminderAfterHours(null); return { lines: ["Break reminders disabled."] }; }
  const hours = Number(value);
  if (!THRESHOLD_CHOICES.includes(hours as typeof THRESHOLD_CHOICES[number])) return { lines: ["Break reminder takes off, 2, 3, 4, 5 or 6."] };
  tracker.setReminderAfterHours(hours);
  return { lines: [`Break reminder set for after ${hours} hours.`] };
}

const hoursText = (seconds: number): string => {
  const hours = seconds / 3600;
  return hours < 1 ? `${Math.round(seconds / 60)} min` : `${hours.toFixed(hours < 10 ? 1 : 0)} h`;
};

/** Make a Health Settings page that records active use continuously and makes break reminders optional. */
export function healthPage(tracker: HealthTracker): SettingsPage {
  const activity = (): HTMLElement => {
    const root = Object.assign(document.createElement("section"), { className: "health-activity" });
    root.setAttribute("aria-label", "Active app use");
    const heading = Object.assign(document.createElement("div"), { className: "health-heading" });
    const modes = Object.assign(document.createElement("div"), { className: "health-modes", role: "tablist", "aria-label": "Activity interval" });
    const chart = Object.assign(document.createElement("div"), { className: "health-chart", role: "grid", "aria-label": "Daily active app use for the last 12 months" });
    const months = Object.assign(document.createElement("div"), { className: "health-months", "aria-hidden": "true" });
    const summary = Object.assign(document.createElement("div"), { className: "health-summary" });
    const label = Object.assign(document.createElement("span"), { className: "health-summary-label", textContent: "Active today" });
    const value = Object.assign(document.createElement("output"), { className: "health-summary-value" });
    const caption = Object.assign(document.createElement("p"), { className: "health-caption", textContent: "Records active use while this window is visible, focused and in use. It stays on this device." });
    summary.append(label, value); heading.append(modes); root.append(heading, chart, months, summary, caption);

    let mode: "daily" | "weekly" | "cumulative" = "daily";
    const buttons = (["daily", "weekly", "cumulative"] as const).map((name) => {
      const button = Object.assign(document.createElement("button"), { type: "button", textContent: name[0].toUpperCase() + name.slice(1) });
      button.setAttribute("role", "tab"); button.setAttribute("aria-selected", String(name === mode));
      button.addEventListener("click", () => { mode = name; buttons.forEach((item) => item.setAttribute("aria-selected", String(item === button))); render(); });
      return button;
    });
    modes.append(...buttons);
    const render = () => {
      const days = tracker.days(); const byDate = new Map(days.map((day) => [day.date, day.seconds]));
      const today = new Date(); today.setHours(0, 0, 0, 0);
      const cells: { date: Date; seconds: number }[] = [];
      for (let index = 363; index >= 0; index -= 1) { const date = new Date(today); date.setDate(date.getDate() - index); cells.push({ date, seconds: byDate.get(localDate(date.getTime())) ?? 0 }); }
      const plotted = mode === "weekly"
        ? Array.from({ length: 52 }, (_, week) => ({ date: cells[Math.min(week * 7, cells.length - 1)].date, seconds: cells.slice(week * 7, week * 7 + 7).reduce((sum, cell) => sum + cell.seconds, 0) }))
        : cells;
      const max = mode === "daily" ? 6 * 3600 : mode === "weekly" ? 30 * 3600 : Math.max(1, cells.reduce((sum, cell) => sum + cell.seconds, 0));
      let running = 0;
      chart.dataset.mode = mode;
      months.replaceChildren(...Array.from({ length: 52 }, (_, week) => {
        const date = cells[Math.min(week * 7, cells.length - 1)].date;
        const prior = week ? cells[(week - 1) * 7].date : null;
        const month = Object.assign(document.createElement("span"), { textContent: !prior || date.getMonth() !== prior.getMonth() ? date.toLocaleDateString(undefined, { month: "short" }) : "" });
        return month;
      }));
      chart.replaceChildren(...plotted.map((cell) => {
        running += cell.seconds;
        const seconds = mode === "cumulative" ? running : cell.seconds;
        const level = seconds === 0 ? 0 : Math.min(4, Math.ceil(seconds / max * 4));
        const tile = Object.assign(document.createElement("span"), { className: "health-day" });
        tile.dataset.level = String(level); tile.setAttribute("role", "gridcell");
        tile.setAttribute("aria-label", `${cell.date.toLocaleDateString()}: ${hoursText(cell.seconds)} active`);
        tile.title = `${cell.date.toLocaleDateString()}: ${hoursText(cell.seconds)} active`;
        return tile;
      }));
      value.textContent = hoursText(tracker.activeSecondsToday());
    };
    const unsubscribe = tracker.subscribe(render);
    const overlay = document.getElementById("overlay-root") ?? document.body;
    const observer = new MutationObserver(() => {
      if (!root.isConnected) { unsubscribe(); observer.disconnect(); }
    });
    observer.observe(overlay, { childList: true, subtree: true });
    render();
    return root;
  };
  return {
    id: "health", title: "Health", icon: UI_ICONS.activity,
    sections: [
      { title: "Activity", rows: [{ kind: "element", element: activity }] },
      { title: "Break reminder", rows: [{
        kind: "select", label: "Remind me", tip: "Show a gentle break reminder after this much active use in one day.",
        choices: [["off", "Off"], ...THRESHOLD_CHOICES.map((hours) => [String(hours), `After ${hours} hours`] as const)],
        value: () => String(tracker.reminderAfterHours() ?? "off"),
        set: (value) => tracker.setReminderAfterHours(value === "off" ? null : Number(value)),
        command: (value) => `health reminder ${value}`,
        default: String(DEFAULT_THRESHOLD_HOURS),
      }] },
    ],
  };
}
