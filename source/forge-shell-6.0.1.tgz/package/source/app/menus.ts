// Licensed under the GNU General Public License v2 or later. See LICENSE.
export interface MenuNode {
  label?: string;
  /** Command id sent back when clicked. */
  id?: string;
  /** Electron accelerator syntax, e.g. "CmdOrCtrl+R". */
  key?: string;
  /** A key shown beside the item but not bound by the menu (the app handles it: Esc, ⌫). */
  hint?: string;
  checked?: boolean;
  enabled?: boolean;
  submenu?: MenuNode[];
  separator?: boolean;
  /** Electron role for standard items (quit, close, togglefullscreen, …); desktop only. */
  role?: string;
}

const isMac = /Mac/.test(navigator.platform);

/** "CmdOrCtrl+Shift+R" → "⇧⌘R" on Mac, "Ctrl+Shift+R" elsewhere. */
export function displayKey(key: string): string {
  const parts = key.split("+");
  const k = parts.pop()!;
  // macOS menus show glyphs for named keys; Windows menus show their names. A letter is upper case on both.
  const glyphs: Record<string, string> = { Enter: "↩", Return: "↩", Right: "→", Left: "←", Up: "↑", Down: "↓", Tab: "⇥", Escape: "⎋", Esc: "⎋",
    Backspace: "⌫", Delete: "⌦", Space: "Space", Home: "↖", End: "↘", PageUp: "⇞", PageDown: "⇟" };
  const names: Record<string, string> = { Enter: "Enter", Return: "Enter", Escape: "Esc", Esc: "Esc", Backspace: "Backspace", Delete: "Del", Space: "Space",
    Home: "Home", End: "End", PageUp: "PgUp", PageDown: "PgDn", Tab: "Tab", Right: "→", Left: "←", Up: "↑", Down: "↓" };
  const name = glyphs[k] ?? (k.length === 1 ? k.toUpperCase() : k);
  if (!isMac) return [...parts.map((p) => (p === "CmdOrCtrl" ? "Ctrl" : p)), names[k] ?? (k.length === 1 ? k.toUpperCase() : k)].join("+");
  const sym: Record<string, string> = { Alt: "⌥", Shift: "⇧", CmdOrCtrl: "⌘", Ctrl: "⌃" };
  const order = ["Ctrl", "Alt", "Shift", "CmdOrCtrl"];
  return parts.sort((a, b) => order.indexOf(a) - order.indexOf(b)).map((p) => sym[p] ?? p).join("") + name;
}

// Key names written out, as macOS and Windows name them in their own help: modifiers in the platform's order.
const MAC_MODIFIERS: [string, string][] = [["Ctrl", "Control"], ["Alt", "Option"], ["Shift", "Shift"], ["CmdOrCtrl", "Cmd"], ["Cmd", "Cmd"]];
const WIN_MODIFIERS: [string, string][] = [["CmdOrCtrl", "Ctrl"], ["Ctrl", "Ctrl"], ["Alt", "Alt"], ["Shift", "Shift"]];
const KEY_NAMES: Record<string, [mac: string, win: string]> = {
  Enter: ["Return", "Enter"], Return: ["Return", "Enter"], Escape: ["Esc", "Esc"], Esc: ["Esc", "Esc"], Backspace: ["Delete", "Backspace"],
  Delete: ["Forward Delete", "Delete"], Tab: ["Tab", "Tab"], Space: ["Space", "Space"], Right: ["Right", "Right"], Left: ["Left", "Left"],
  Up: ["Up", "Up"], Down: ["Down", "Down"], Home: ["Home", "Home"], End: ["End", "End"], PageUp: ["Page Up", "Page Up"], PageDown: ["Page Down", "Page Down"],
};
// Glyphs an app may have written as a hint, read back as accelerator names.
const GLYPHS: Record<string, string> = { "⌫": "Backspace", "⎋": "Escape", "↩": "Enter", "⏎": "Enter", "⇥": "Tab", "→": "Right", "←": "Left", "↑": "Up", "↓": "Down" };

/**
 * A shortcut written out for help text and tooltips: "CmdOrCtrl+Shift+Z" is "Cmd + Shift + Z" on macOS and
 * "Ctrl + Shift + Z" elsewhere, with a space either side of each plus. Menus keep `displayKey`, as native menus do.
 */
export function shortcutText(key: string, mac = isMac): string {
  const parts = key.split(/\+(?!$)/).map((part) => GLYPHS[part] ?? part);
  const last = parts.pop()!;
  const order = mac ? MAC_MODIFIERS : WIN_MODIFIERS;
  const modifiers = order.filter(([name]) => parts.includes(name)).map(([, label]) => label).filter((label, index, all) => all.indexOf(label) === index);
  const named = KEY_NAMES[last]?.[mac ? 0 : 1] ?? (last.length === 1 ? last.toUpperCase() : last);
  return [...modifiers, named].join(" + ");
}

/** Does a keyboard event match an accelerator? */
export function matchesKey(e: KeyboardEvent, key: string): boolean {
  const parts = key.split("+");
  const k = parts.pop()!;
  const want = {
    cmd: parts.includes("CmdOrCtrl"),
    ctrl: parts.includes("Ctrl"),
    alt: parts.includes("Alt"),
    shift: parts.includes("Shift"),
  };
  const cmd = isMac ? e.metaKey : e.ctrlKey;
  const ctrl = isMac ? e.ctrlKey : false;
  if (cmd !== (want.cmd || (!isMac && want.ctrl)) || (isMac && ctrl !== want.ctrl) || e.altKey !== want.alt || e.shiftKey !== want.shift) return false;
  // Named keys and punctuation by their physical code, so that they match on every keyboard layout (Greek included).
  const code = { Enter: "Enter", Return: "Enter", Right: "ArrowRight", Left: "ArrowLeft", Up: "ArrowUp", Down: "ArrowDown", "=": "Equal", "-": "Minus",
    "[": "BracketLeft", "]": "BracketRight", "/": "Slash", ",": "Comma", ".": "Period", ";": "Semicolon", "'": "Quote", "`": "Backquote", "\\": "Backslash",
    Tab: "Tab", Escape: "Escape", Esc: "Escape", Backspace: "Backspace", Delete: "Delete", Space: "Space", Home: "Home", End: "End", PageUp: "PageUp", PageDown: "PageDown" }[k];
  if (code) return e.code === code || e.key === code;
  return e.code === `Key${k.toUpperCase()}` || e.code === `Digit${k}` || e.key.toLowerCase() === k.toLowerCase();
}

/** Where the menu bar is drawn by the page: the browser, and Windows desktop, where native menus cannot be styled. */
export function drawsMenubar(platform: string, desktop: boolean): boolean {
  return !desktop || platform === "win32";
}

/** The colours of the native window controls beside a drawn title bar, from the page's current theme. */
export function titleBarColors(element: HTMLElement = document.getElementById("menubar") ?? document.body): { color: string; symbolColor: string } {
  const style = getComputedStyle(element);
  return { color: style.backgroundColor, symbolColor: getComputedStyle(document.body).color };
}

/** The standard edit roles a drawn menu performs itself, as the native menu does. */
export const EDIT_ROLES: Record<string, () => void> = {
  undo: () => document.execCommand("undo"),
  redo: () => document.execCommand("redo"),
  cut: () => document.execCommand("cut"),
  copy: () => document.execCommand("copy"),
  paste: () => { void navigator.clipboard.readText().then((text) => document.execCommand("insertText", false, text)).catch(() => document.execCommand("paste")); },
  pasteAndMatchStyle: () => EDIT_ROLES.paste(),
  delete: () => document.execCommand("delete"),
  selectAll: () => document.execCommand("selectAll"),
};

export interface MenubarOptions {
  /** The bar is the window's title bar (Windows desktop): it drags the window and leaves room for its controls. */
  titleBar?: boolean;
  /** Actions for role items beyond `EDIT_ROLES`, such as `togglefullscreen`; a role without an action is left out. */
  roles?: Record<string, () => void>;
}

/** Render the menus as an HTML menu bar with nested pop-ups. Alt, F10 or the arrow keys move through it from the keyboard. */
const menubarCleanup = new WeakMap<HTMLElement, () => void>();

export function renderMenubar(bar: HTMLElement, menus: MenuNode[], run: (id: string) => void, options: MenubarOptions = {}): void {
  menubarCleanup.get(bar)?.();
  bar.hidden = false;
  bar.replaceChildren();
  bar.classList.toggle("title-bar", !!options.titleBar);
  bar.setAttribute("role", "menubar");
  const roles = { ...EDIT_ROLES, ...options.roles };
  const root = document.getElementById("overlay-root")!;
  let open: { el: HTMLElement; rows: HTMLElement[] }[] = [];
  let openTitle: HTMLElement | null = null;
  const titles: HTMLElement[] = [];

  const closeFrom = (level: number) => {
    for (const p of open.splice(level)) p.el.remove();
  };
  const closeAll = () => {
    closeFrom(0);
    openTitle?.classList.remove("open");
    openTitle = null;
  };
  /** Highlight a row of the popup at `level` for the keyboard, as the pointer does. */
  const highlight = (level: number, index: number) => {
    const popup = open[level];
    if (!popup) return;
    popup.rows.forEach((row, at) => row.classList.toggle("active", at === index));
  };
  const activeIndex = (level: number) => open[level]?.rows.findIndex((row) => row.classList.contains("active")) ?? -1;

  const popup = (items: MenuNode[], x: number, y: number, level: number) => {
    closeFrom(level);
    const el = document.createElement("div");
    // The check column is reserved only when an item in this popup can be checked, so that a menu of plain actions has no gap.
    el.className = "menu-popup" + (items.some((item) => "checked" in item) ? " has-checks" : "");
    el.setAttribute("role", "menu");
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
    const rows: HTMLElement[] = [];
    for (const item of items) {
      if (item.separator) {
        el.append(Object.assign(document.createElement("div"), { className: "menu-sep" }));
        continue;
      }
      const role = item.role ? roles[item.role] : undefined;
      if (item.role && !role) continue;
      const row = document.createElement("div");
      const disabled = item.enabled === false || (!item.id && !item.submenu && !role);
      row.className = "menu-item" + (disabled ? " disabled" : "");
      row.setAttribute("role", "checked" in item ? "menuitemcheckbox" : "menuitem");
      if ("checked" in item) row.setAttribute("aria-checked", String(!!item.checked));
      if (disabled) row.setAttribute("aria-disabled", "true");
      row.innerHTML = `<span class="check" aria-hidden="true">${item.checked ? "✓" : ""}</span><span class="label"></span>${item.key ?? item.hint ? `<span class="key">${displayKey((item.key ?? item.hint)!)}</span>` : ""}${item.submenu ? '<span class="sub">›</span>' : ""}`;
      row.children[1].textContent = item.label ?? "";
      row.title = item.label ?? "";
      const index = rows.length;
      const openSub = () => {
        const rowBounds = row.getBoundingClientRect();
        popup(item.submenu!, rowBounds.right - 2, rowBounds.top - 5, level + 1);
      };
      (row as HTMLElement & { openSub?: () => void; activate?: () => void }).openSub = item.submenu && !disabled ? openSub : undefined;
      const activate = () => { closeAll(); if (role) role(); else run(item.id!); };
      (row as HTMLElement & { activate?: () => void }).activate = !disabled && (item.id || role) && !item.submenu ? activate : undefined;
      row.addEventListener("mouseenter", () => {
        highlight(level, index);
        if (item.submenu && !disabled) openSub();
        else closeFrom(level + 1);
      });
      if (!disabled && (item.id || role) && !item.submenu) row.addEventListener("click", activate);
      rows.push(row);
      el.append(row);
    }
    root.append(el);
    const popupBounds = el.getBoundingClientRect();
    if (popupBounds.right > innerWidth) el.style.left = `${Math.max(0, innerWidth - popupBounds.width - 4)}px`;
    if (popupBounds.bottom > innerHeight) el.style.top = `${Math.max(0, innerHeight - popupBounds.height - 4)}px`;
    open.push({ el, rows });
  };

  const show = (title: HTMLElement, menu: MenuNode) => {
    closeAll();
    openTitle = title;
    title.classList.add("open");
    const titleBounds = title.getBoundingClientRect();
    popup(menu.submenu ?? [], titleBounds.left, titleBounds.bottom + 4, 0);
  };
  menus.forEach((menu) => {
    const title = document.createElement("div");
    title.className = "menu-title";
    title.textContent = menu.label ?? "";
    title.setAttribute("role", "menuitem");
    titles.push(title);
    if (!menu.submenu && menu.id) {
      title.addEventListener("mousedown", (e) => {
        e.preventDefault();
        closeAll();
        run(menu.id!);
      });
      bar.append(title);
      return;
    }
    title.setAttribute("aria-haspopup", "menu");
    title.addEventListener("mousedown", (e) => {
      e.preventDefault();
      if (openTitle === title) closeAll();
      else show(title, menu);
    });
    title.addEventListener("mouseenter", () => {
      if (openTitle && openTitle !== title) show(title, menu);
    });
    bar.append(title);
  });

  const outside = (e: MouseEvent) => {
    if (!(e.target as HTMLElement).closest(".menu-popup, .menu-title")) closeAll();
  };
  /** Open the menu `step` titles away from the open one, wrapping around, and highlight its first row. */
  const moveTitle = (step: number) => {
    const at = openTitle ? titles.indexOf(openTitle) : -1;
    const next = (at + step + titles.length) % titles.length;
    const menu = menus[next];
    if (menu?.submenu) { show(titles[next], menu); highlight(0, 0); }
  };
  let altAlone = false;
  const keys = (e: KeyboardEvent) => {
    // Outside macOS, Alt pressed and released alone, or F10, opens the first menu, as Windows does.
    if (e.type === "keyup") {
      if (e.key === "Alt" && altAlone && !isMac) { e.preventDefault(); if (open.length) closeAll(); else moveTitle(1); }
      altAlone = false;
      return;
    }
    altAlone = e.key === "Alt" && !e.repeat;
    if (e.key === "F10" && !isMac && !e.shiftKey && !e.metaKey && !e.ctrlKey && !e.altKey) { e.preventDefault(); if (open.length) closeAll(); else moveTitle(1); return; }
    if (!open.length) return;
    const level = open.length - 1;
    const rows = open[level].rows;
    const at = activeIndex(level);
    const usable = (index: number) => !rows[index].classList.contains("disabled");
    const step = (delta: number) => {
      for (let tries = 1, index = at; tries <= rows.length; tries++) {
        index = (index + delta + rows.length) % rows.length;
        if (usable(index)) { highlight(level, index); return; }
      }
    };
    const row = rows[at] as (HTMLElement & { openSub?: () => void; activate?: () => void }) | undefined;
    const handled = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    if (e.key === "Escape") { handled(); if (level > 0) closeFrom(level); else closeAll(); }
    else if (e.key === "ArrowDown") { handled(); step(1); }
    else if (e.key === "ArrowUp") { handled(); step(at < 0 ? 0 : -1); }
    else if (e.key === "ArrowRight") { handled(); if (row?.openSub) { row.openSub(); highlight(level + 1, 0); } else moveTitle(1); }
    else if (e.key === "ArrowLeft") { handled(); if (level > 0) closeFrom(level); else moveTitle(-1); }
    else if (e.key === "Enter" || e.key === " ") { handled(); if (row?.openSub) { row.openSub(); highlight(level + 1, 0); } else row?.activate?.(); }
  };
  document.addEventListener("mousedown", outside);
  document.addEventListener("keydown", keys, true);
  document.addEventListener("keyup", keys, true);
  menubarCleanup.set(bar, () => {
    closeAll();
    document.removeEventListener("mousedown", outside);
    document.removeEventListener("keydown", keys, true);
    document.removeEventListener("keyup", keys, true);
  });
}

/**
 * Find all items with accelerators (for keyboard handling in the browser). Items with a role are left out: their keys
 * (Cmd+C, Cmd+V, Cmd+A…) belong to the focused text field and the browser, never to the application's handler.
 */
export function collectShortcuts(menus: MenuNode[], out: { key: string; id: string }[] = []): { key: string; id: string }[] {
  for (const m of menus) {
    if (m.key && m.id && !m.role && m.enabled !== false) out.push({ key: m.key, id: m.id });
    if (m.submenu) collectShortcuts(m.submenu, out);
  }
  return out;
}

/** Menu shortcuts for the keyboard-help window, in app-supplied category order. */
export function menuShortcutRows(commands: readonly { id: string; label: string; key?: string; hint?: string }[], order: readonly string[]): [string, string][] {
  const seen = new Set<string>();
  const rank = (id: string) => {
    const index = order.indexOf(id.split(".")[0]);
    return index < 0 ? order.length : index;
  };
  const keyOf = (command: (typeof commands)[number]) => command.key ?? command.hint;
  return commands.filter((command) => {
    const key = keyOf(command);
    return !!key && !seen.has(key) && !!seen.add(key);
  }).sort((a, b) => rank(a.id) - rank(b.id))
    .map((command) => [shortcutText(keyOf(command)!), command.label.replace(/\s+\(.*\)$/, "").replace(/…$/, "")]);
}
