// What a scroll means, the same on work surfaces and data views, by the established convention:
// a trackpad's two-finger scroll pans and its pinch zooms; a mouse wheel zooms at the pointer, a
// step per notch however fast it turns (⌘ or Ctrl + scroll zooms with either).
// Licensed under the GNU General Public License v2 or later. See LICENSE.

export type WheelIntent = { kind: "zoom"; factor: number } | { kind: "pan"; dx: number; dy: number };

/** Zoom per mouse-wheel notch. */
const NOTCH_ZOOM = 1.15;
/**
 * Zoom per pixel of a pinch, as exp(−deltaY × this). Chromium writes a pinch's change of scale s as deltaY = −100 ln s,
 * so 0.01 would follow the fingers exactly; 0.03 zooms three times as far, which suits a pinch over a whole document
 * (about 2× for a short pinch, 6× for a long one).
 */
const PINCH_RATE = 0.03;
/** A Ctrl + scroll step in pixels smaller than this is a pinch; a mouse notch is about 100 px. */
const PINCH_MAX_STEP = 50;
/** Events closer than this are one gesture (its device is decided once, by its first event). */
const GESTURE_GAP_MS = 250;

let gesture = { at: -Infinity, trackpad: false };

/**
 * Is it a trackpad? Chromium and Safari give a trackpad scroll a legacy wheelDeltaY of exactly −3 ×
 * its deltaY; a mouse wheel's is in notches (±120 each) whatever macOS's acceleration does to
 * deltaY. A sideways component is a trackpad too (a mouse wheel has none, without Shift).
 */
function isTrackpad(e: WheelEvent): boolean {
  const legacy = (e as WheelEvent & { wheelDeltaY?: number }).wheelDeltaY;
  if (e.deltaX !== 0 && !e.shiftKey) return true;
  if (legacy) return legacy === -3 * e.deltaY;
  return e.deltaMode === 0;
}

/**
 * Notches of a mouse wheel turn: from the legacy delta (±120 each) or from lines or pages; null for a trackpad or a pinch.
 * Chromium stamps each pinch step with a legacy delta of ±120 too, so a small pixel step with Ctrl is a pinch whatever
 * its legacy delta says (read as notches, a pinch of 50 small steps zoomed 1.15 each, thousands of times over).
 */
function mouseNotches(e: WheelEvent): number | null {
  if (e.ctrlKey && e.deltaMode === 0 && Math.abs(e.deltaY) < PINCH_MAX_STEP) return null;
  const legacy = (e as WheelEvent & { wheelDeltaY?: number }).wheelDeltaY;
  if (legacy && legacy !== -3 * e.deltaY && legacy % 120 === 0) return legacy / 120;
  if (e.deltaMode === 1) return -e.deltaY / 3;
  if (e.deltaMode === 2) return -e.deltaY;
  return null;
}

/** The zoom of `notches` mouse-wheel notches, at most 6 a turn. */
const notchZoom = (notches: number): number => Math.pow(NOTCH_ZOOM, Math.max(-6, Math.min(6, notches)));

/** What a wheel event asks for. */
export function wheelIntent(e: WheelEvent, wheelZooms: boolean): WheelIntent {
  // A pinch arrives as Ctrl + scroll in small pixel steps; ⌘ or Ctrl + a mouse wheel zooms a notch at a time, as
  // without the key (exp(−100 × 0.01) would zoom 2.7× for one notch of 100 px).
  if (e.ctrlKey || e.metaKey) {
    const notches = mouseNotches(e);
    return { kind: "zoom", factor: notches === null ? Math.exp(-e.deltaY * PINCH_RATE) : notchZoom(notches) };
  }
  const now = performance.now();
  if (now - gesture.at > GESTURE_GAP_MS) gesture.trackpad = wheelZooms ? false : isTrackpad(e);
  gesture.at = now;
  if (gesture.trackpad) return { kind: "pan", dx: e.deltaX, dy: e.deltaY };
  // Shift + wheel: sideways, as everywhere
  if (e.shiftKey) return { kind: "pan", dx: e.deltaX || e.deltaY, dy: 0 };
  // notches: from the legacy delta when there is one, else lines or pixels
  const legacy = (e as WheelEvent & { wheelDeltaY?: number }).wheelDeltaY;
  const notches = legacy ? legacy / 120 : e.deltaMode === 1 ? -e.deltaY / 3 : e.deltaMode === 2 ? -e.deltaY : -e.deltaY / 100;
  return { kind: "zoom", factor: notchZoom(notches) };
}
