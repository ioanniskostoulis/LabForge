// Licensed under the GNU General Public License v2 or later. See LICENSE.
// A range slider: two thumbs on one track, an editable readout for each end, and an optional wrap for circular
// ranges such as hue, where the low end may lie above the high end and the range runs through the ends of the track.
import { editableValue } from "./inspector-widgets";

/** The low and the high end of a range. */
export type Range = readonly [low: number, high: number];

/** Inset of the track's ends from the slider's edges, in px, as for `makeSlider`. */
export const RANGE_INSET_PX = 4;
/** Number of steps across the track when no step is given. */
export const RANGE_DEFAULT_STEPS = 100;
/** Steps moved by Page Up and Page Down. */
export const RANGE_PAGE_STEPS = 10;

// MARK: method

const clamp = (v: number, min: number, max: number): number => Math.max(min, Math.min(max, v));

/** The default step: the power of ten closest below 1/100 of the span (1 for 0–255 and 0–360, 0.01 for 0–1). */
export function rangeStep(min: number, max: number): number {
  return 10 ** Math.floor(Math.log10((max - min) / RANGE_DEFAULT_STEPS));
}

/** Decimal places that show a step exactly (0 for 1, 2 for 0.01, 1 for 0.5). */
export function stepDecimals(step: number): number {
  const text = String(step);
  const dot = text.indexOf(".");
  return dot < 0 ? 0 : text.length - dot - 1;
}

/** A value on whole steps from `min`, inside [min, max]. */
export function snapToStep(v: number, min: number, max: number, step: number): number {
  const snapped = min + Math.round((v - min) / step) * step;
  return clamp(Number(snapped.toFixed(stepDecimals(step))), min, max);
}

/** Whether `v` lies in the range; a wrapped range (low above high) holds the values from low up and from high down. */
export function inRange(v: number, [low, high]: Range): boolean {
  return low <= high ? v >= low && v <= high : v >= low || v <= high;
}

/** The filled spans of the track as fractions of its length: one span, or two for a wrapped range. */
export function rangeSpans([low, high]: Range, min: number, max: number): [number, number][] {
  const f = (v: number) => (v - min) / (max - min);
  return low <= high ? [[f(low), f(high)]] : [[f(low), 1], [0, f(high)]];
}

/**
 * The range with one end moved to `v`, inside [min, max]. Without wrap the low end stops at the high end and the high
 * end at the low end; with wrap either end may pass the other.
 */
export function moveRangeEnd(range: Range, end: 0 | 1, v: number, min: number, max: number, wrap = false): [number, number] {
  const next: [number, number] = [range[0], range[1]];
  const at = clamp(v, min, max);
  if (wrap) next[end] = at;
  else next[end] = end === 0 ? Math.min(at, range[1]) : Math.max(at, range[0]);
  return next;
}

/**
 * The end a press takes: the nearer one. When both are as near (the ends meet), the direction of the first movement
 * decides, so that two ends at one value can still be pulled apart.
 */
export function grabbedEnd([low, high]: Range, pressed: number, moved: number): 0 | 1 {
  const dLow = Math.abs(pressed - low), dHigh = Math.abs(pressed - high);
  if (dLow !== dHigh) return dLow < dHigh ? 0 : 1;
  return moved < pressed ? 0 : 1;
}

/** A typed end, or null when it is not a number inside [min, max] or (without wrap) it would pass the other end. */
export function typedRangeEnd(text: string, range: Range, end: 0 | 1, min: number, max: number, wrap = false): number | null {
  const v = Number.parseFloat(text.replace("−", "-"));
  if (!Number.isFinite(v) || v < min || v > max) return null;
  if (!wrap && (end === 0 ? v > range[1] : v < range[0])) return null;
  return v;
}

// MARK: the row

/** Options of a range slider row. */
export interface RangeSliderOptions {
  /** Circular range: the low end may lie above the high end. */
  wrap?: boolean;
  /** The step of a drag, a key and a typed value (default `rangeStep(min, max)`). */
  step?: number;
  /** The text of an end (default: the value with the step's decimals). */
  format?: (v: number) => string;
  /** Group each drag, key step, typed value or reset as one undoable change. */
  undo?: { begin(): void; end(): void };
  /** Double-click: the range to return to (default: the full range; null: nothing to reset to). */
  reset?: () => Range | null;
  enabled?: boolean;
}

/** A labelled range slider: the label and both ends on the readout line, two thumbs on one track below it. */
export function rangeSliderRow(label: string, value: Range, min: number, max: number, onInput: (range: [number, number]) => void, options: RangeSliderOptions = {}) {
  const { wrap = false, step = rangeStep(min, max), undo, enabled = true } = options;
  const format = options.format ?? ((v: number) => v.toFixed(stepDecimals(step)));
  let range: [number, number] = [value[0], value[1]];
  const make = <K extends keyof HTMLElementTagNameMap>(tag: K, cls: string, text?: string) => {
    const e = document.createElement(tag);
    e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };

  const row = make("div", "slider-row range-row" + (enabled ? "" : " disabled"));
  const head = make("div", "head");
  const ends = make("span", "ends");
  const lowText = make("span", "value"), highText = make("span", "value");
  ends.append(lowText, make("span", "dash", " – "), highText);
  head.append(make("span", "", label), ends);
  const root = make("div", "slider range" + (wrap ? " wrap" : ""));
  const fills = [make("div", "fill"), make("div", "fill")];
  const thumbs = [make("div", "thumb low"), make("div", "thumb high")];
  root.append(make("div", "track"), ...fills, ...thumbs);
  row.append(head, root);

  const xAt = (fraction: number) => RANGE_INSET_PX + fraction * (root.clientWidth - 2 * RANGE_INSET_PX || 1);
  const show = () => {
    const spans = rangeSpans(range, min, max);
    fills.forEach((fill, i) => {
      fill.hidden = !spans[i];
      if (!spans[i]) return;
      // a span that reaches an end of the track is filled to the slider's edge, as the single slider's fill is
      const left = spans[i][0] <= 0 ? 0 : xAt(spans[i][0]);
      const right = spans[i][1] >= 1 ? root.clientWidth : xAt(spans[i][1]);
      fill.style.left = `${left}px`;
      fill.style.width = `${Math.max(0, right - left)}px`;
    });
    thumbs.forEach((thumb, i) => {
      thumb.style.left = `${xAt((range[i] - min) / (max - min))}px`;
      thumb.setAttribute("aria-valuenow", String(range[i]));
      thumb.setAttribute("aria-valuetext", format(range[i]));
    });
    lowText.textContent = format(range[0]);
    highText.textContent = format(range[1]);
  };
  const change = (next: [number, number]) => {
    if (next[0] === range[0] && next[1] === range[1]) return;
    range = next;
    show();
    onInput([range[0], range[1]]);
  };
  const once = (next: [number, number]) => {
    undo?.begin();
    change(next);
    undo?.end();
  };
  const valueAt = (clientX: number) => {
    const r = root.getBoundingClientRect();
    const f = clamp((clientX - r.left - RANGE_INSET_PX) / Math.max(1, r.width - 2 * RANGE_INSET_PX), 0, 1);
    return snapToStep(min + f * (max - min), min, max, step);
  };

  thumbs.forEach((thumb, i) => {
    thumb.setAttribute("role", "slider");
    thumb.setAttribute("aria-label", `${label}, ${i === 0 ? "low" : "high"} end`);
    thumb.setAttribute("aria-valuemin", String(min));
    thumb.setAttribute("aria-valuemax", String(max));
    if (!enabled) return;
    thumb.tabIndex = 0;
    thumb.addEventListener("keydown", (e) => {
      const steps = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1, PageUp: RANGE_PAGE_STEPS, PageDown: -RANGE_PAGE_STEPS }[e.key];
      const to = steps !== undefined ? range[i] + steps * step : e.key === "Home" ? min : e.key === "End" ? max : null;
      if (to === null) return;
      e.preventDefault();
      e.stopPropagation();
      once(moveRangeEnd(range, i as 0 | 1, snapToStep(to, min, max, step), min, max, wrap));
    });
  });

  if (enabled) {
    root.addEventListener("pointerdown", (e) => {
      root.setPointerCapture(e.pointerId);
      undo?.begin();
      const pressed = valueAt(e.clientX);
      const exact = Math.abs(pressed - range[0]) === Math.abs(pressed - range[1]);
      let end: 0 | 1 | null = exact ? null : grabbedEnd(range, pressed, pressed);
      if (end !== null) {
        thumbs[end].focus();
        change(moveRangeEnd(range, end, pressed, min, max, wrap));
      }
      const move = (ev: PointerEvent) => {
        const v = valueAt(ev.clientX);
        if (end === null) {
          if (v === pressed) return;
          end = grabbedEnd(range, pressed, v);
          thumbs[end].focus();
        }
        change(moveRangeEnd(range, end, v, min, max, wrap));
      };
      const up = () => {
        root.removeEventListener("pointermove", move);
        root.removeEventListener("pointerup", up);
        root.removeEventListener("pointercancel", up);
        undo?.end();
      };
      root.addEventListener("pointermove", move);
      root.addEventListener("pointerup", up);
      root.addEventListener("pointercancel", up);
    });
    root.addEventListener("dblclick", () => {
      const to = options.reset ? options.reset() : [min, max] as const;
      if (to) once([to[0], to[1]]);
    });
    [lowText, highText].forEach((text, i) => {
      const end = i as 0 | 1;
      editableValue(text, () => format(range[end]), (typed) => {
        const v = typedRangeEnd(typed, range, end, min, max, wrap);
        if (v === null) return false;
        once(moveRangeEnd(range, end, v, min, max, wrap));
        return true;
      }, `Enter the ${end === 0 ? "low" : "high"} end, from ${format(min)} to ${format(max)}`);
    });
  }

  show();
  requestAnimationFrame(show);
  new ResizeObserver(show).observe(root);
  return {
    row,
    lowText,
    highText,
    slider: {
      root,
      get value(): [number, number] { return [range[0], range[1]]; },
      /** Show a range without calling `onInput`. */
      set(next: Range): void { range = [next[0], next[1]]; show(); },
    },
  };
}
