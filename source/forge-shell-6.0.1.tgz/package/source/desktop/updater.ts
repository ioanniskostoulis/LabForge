// Licensed under the GNU General Public License v2 or later. See LICENSE.
// One-click updates on the desktop. The main process downloads the release's installer, checks its size and SHA-256,
// and then:
//  - macOS: opens the disk image out of sight, copies the new app beside the running one, quits, and a detached
//    script swaps the two and opens the new app. Where the app cannot replace itself (opened from the disk image or a
//    translocated download, or a folder it cannot write), the disk image is opened instead.
//  - Windows: quits, and a detached script, run from the temporary folder, waits for every process of the app, runs the
//    Forge setup silently (it asks for administrator rights once), retries while the app's folder is still in use,
//    and opens the installed app again.
import { spawn, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { accessSync, constants, existsSync, mkdtempSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname, join } from "node:path";
import type { InstallResult, ReleaseAsset } from "../app/updates";

/** The `.app` bundle that holds a macOS executable (`/Applications/X.app/Contents/MacOS/X` → `/Applications/X.app`), or null. */
export function appBundle(executable: string): string | null {
  const match = /^(.*?\.app)\/Contents\/MacOS\/[^/]+$/.exec(executable);
  return match ? match[1] : null;
}

/** Why a macOS app at `bundle` cannot replace itself, or null when it can. */
export function cannotReplace(bundle: string | null): string | null {
  if (!bundle) return "The app is not in an app bundle.";
  if (bundle.includes("/AppTranslocation/")) return "The app was opened from where it was downloaded. Move it to Applications first.";
  if (bundle.startsWith("/Volumes/")) return "The app was opened from its disk image. Drag it to Applications first.";
  return null;
}

const quote = (text: string) => `'${text.replaceAll("'", "'\\''")}'`;

/** The detached macOS script: wait for the app to quit, swap in the staged copy, clear quarantine and open it. */
export function macSwapScript(options: { pid: number; bundle: string; staged: string; work: string }): string {
  const { pid, bundle, staged, work } = options;
  const old = `${bundle}.old`;
  return [
    "#!/bin/sh",
    `while kill -0 ${pid} 2>/dev/null; do sleep 0.2; done`,
    `rm -rf ${quote(old)}`,
    // The running copy moves aside first; if the new one then cannot take its place, the old one goes back.
    `if mv ${quote(bundle)} ${quote(old)}; then`,
    `  if mv ${quote(staged)} ${quote(bundle)}; then rm -rf ${quote(old)}; else mv ${quote(old)} ${quote(bundle)}; fi`,
    "fi",
    `rm -rf ${quote(staged)}`,
    `xattr -dr com.apple.quarantine ${quote(bundle)} 2>/dev/null`,
    `open ${quote(bundle)}`,
    `rm -rf ${quote(work)}`,
    "",
  ].join("\n");
}

const psQuote = (text: string) => `'${text.replaceAll("'", "''")}'`;

/**
 * The detached Windows script. It runs from `work`, never from the app's folder: the setup replaces the app by renaming
 * its folder, which Windows refuses while any process has it as its working directory (the script and the setup would
 * otherwise inherit the app's own, the install folder when it was started from its shortcut). It waits for the app and
 * then for every process of the app's executable, since Electron's helper processes run the same file and can outlive
 * it for a moment, at most 30 s. A setup that still finds the app or its folder in use (exit 3) is run again, twice at
 * most, 2 s apart. The installed app is opened again either way, and each step is written to `log`.
 */
export function windowsUpdateScript(options: { pid: number; setup: string; app: string; work: string; log: string }): string {
  const { pid, setup, app, work, log } = options;
  return [
    `$log = ${psQuote(log)}`,
    "function Note($text) { Add-Content -LiteralPath $log -Value ((Get-Date).ToString('u') + ' ' + $text) -ErrorAction SilentlyContinue }",
    `Set-Location -LiteralPath ${psQuote(work)}`,
    `Note 'Update: waiting for the app to quit.'`,
    `Wait-Process -Id ${pid} -ErrorAction SilentlyContinue`,
    "$deadline = (Get-Date).AddSeconds(30)",
    `while ((Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq ${psQuote(app)} }) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 250 }`,
    "$code = 1",
    "for ($try = 1; $try -le 3; $try++) {",
    `  $setup = Start-Process -FilePath ${psQuote(setup)} -ArgumentList '/S' -WorkingDirectory ${psQuote(work)} -Wait -PassThru`,
    "  $code = $setup.ExitCode",
    '  Note "Update: setup try $try exit $code."',
    // 3: the app or its folder was still in use; anything else is final.
    "  if ($code -ne 3) { break }",
    "  Start-Sleep -Seconds 2",
    "}",
    // A failed or refused setup leaves the installed version, which is opened again either way.
    `Start-Process -FilePath ${psQuote(app)} -WorkingDirectory $env:USERPROFILE`,
    "Set-Location -LiteralPath $env:TEMP",
    `Remove-Item -LiteralPath ${psQuote(work)} -Recurse -Force -ErrorAction SilentlyContinue`,
    "exit $code",
    "",
  ].join("\r\n");
}

/** Where a Windows update writes its steps: `<Product> update.log` in the temporary folder, kept after the update. */
export const windowsUpdateLog = (executable: string, temp = tmpdir()): string => join(temp, `${basename(executable.replace(/\\/g, "/")).replace(/\.exe$/i, "")} update.log`);

/** How far a download is: bytes received and, when known, the whole size. */
export interface DownloadProgress { done: number; total: number }

/**
 * Download an asset to `path`, checking its size and, when GitHub gives one, its SHA-256 digest. `onProgress` follows
 * the bytes as they arrive, at most every 100 ms and once at the end.
 */
export async function downloadAsset(asset: ReleaseAsset, path: string, request: typeof fetch = fetch, onProgress?: (progress: DownloadProgress) => void): Promise<void> {
  const response = await request(asset.url, { redirect: "follow" });
  if (!response.ok) throw new Error(`The download failed: GitHub answered ${response.status}.`);
  const total = asset.size || Number(response.headers?.get?.("content-length")) || 0;
  const chunks: Uint8Array[] = [];
  let done = 0, reported = 0;
  const reader = response.body?.getReader?.();
  if (reader) {
    for (;;) {
      const { value, done: finished } = await reader.read();
      if (finished) break;
      chunks.push(value);
      done += value.length;
      const now = Date.now();
      if (onProgress && now - reported >= 100) { reported = now; onProgress({ done, total }); }
    }
  } else {
    const whole = new Uint8Array(await response.arrayBuffer());
    chunks.push(whole);
    done = whole.length;
  }
  onProgress?.({ done, total: total || done });
  const bytes = Buffer.concat(chunks.map((chunk) => Buffer.from(chunk.buffer, chunk.byteOffset, chunk.byteLength)));
  if (asset.size && bytes.length !== asset.size) throw new Error("The download was incomplete.");
  if (asset.sha256 && createHash("sha256").update(bytes).digest("hex") !== asset.sha256) throw new Error("The download did not match the release.");
  writeFileSync(path, bytes);
}

export interface UpdaterOptions {
  /** The repository named in the profile; only its release files are downloaded. */
  repository: string;
  /** `process.execPath` of the packaged app. */
  executable: string;
  platform: string;
  /** Quit the app, closing its windows (Electron's `app.quit`). */
  quit(): void;
  /** Open a file with its default application (Electron's `shell.openPath`). */
  openPath(path: string): Promise<string>;
  request?: typeof fetch;
  /** Follows the download (`updateProgress` to the window that asked, through `registerUpdater`). */
  onProgress?(progress: DownloadProgress): void;
}

/** Install an update, as described at the top of this file. */
export async function installUpdate(asset: ReleaseAsset, options: UpdaterOptions): Promise<InstallResult> {
  if (!asset.url.startsWith(`https://github.com/${options.repository}/releases/download/`)) return { status: "failed", reason: "The update is not from this app's releases." };
  const work = mkdtempSync(join(tmpdir(), "forge-update-"));
  const file = join(work, basename(new URL(asset.url).pathname));
  try {
    await downloadAsset(asset, file, options.request, options.onProgress);
  } catch (error) {
    rmSync(work, { recursive: true, force: true });
    return { status: "failed", reason: error instanceof Error ? error.message : String(error) };
  }
  if (options.platform === "win32") return startWindowsUpdate(file, options);
  if (options.platform === "darwin") return startMacUpdate(file, work, options);
  return { status: "failed", reason: "Updates install only on macOS and Windows." };
}

function startWindowsUpdate(setup: string, options: UpdaterOptions): InstallResult {
  const work = dirname(setup);
  const script = join(work, "update.ps1");
  writeFileSync(script, windowsUpdateScript({ pid: process.pid, setup, app: options.executable, work, log: windowsUpdateLog(options.executable) }));
  // From the temporary folder, so the script does not hold the app's folder, which the setup renames.
  spawn("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", script], { cwd: work, detached: true, stdio: "ignore", windowsHide: true }).unref();
  options.quit();
  return { status: "restarting" };
}

async function startMacUpdate(dmg: string, work: string, options: UpdaterOptions): Promise<InstallResult> {
  const bundle = appBundle(options.executable);
  const writable = (path: string) => { try { accessSync(path, constants.W_OK); return true; } catch { return false; } };
  if (cannotReplace(bundle) || !writable(dirname(bundle!)) || !writable(bundle!)) {
    const failed = await options.openPath(dmg);
    return failed ? { status: "failed", reason: failed } : { status: "opened" };
  }
  const mount = join(work, "volume");
  const staged = `${bundle}.new`;
  const attach = spawnSync("hdiutil", ["attach", dmg, "-nobrowse", "-readonly", "-noautoopen", "-mountpoint", mount], { encoding: "utf8" });
  if (attach.status !== 0) return { status: "failed", reason: "The disk image could not be opened." };
  try {
    const app = readdirSync(mount).find((name) => name.endsWith(".app"));
    if (!app) return { status: "failed", reason: "The disk image holds no app." };
    rmSync(staged, { recursive: true, force: true });
    // ditto keeps the bundle's links, permissions and signature.
    const copy = spawnSync("ditto", [join(mount, app), staged]);
    if (copy.status !== 0 || !existsSync(staged)) { rmSync(staged, { recursive: true, force: true }); return { status: "failed", reason: "The new app could not be copied." }; }
  } finally {
    spawnSync("hdiutil", ["detach", mount, "-quiet"]);
  }
  rmSync(dmg, { force: true });
  const script = join(work, "update.sh");
  writeFileSync(script, macSwapScript({ pid: process.pid, bundle: bundle!, staged, work }), { mode: 0o755 });
  spawn("/bin/sh", [script], { detached: true, stdio: "ignore" }).unref();
  options.quit();
  return { status: "restarting" };
}

/** The `installUpdate` handler of the main process, for the bridge's `installUpdate`. */
export function registerUpdater(ipc: { handle(channel: string, handler: (event: unknown, ...args: any[]) => unknown): unknown }, options: UpdaterOptions): void {
  ipc.handle("installUpdate", (event, asset: ReleaseAsset) => {
    if (!asset || typeof asset.url !== "string" || typeof asset.name !== "string") return { status: "failed", reason: "No update was given." };
    // The window that asked follows the download (the bridge's `onUpdateProgress`).
    const sender = (event as { sender?: { send?(channel: string, ...args: unknown[]): void; isDestroyed?(): boolean } } | null)?.sender;
    const onProgress = (progress: DownloadProgress) => { options.onProgress?.(progress); if (sender?.send && !sender.isDestroyed?.()) sender.send("updateProgress", progress); };
    return installUpdate({ name: asset.name, url: asset.url, size: Number(asset.size) || 0, sha256: typeof asset.sha256 === "string" ? asset.sha256 : null }, { ...options, onProgress });
  });
}
