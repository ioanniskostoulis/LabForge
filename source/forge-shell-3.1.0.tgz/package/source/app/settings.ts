// Licensed under the GNU General Public License v2 or later. See LICENSE.
/** Persist a mutable app settings object and notify listeners after changes. */
export function createSettingsStore<T extends object>(
  storageKey: string,
  defaults: T,
  restore: (stored: Record<string, unknown>) => T,
): {
  settings: T;
  updateSettings(patch: Partial<T>): void;
  onSettingsChange(listener: () => void): void;
} {
  // CLI and workers use defaults without browser storage.
  let settings = { ...defaults };
  if (typeof document !== "undefined") {
    try { settings = restore(JSON.parse(localStorage.getItem(storageKey) ?? "{}")); }
    catch { settings = { ...defaults }; }
  }
  const listeners = new Set<() => void>();
  return {
    settings,
    updateSettings(patch) {
      Object.assign(settings, patch);
      if (typeof document !== "undefined") try {
        localStorage.setItem(storageKey, JSON.stringify(settings));
      } catch {
        // Storage unavailable (private mode): settings still apply for this session.
      }
      for (const listener of listeners) listener();
    },
    onSettingsChange(listener) { listeners.add(listener); },
  };
}
