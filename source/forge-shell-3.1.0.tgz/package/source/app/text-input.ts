// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** Track whether an edit key belongs to text typed since a field gained focus. */
export function createTextInputState(doc: Document = document) {
  const isTextEntry = (element: Element | null): element is HTMLInputElement | HTMLTextAreaElement =>
    element instanceof HTMLTextAreaElement || (element instanceof HTMLInputElement && /^(text|search|number|url|email|password)$/.test(element.type));
  const typedIn = new WeakSet<Element>();
  doc.addEventListener("focusin", (event) => { if (event.target instanceof Element) typedIn.delete(event.target); }, true);
  doc.addEventListener("input", (event) => { if (isTextEntry(event.target as Element)) typedIn.add(event.target as Element); }, true);
  doc.addEventListener("change", (event) => { if (event.target instanceof Element) typedIn.delete(event.target); }, true);
  doc.addEventListener("submit", (event) => {
    for (const field of (event.target as HTMLFormElement).querySelectorAll("input, textarea")) typedIn.delete(field);
  }, true);
  return {
    isTextEntry,
    typingInField(): boolean {
      const active = doc.activeElement;
      return isTextEntry(active) && typedIn.has(active);
    },
  };
}
