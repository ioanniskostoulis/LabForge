// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface ToolSearchResult { id: string; label: string; category?: string }

/** Optional module: the `#toolstrip-search` combobox. `name` is the plural of the searched objects, such as "parts". */
export function createToolSearch(options: { name: string; search(query: string): ToolSearchResult[]; onSelect(id: string): void; icon?: string; overlay?: HTMLElement }) {
  const doc = document;
  const root = doc.createElement("div");
  root.id = "toolstrip-search";
  if (options.icon) root.innerHTML = options.icon;
  const input = doc.createElement("input");
  input.type = "text";
  input.placeholder = `Search ${options.name}`;
  input.setAttribute("role", "combobox");
  input.setAttribute("aria-label", `Search ${options.name}`);
  input.setAttribute("aria-expanded", "false");
  input.setAttribute("aria-controls", "tool-search-results");
  root.append(input);
  const list = doc.createElement("div");
  list.id = "tool-search-results";
  list.className = "menu-popup context tool-search-results";
  list.setAttribute("role", "listbox");
  let results: ToolSearchResult[] = [];
  let index = 0;

  const paint = (): void => {
    list.replaceChildren(...(results.length ? results.map((result, at) => {
      const row = doc.createElement("button");
      row.type = "button";
      row.className = `tool-search-result${at === index ? " active" : ""}`;
      row.setAttribute("role", "option");
      row.textContent = result.label;
      if (result.category) { const tag = doc.createElement("span"); tag.className = "tool-search-category"; tag.textContent = result.category; row.append(tag); }
      row.addEventListener("click", () => choose(at));
      return row;
    }) : [Object.assign(doc.createElement("div"), { className: "tool-search-empty", textContent: `No ${options.name} found.` })]));
  };
  const show = (open: boolean): void => {
    input.setAttribute("aria-expanded", String(open));
    if (open) {
      const rect = root.getBoundingClientRect();
      list.style.left = `${rect.left}px`;
      list.style.top = `${rect.bottom + 2}px`;
      (options.overlay ?? doc.getElementById("overlay-root") ?? doc.body).append(list);
    } else list.remove();
  };
  const clear = (): void => { input.value = ""; results = []; show(false); };
  const choose = (at: number): void => { const result = results[at]; clear(); if (result) options.onSelect(result.id); };
  input.addEventListener("input", () => {
    results = input.value.trim() ? options.search(input.value.trim()) : [];
    index = 0;
    if (!input.value.trim()) return show(false);
    paint(); show(true);
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown") { event.preventDefault(); index = Math.min(index + 1, results.length - 1); paint(); }
    else if (event.key === "ArrowUp") { event.preventDefault(); index = Math.max(index - 1, 0); paint(); }
    else if (event.key === "Enter") { event.preventDefault(); choose(index); }
    else if (event.key === "Escape") { event.preventDefault(); clear(); }
  });
  return { root, input, clear };
}
