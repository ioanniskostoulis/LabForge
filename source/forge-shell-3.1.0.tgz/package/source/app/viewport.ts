// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** Maps content (world) coordinates to view pixels for a canvas that pans and zooms: view = world × scale + origin. */
export class Viewport {
  static readonly minScale = 0.05;
  static readonly maxScale = 12;

  constructor(public scale = 1, public ox = 0, public oy = 0) {}

  toWorld(x: number, y: number): [number, number] {
    return [(x - this.ox) / this.scale, (y - this.oy) / this.scale];
  }

  toView(x: number, y: number): [number, number] {
    return [x * this.scale + this.ox, y * this.scale + this.oy];
  }

  /** Zoom by `factor`, keeping the world point under (ax, ay) fixed, within `minScale` and `maxScale`. */
  zoom(factor: number, ax: number, ay: number): void {
    const [wx, wy] = this.toWorld(ax, ay);
    this.scale = Math.min(Math.max(this.scale * factor, Viewport.minScale), Viewport.maxScale);
    this.ox = ax - wx * this.scale;
    this.oy = ay - wy * this.scale;
  }

  pan(dx: number, dy: number): void {
    this.ox += dx;
    this.oy += dy;
  }

  /** Fit a world rectangle into a view of the given size, centred, never magnifying beyond `maxFit`. */
  static fit(r: { x: number; y: number; width: number; height: number }, w: number, h: number, maxFit = 2.5): Viewport {
    if (r.width <= 0 || r.height <= 0 || w <= 0 || h <= 0) return new Viewport();
    const s = Math.min(w / r.width, h / r.height, maxFit);
    return new Viewport(s, (w - r.width * s) / 2 - r.x * s, (h - r.height * s) / 2 - r.y * s);
  }
}
