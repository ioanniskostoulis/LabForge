// Licensed under the GNU General Public License v2 or later. See LICENSE.
import type { SaveChoice, UnsavedChoice } from "./dialogs";

/** The lowest unused name among the document tabs currently open in this window. */
export function untitledName(documents: readonly { name: string }[]): string {
  const taken = new Set(documents.map((document) => document.name));
  let number = 1;
  while (taken.has(`Untitled ${number}`)) number++;
  return `Untitled ${number}`;
}

export interface OpenedDocumentFile { path: string; text: string }

/** Startup files take precedence over a URL example; an unreadable example leaves the welcome screen open. */
export async function initialDocumentFiles<Document>(options: {
  desktopFiles?: () => Promise<OpenedDocumentFile[]>;
  examplePath?: string | null;
  loadExample: (path: string) => Promise<Document>;
  fromDesktopFile: (file: OpenedDocumentFile) => Document;
}): Promise<Document[]> {
  const files = await options.desktopFiles?.() ?? [];
  if (files.length) return files.map(options.fromDesktopFile);
  if (options.examplePath) {
    try { return [await options.loadExample(options.examplePath)]; }
    catch { /* Keep the welcome screen available when an example cannot be loaded. */ }
  }
  return [];
}

/** Reopen an existing path in its tab; open only paths that are not already present. */
export function openDocumentFiles<Document extends { path: string | null }>(
  documents: readonly Document[], files: readonly OpenedDocumentFile[],
  activate: (document: Document) => void, create: (file: OpenedDocumentFile) => Document,
  open: (document: Document) => void,
): void {
  for (const file of files) {
    const existing = documents.find((document) => document.path === file.path);
    if (existing) activate(existing);
    else open(create(file));
  }
}

/** The document name and dirty mark live in the browser title; desktop chrome shows the product name. */
export function documentWindowTitle(product: string, document?: { dirty: boolean; displayTitle: string }): string {
  return document ? `${document.dirty ? "• " : ""}${document.displayTitle}: ${product}` : product;
}

/** Place New or Open immediately after the active tab, optionally replacing its sole blank tab. */
export function insertDocument<T>(documents: T[], active: T, incoming: T, replaceSoleBlank: boolean): void {
  if (replaceSoleBlank && documents.length === 1 && documents[0] === active) documents.splice(0, 1, incoming);
  else documents.splice(documents.indexOf(active) + 1, 0, incoming);
}

/** Remove a tab and choose the one now at its position, or the preceding last tab. */
export function removeDocument<T>(documents: T[], active: T, closing: T): { removed: boolean; active: T | null } {
  const index = documents.indexOf(closing);
  if (index < 0) return { removed: false, active };
  documents.splice(index, 1);
  return { removed: true, active: closing === active ? documents[Math.min(index, documents.length - 1)] ?? null : active };
}

export interface TabCloseOptions<Document extends { name: string }> {
  documents: Document[];
  active: Document;
  closing: Document;
  needsPrompt: (document: Document) => boolean;
  askToSave: (name: string) => Promise<SaveChoice>;
  save: (document: Document) => Promise<boolean>;
  activate: (document: Document) => void;
  dispose: (document: Document) => void;
  emptyDocument: () => Document;
  renderTabs: () => void;
  afterClose: () => void;
}

/** Close a document tab, keeping it open on a cancelled or failed save. */
export async function closeDocumentTab<Document extends { name: string }>(options: TabCloseOptions<Document>): Promise<boolean> {
  const { documents, closing } = options;
  let active = options.active;
  if (!documents.includes(closing)) return false;
  if (options.needsPrompt(closing)) {
    if (closing !== active) { options.activate(closing); active = closing; }
    const choice = await options.askToSave(closing.name);
    if (choice === "cancel" || (choice === "save" && !(await options.save(closing)))) return false;
  }
  const next = removeDocument(documents, active, closing);
  if (!next.removed) return false;
  options.dispose(closing);
  if (closing === active) options.activate(next.active ?? options.emptyDocument());
  else options.renderTabs();
  options.afterClose();
  return true;
}

export interface WindowCloseOptions<Document extends { dirty: boolean; displayTitle: string; path: string | null }> {
  documents: readonly Document[];
  askToSaveAll: (documents: { name: string; path: string | null }[]) => Promise<UnsavedChoice>;
  activate: (document: Document) => void;
  save: (document: Document) => Promise<boolean>;
  closeWindow: () => void;
  closeCancelled: () => void;
}

/** Resolve an unsaved window close, including partial save choices and failed saves. */
export async function confirmWindowClose<Document extends { dirty: boolean; displayTitle: string; path: string | null }>(options: WindowCloseOptions<Document>): Promise<void> {
  const unsaved = options.documents.filter((document) => document.dirty);
  if (!unsaved.length) return options.closeWindow();
  const { choice, save: chosen } = await options.askToSaveAll(unsaved.map((document) => ({ name: document.displayTitle, path: document.path })));
  if (choice === "cancel") return options.closeCancelled();
  if (choice === "save") {
    for (const index of chosen) {
      const document = unsaved[index];
      if (!document) continue;
      options.activate(document);
      if (!(await options.save(document))) return options.closeCancelled();
    }
  }
  options.closeWindow();
}
