// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** What the page needs from the desktop bridge; absent in a browser preview. */
export interface DesktopClassSource {
  platform: string;
  onFullScreen(listener: (on: boolean) => void): void;
}

/**
 * Set `desktop-mac` on macOS desktop and keep `full-screen` in step with the window. The toolbar reserves room for the
 * window buttons only while `full-screen` is off.
 */
export function applyDesktopClasses(desktop: DesktopClassSource | undefined, body: Pick<HTMLElement, "classList"> = document.body): void {
  body.classList.toggle("desktop-mac", desktop?.platform === "darwin");
  desktop?.onFullScreen((on) => body.classList.toggle("full-screen", on));
}
