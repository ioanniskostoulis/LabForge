// Licensed under the GNU General Public License v2 or later. See LICENSE.
/** A right-aligned list number followed by three spaces. */
export const listNumber = (n: number): string => `[${n}]`.padStart(6) + "   ";

export function numberedTable(headers: string[], entries: string[][], showHeaders = false): { headers: string[]; rows: string[][]; numbered: true } {
  return { headers: showHeaders ? ["", ...headers] : [],
    rows: entries.map((row, i) => [listNumber(i + 1), ...row]), numbered: true };
}

/** Resolve a one-based list choice with the same error wording across commands. */
export function numberedItem<T>(items: readonly T[], text: string, label: string): T {
  const number = /^\d+$/.test(text) ? Number(text) : NaN;
  if (!Number.isSafeInteger(number) || number < 1 || number > items.length) throw new Error(`${label}: no item numbered ${text}.`);
  return items[number - 1];
}
