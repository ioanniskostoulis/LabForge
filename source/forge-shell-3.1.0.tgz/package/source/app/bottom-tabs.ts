// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface BottomPane<Name extends string> {
  name: Name;
  element: HTMLElement;
  onSelect?: () => void;
}

/** Tab buttons, active marker and pane visibility. Apps supply pane behavior. */
export function createBottomTabs<Name extends string>(bar: HTMLElement, panes: readonly BottomPane<Name>[]): (name: Name) => void {
  bar.setAttribute("role", "tablist");
  bar.setAttribute("aria-label", "Panels");
  const indicator = document.createElement("span");
  indicator.className = "tab-indicator";
  indicator.setAttribute("aria-hidden", "true");
  let indicatorReady = false;
  function positionIndicator(): void {
    const active = bar.querySelector<HTMLElement>(".tab.active");
    if (!active) return;
    const tabRect = active.getBoundingClientRect();
    if (!tabRect.width) return;
    indicator.style.width = `${tabRect.width}px`;
    indicator.style.transform = `translateX(${tabRect.left - bar.getBoundingClientRect().left}px)`;
    if (!indicatorReady) {
      indicatorReady = true;
      requestAnimationFrame(() => indicator.classList.add("ready"));
    }
  }
  function select(name: Name): void {
    bar.querySelectorAll<HTMLElement>(".tab").forEach((tab) => {
      const active = tab.dataset.tab === name;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", String(active));
      tab.tabIndex = active ? 0 : -1;
    });
    bar.dataset.active = name;
    positionIndicator();
    for (const pane of panes) pane.element.hidden = pane.name !== name;
    panes.find((pane) => pane.name === name)?.onSelect?.();
  }
  for (const pane of panes) {
    if (!pane.element.id) pane.element.id = `forge-pane-${pane.name.toLowerCase().replace(/[^a-z0-9-]+/g, "-")}`;
    const button = Object.assign(document.createElement("button"), { className: "tab", textContent: pane.name });
    button.setAttribute("role", "tab");
    button.setAttribute("aria-controls", pane.element.id);
    button.dataset.tab = pane.name;
    button.addEventListener("click", () => select(pane.name));
    button.addEventListener("keydown", (event) => {
      const index = panes.indexOf(pane);
      const next = event.key === "ArrowRight" ? (index + 1) % panes.length
        : event.key === "ArrowLeft" ? (index - 1 + panes.length) % panes.length
        : event.key === "Home" ? 0 : event.key === "End" ? panes.length - 1 : -1;
      if (next < 0 || !panes.length) return;
      event.preventDefault();
      select(panes[next].name);
      bar.querySelectorAll<HTMLButtonElement>(".tab")[next]?.focus();
    });
    bar.append(button);
  }
  bar.append(indicator);
  new ResizeObserver(positionIndicator).observe(bar);
  return select;
}
