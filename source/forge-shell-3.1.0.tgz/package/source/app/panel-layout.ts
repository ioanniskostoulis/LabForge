// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface PanelLayoutSettings {
  showInspector: boolean;
  inspectorWidth: number;
  inspectorSide: "left" | "right";
  showBottomPanel: boolean;
  bottomPanelHeight: number;
}

export interface PanelLayoutOptions<T extends PanelLayoutSettings> {
  center: HTMLElement;
  inspector: HTMLElement;
  inspectorSplit: HTMLElement;
  bottom: HTMLElement;
  bottomSplit: HTMLElement;
  settings: T;
  defaults: Pick<T, "inspectorWidth" | "bottomPanelHeight">;
  save: (change: Partial<T>) => void;
  afterApply?: () => void;
}

/** How far past its minimum size a panel is dragged before it closes, in px. */
export const CLOSE_PAST = 96;
/** The largest bottom-panel height and inspector width, in px. The smallest are the defaults of the application. */
export const BOTTOM_MAX = 640;
export const INSPECTOR_MAX = 420;
// Central workspace left visible when a short window shrinks a bottom panel taller than its default, in px.
const CENTER_ROOM = 140;

/** A stored panel size kept within `min` (the default size) and `max`; anything unreadable gives `min`. */
export function panelSize(stored: number, min: number, max: number): number {
  return Number.isFinite(stored) ? Math.min(max, Math.max(min, stored)) : min;
}

/** The result of dragging a panel to `raw` px: its size kept within `min` and `max`, and whether it closes (dragged `CLOSE_PAST` past `min`). */
export function dragOutcome(raw: number, min: number, max: number, closePast = CLOSE_PAST): { size: number; close: boolean } {
  return { size: Math.min(max, Math.max(min, raw)), close: raw < min - closePast };
}

/**
 * Animated panel visibility and draggable sizes, independent of pane contents. A panel is never smaller than its
 * default size: dragging it smaller holds it there, and dragging `CLOSE_PAST` beyond closes it.
 */
export function createPanelLayout<T extends PanelLayoutSettings>(options: PanelLayoutOptions<T>): () => void {
  const { center, inspector, inspectorSplit, bottom, bottomSplit, settings, defaults, save } = options;
  const motions = new Map<HTMLElement, { visible: boolean; animation: Animation | null }>();
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  function layoutPanel(panel: HTMLElement, split: HTMLElement, visible: boolean, axis: "width" | "height", size: number): void {
    const target = `${size}px`;
    const motion = motions.get(panel);
    if (!motion || reducedMotion.matches) {
      motion?.animation?.cancel();
      panel.hidden = split.hidden = !visible;
      panel.inert = !visible;
      panel.style[axis] = target;
      panel.style.overflow = "";
      motions.set(panel, { visible, animation: null });
      return;
    }
    if (motion.visible === visible) {
      panel.style[axis] = target;
      return;
    }
    const from = panel.hidden ? 0 : panel.getBoundingClientRect()[axis];
    const fromOpacity = panel.hidden ? 0 : Number(getComputedStyle(panel).opacity);
    motion.animation?.cancel();
    panel.hidden = split.hidden = false;
    panel.inert = !visible;
    panel.style[axis] = visible ? target : "0px";
    panel.style.overflow = "hidden";
    const animation = panel.animate([
      { [axis]: `${from}px`, opacity: fromOpacity },
      { [axis]: visible ? target : "0px", opacity: visible ? 1 : 0 },
    ], { duration: 150, easing: "ease" });
    motions.set(panel, { visible, animation });
    animation.onfinish = () => {
      if (motions.get(panel)?.animation !== animation) return;
      panel.hidden = split.hidden = !visible;
      panel.style[axis] = target;
      panel.style.overflow = "";
      motions.set(panel, { visible, animation: null });
    };
  }
  function applyLayout(): void {
    settings.inspectorWidth = panelSize(settings.inspectorWidth, defaults.inspectorWidth, INSPECTOR_MAX);
    settings.bottomPanelHeight = panelSize(settings.bottomPanelHeight, defaults.bottomPanelHeight, BOTTOM_MAX);
    layoutPanel(inspector, inspectorSplit, settings.showInspector, "width", settings.inspectorWidth);
    // A short window shrinks a taller bottom panel to leave the center room, but never below its default height.
    const room = center.clientHeight - CENTER_ROOM;
    layoutPanel(bottom, bottomSplit, settings.showBottomPanel, "height", Math.min(settings.bottomPanelHeight, Math.max(defaults.bottomPanelHeight, room)));
    options.afterApply?.();
  }
  const dragSplit = (handle: HTMLElement, horizontal: boolean) => {
    handle.addEventListener("pointerdown", (e) => {
      handle.setPointerCapture(e.pointerId);
      const start = horizontal ? e.clientY : e.clientX;
      const startSize = horizontal ? settings.bottomPanelHeight : settings.inspectorWidth;
      const move = (ev: PointerEvent) => {
        const d = (horizontal ? ev.clientY : ev.clientX) - start;
        // Past the minimum the panel closes, as in other apps; dragging back reopens it at its last size.
        if (horizontal) {
          const { size, close } = dragOutcome(startSize - d, defaults.bottomPanelHeight, BOTTOM_MAX);
          settings.showBottomPanel = !close;
          if (!close) settings.bottomPanelHeight = size;
        } else {
          const { size, close } = dragOutcome(startSize + (settings.inspectorSide === "left" ? d : -d), defaults.inspectorWidth, INSPECTOR_MAX);
          settings.showInspector = !close;
          if (!close) settings.inspectorWidth = size;
        }
        applyLayout();
      };
      const up = () => {
        handle.removeEventListener("pointermove", move);
        handle.removeEventListener("pointerup", up);
        handle.removeEventListener("pointercancel", up);
        handle.removeEventListener("lostpointercapture", up);
        save({});
      };
      handle.addEventListener("pointercancel", up);
      handle.addEventListener("lostpointercapture", up);
      handle.addEventListener("pointermove", move);
      handle.addEventListener("pointerup", up);
    });
    handle.addEventListener("dblclick", () => {
      if (horizontal) save({ bottomPanelHeight: defaults.bottomPanelHeight } as Partial<T>);
      else save({ inspectorWidth: defaults.inspectorWidth } as Partial<T>);
      applyLayout();
    });
  };
  dragSplit(bottomSplit, true);
  dragSplit(inspectorSplit, false);
  applyLayout();
  window.addEventListener("resize", applyLayout);
  return applyLayout;
}
