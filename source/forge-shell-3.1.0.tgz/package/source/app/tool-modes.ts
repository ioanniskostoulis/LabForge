// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface ToolModeStrip {
  setSelected(id: string, selected: boolean): void;
  setMode(label: string): void;
}

/** The mode label: `verb object. Press Esc to finish`. */
export function modeLabel(verb: string, object: string): string {
  return `${verb} ${object}. Press Esc to finish`;
}

/** Optional module: exactly one active tool, a mode label, and Esc back to the neutral mode. */
export function createToolModes(strip: ToolModeStrip, onChange: (id: string | null) => void = () => {}, target: Pick<Document, "addEventListener"> = document) {
  let active: string | null = null;
  const set = (id: string | null, label = ""): void => {
    if (active) strip.setSelected(active, false);
    active = id;
    if (id) strip.setSelected(id, true);
    strip.setMode(id ? label : "");
    onChange(id);
  };
  target.addEventListener("keydown", (event) => { if ((event as KeyboardEvent).key === "Escape" && active) set(null); });
  return {
    get active(): string | null { return active; },
    activate(id: string, verb: string, object: string): void { set(id, modeLabel(verb, object)); },
    neutral(): void { set(null); },
  };
}
