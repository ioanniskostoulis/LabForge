// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** Choose one or more local files in the browser edition, leaving interpretation to the app. */
export function openBrowserFiles(accept: string, onFile: (file: File) => void | Promise<void>, multiple = true): void {
  const input = Object.assign(document.createElement("input"), { type: "file", accept, multiple });
  input.addEventListener("change", async () => {
    for (const file of Array.from(input.files ?? [])) await onFile(file);
  });
  input.click();
}
