// What a scroll means, the same on work surfaces and data views, by the established convention:
// a trackpad's two-finger scroll pans and its pinch zooms; a mouse wheel zooms at the pointer, a
// step per notch however fast it turns (⌘ or Ctrl + scroll zooms with either).
// Licensed under the GNU General Public License v2 or later. See LICENSE.

export type WheelIntent = { kind: "zoom"; factor: number } | { kind: "pan"; dx: number; dy: number };

/** Zoom per mouse-wheel notch. */
const NOTCH_ZOOM = 1.15;
/** Events closer than this are one gesture (its device is decided once, by its first event). */
const GESTURE_GAP_MS = 250;

let gesture = { at: -Infinity, trackpad: false };

/**
 * Is it a trackpad? Chromium and Safari give a trackpad scroll a legacy wheelDeltaY of exactly −3 ×
 * its deltaY; a mouse wheel's is in notches (±120 each) whatever macOS's acceleration does to
 * deltaY. A sideways component is a trackpad too (a mouse wheel has none, without Shift).
 */
function isTrackpad(e: WheelEvent): boolean {
  const legacy = (e as WheelEvent & { wheelDeltaY?: number }).wheelDeltaY;
  if (e.deltaX !== 0 && !e.shiftKey) return true;
  if (legacy) return legacy === -3 * e.deltaY;
  return e.deltaMode === 0;
}

/** What a wheel event asks for. */
export function wheelIntent(e: WheelEvent, wheelZooms: boolean): WheelIntent {
  // a pinch arrives as Ctrl + scroll; ⌘ / Ctrl + scroll zooms with a mouse too
  if (e.ctrlKey || e.metaKey) return { kind: "zoom", factor: Math.exp(-e.deltaY * 0.01) };
  const now = performance.now();
  if (now - gesture.at > GESTURE_GAP_MS) gesture.trackpad = wheelZooms ? false : isTrackpad(e);
  gesture.at = now;
  if (gesture.trackpad) return { kind: "pan", dx: e.deltaX, dy: e.deltaY };
  // Shift + wheel: sideways, as everywhere
  if (e.shiftKey) return { kind: "pan", dx: e.deltaX || e.deltaY, dy: 0 };
  // notches: from the legacy delta when there is one, else lines or pixels
  const legacy = (e as WheelEvent & { wheelDeltaY?: number }).wheelDeltaY;
  const notches = legacy ? legacy / 120 : e.deltaMode === 1 ? -e.deltaY / 3 : e.deltaMode === 2 ? -e.deltaY : -e.deltaY / 100;
  return { kind: "zoom", factor: Math.pow(NOTCH_ZOOM, Math.max(-6, Math.min(6, notches))) };
}
