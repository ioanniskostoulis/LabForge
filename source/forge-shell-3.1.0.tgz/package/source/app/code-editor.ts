// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The shared code editor: CodeMirror with the family's look. Syntax colours are the --syntax-* tokens, the selection is
// one rounded shape, the caret fades as it blinks and glides between positions, all of it off under reduced motion.
// CodeMirror is a peer dependency: an application that imports this module installs it; others never load it.
import { EditorSelection, EditorState, type Extension } from "@codemirror/state";
import { EditorView, drawSelection, highlightActiveLine, highlightActiveLineGutter, keymap, layer, lineNumbers, type LayerMarker } from "@codemirror/view";
import { HighlightStyle, bracketMatching, foldedRanges, indentOnInput, syntaxHighlighting } from "@codemirror/language";
import { defaultKeymap, history, historyKeymap, indentWithTab } from "@codemirror/commands";
import { tags, type Tag } from "@lezer/highlight";
import { joinBands, roundedPath, type LineRect } from "./selection-shape";

/** The syntax colours, one CSS class and one token each (`--syntax-<kind>`), in Dark and Light. */
export const SYNTAX_KINDS = ["keyword", "name", "string", "number", "comment", "type", "operator", "heading", "link", "invalid"] as const;
export type SyntaxKind = (typeof SYNTAX_KINDS)[number];

/** Which Lezer highlighting tags take which syntax colour. A language's own tags are mapped by the application. */
export const SYNTAX_TAGS: Record<SyntaxKind, readonly Tag[]> = {
  keyword: [tags.keyword, tags.controlKeyword, tags.definitionKeyword, tags.moduleKeyword, tags.modifier, tags.self, tags.null, tags.bool],
  name: [tags.function(tags.variableName), tags.function(tags.propertyName), tags.macroName, tags.className, tags.labelName, tags.tagName],
  string: [tags.string, tags.special(tags.string), tags.regexp, tags.character, tags.escape],
  number: [tags.number, tags.integer, tags.float, tags.unit, tags.atom, tags.constant(tags.name)],
  comment: [tags.comment, tags.lineComment, tags.blockComment, tags.docComment, tags.meta],
  type: [tags.typeName, tags.namespace, tags.attributeName, tags.annotation],
  operator: [tags.operator, tags.punctuation, tags.bracket, tags.separator],
  heading: [tags.heading, tags.strong],
  link: [tags.link, tags.url],
  invalid: [tags.invalid],
};

/** The highlight style of the shared editor: each tag of `SYNTAX_TAGS` gets the class `syntax-<kind>`, coloured by shell.css. */
export const shellHighlightStyle = HighlightStyle.define(SYNTAX_KINDS.flatMap((kind) => SYNTAX_TAGS[kind].map((tag) => ({ tag, class: `syntax-${kind}` }))));

/** The text of each selected range as one band per visual line; a selected empty line gets a 6 px stub. */
function selectionBands(view: EditorView): LineRect[] {
  const base = view.scrollDOM.getBoundingClientRect();
  const originX = base.left - view.scrollDOM.scrollLeft, originY = base.top - view.scrollDOM.scrollTop;
  const bands: LineRect[] = [];
  // Lines inside a fold are not drawn, so they get no band; a fold the selection reaches into is covered up to its marker.
  const folds: { from: number; to: number }[] = [];
  foldedRanges(view.state).between(0, view.state.doc.length, (from, to) => { folds.push({ from, to }); });
  for (const range of view.state.selection.ranges) {
    if (range.empty) continue;
    const first = Math.max(range.from, view.viewport.from), last = Math.min(range.to, view.viewport.to);
    for (let number = view.state.doc.lineAt(first).number; number <= view.state.doc.lineAt(last).number; number++) {
      const line = view.state.doc.line(number);
      if (folds.some((fold) => line.from > fold.from && line.from <= fold.to)) continue;
      const end = Math.min(range.to, line.to);
      let position = Math.max(range.from, line.from);
      const folded = folds.find((fold) => fold.from === line.to && range.to > fold.from);
      const before = bands.length;
      if (position === end) {
        const at = view.coordsAtPos(position, 1);
        if (at && line.length === 0) bands.push({ left: at.left - originX, right: at.left - originX + 6, top: at.top - originY, bottom: at.bottom - originY });
        continue;
      }
      while (position < end) {
        const edge = view.moveToLineBoundary(EditorSelection.cursor(position), true).head;
        const stop = Math.min(Math.max(edge, position + 1), end);
        const from = view.coordsAtPos(position, 1), to = view.coordsAtPos(stop, -1);
        if (from && to) bands.push({ left: from.left - originX, right: Math.max(to.right, from.left) - originX, top: from.top - originY, bottom: from.bottom - originY });
        position = stop;
      }
      const marker = folded && bands.length > before ? view.coordsAtPos(folded.to, -1) : null;
      if (marker) bands[bands.length - 1].right = Math.max(bands[bands.length - 1].right, marker.right - originX);
    }
  }
  return bands;
}

class SelectionShape implements LayerMarker {
  constructor(readonly left: number, readonly top: number, readonly width: number, readonly height: number, readonly path: string) {}
  eq(other: SelectionShape): boolean { return this.left === other.left && this.top === other.top && this.width === other.width && this.height === other.height && this.path === other.path; }
  draw(): HTMLElement {
    const root = document.createElement("div");
    root.className = "cm-selectionShape";
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.append(document.createElementNS("http://www.w3.org/2000/svg", "path"));
    root.append(svg);
    this.update(root);
    return root;
  }
  update(dom: HTMLElement): boolean {
    Object.assign(dom.style, { left: `${this.left}px`, top: `${this.top}px`, width: `${this.width}px`, height: `${this.height}px` });
    dom.querySelector("svg")!.setAttribute("viewBox", `0 0 ${this.width} ${this.height}`);
    dom.querySelector("path")!.setAttribute("d", this.path);
    return true;
  }
}

/** The selection as one rounded shape in `--selection`, with the shell's selection geometry (radius 4 px). */
export function roundedSelection(): Extension {
  return layer({
    above: false,
    class: "cm-selectionShapeLayer",
    update: (update) => update.docChanged || update.selectionSet || update.viewportChanged || update.geometryChanged || update.focusChanged,
    markers(view) {
      const bands = joinBands(selectionBands(view));
      if (!bands.length) return [];
      const left = Math.min(...bands.map((band) => band.left)), top = Math.min(...bands.map((band) => band.top));
      const right = Math.max(...bands.map((band) => band.right)), bottom = Math.max(...bands.map((band) => band.bottom));
      const moved = bands.map((band) => ({ left: band.left - left, right: band.right - left, top: band.top - top, bottom: band.bottom - top }));
      return [new SelectionShape(left, top, right - left, bottom - top, roundedPath(moved, 4))];
    },
  });
}

export interface CodeEditorOptions {
  parent: HTMLElement;
  doc?: string;
  /** The language support, such as `python()` or a `StreamLanguage`; plain text without it. */
  language?: Extension;
  /** Further extensions of the application, after the shared ones. */
  extensions?: Extension[];
  readOnly?: boolean;
  /** Called with the whole text after every change. */
  onChange?(text: string): void;
}

/**
 * The shared editor's extensions: line numbers, the active line, history, the rounded selection, bracket matching,
 * the syntax colours and the family's classes (`shell-editor`, which shell.css styles, and the smooth caret).
 */
export function codeEditorSetup(options: Pick<CodeEditorOptions, "readOnly" | "onChange"> = {}): Extension[] {
  return [
    lineNumbers(), highlightActiveLine(), highlightActiveLineGutter(), history(), drawSelection(), roundedSelection(),
    bracketMatching(), indentOnInput(), syntaxHighlighting(shellHighlightStyle),
    keymap.of([...defaultKeymap, ...historyKeymap, indentWithTab]),
    EditorView.editorAttributes.of({ class: "shell-editor" }),
    EditorState.readOnly.of(!!options.readOnly),
    EditorView.updateListener.of((update) => { if (update.docChanged) options.onChange?.(update.state.doc.toString()); }),
  ];
}

/** A shared editor in `parent`. */
export function createCodeEditor(options: CodeEditorOptions): EditorView {
  return new EditorView({
    parent: options.parent,
    state: EditorState.create({ doc: options.doc ?? "", extensions: [codeEditorSetup(options), options.language ?? [], options.extensions ?? []] }),
  });
}
