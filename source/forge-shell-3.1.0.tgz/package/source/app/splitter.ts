// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Two panes side by side or one above the other with a divider between them, such as an editor and its preview.

/** Each pane keeps at least this many px; the divider's visible line and its wider pointer target, in px. */
export const SPLIT_MIN = 160;
export const SPLIT_LINE = 1, SPLIT_HIT = 9;
/** One press of an arrow key on the focused divider moves it this share of the whole. */
export const SPLIT_KEY_STEP = 0.02;

/** The first pane's share of `total` px with the divider at `position` px, so that each pane keeps `min` px. */
export function splitShare(position: number, total: number, min = SPLIT_MIN): number {
  if (total <= 2 * min) return 0.5;
  return Math.min(total - min, Math.max(min, position)) / total;
}

export interface SplitterOptions {
  /** `x`: side by side, `y`: one above the other. */
  axis: "x" | "y";
  /** The first pane's share of the whole to start with, and the share a double click on the divider restores. */
  share: number;
  defaultShare?: number;
  min?: number;
  /** Called with the new share when a drag ends or a key moves the divider, to keep it. */
  onChange?(share: number): void;
}

/**
 * Lay `first` and `second` out in `container` with a divider: drag it, double-click it to restore the default, or
 * focus it and use the arrow keys. Returns the divider and a setter for the share.
 */
export function createSplitter(container: HTMLElement, first: HTMLElement, second: HTMLElement, options: SplitterOptions) {
  const min = options.min ?? SPLIT_MIN;
  const divider = document.createElement("div");
  divider.className = `splitter splitter-${options.axis}`;
  divider.tabIndex = 0;
  divider.setAttribute("role", "separator");
  divider.setAttribute("aria-orientation", options.axis === "x" ? "vertical" : "horizontal");
  container.classList.add("split", `split-${options.axis}`);
  container.replaceChildren(first, divider, second);
  let share = options.share;
  const size = () => (options.axis === "x" ? container.clientWidth : container.clientHeight);
  const apply = (next: number) => {
    share = Math.min(1, Math.max(0, next));
    first.style.flex = `0 0 ${(share * 100).toFixed(3)}%`;
    second.style.flex = "1 1 0";
    divider.setAttribute("aria-valuenow", String(Math.round(share * 100)));
  };
  apply(share);
  divider.addEventListener("pointerdown", (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    divider.setPointerCapture(event.pointerId);
    const box = container.getBoundingClientRect();
    const move = (moved: PointerEvent) => apply(splitShare(options.axis === "x" ? moved.clientX - box.left : moved.clientY - box.top, size(), min));
    const up = () => { divider.removeEventListener("pointermove", move); divider.removeEventListener("pointerup", up); options.onChange?.(share); };
    divider.addEventListener("pointermove", move);
    divider.addEventListener("pointerup", up);
  });
  divider.addEventListener("dblclick", () => { apply(options.defaultShare ?? options.share); options.onChange?.(share); });
  divider.addEventListener("keydown", (event) => {
    const back = options.axis === "x" ? "ArrowLeft" : "ArrowUp", forward = options.axis === "x" ? "ArrowRight" : "ArrowDown";
    if (event.key !== back && event.key !== forward) return;
    event.preventDefault();
    apply(splitShare((share + (event.key === forward ? SPLIT_KEY_STEP : -SPLIT_KEY_STEP)) * size(), size(), min));
    options.onChange?.(share);
  });
  return { divider, setShare: apply, share: () => share };
}
