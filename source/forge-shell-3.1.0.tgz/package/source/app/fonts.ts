// Licensed under the GNU General Public License v2 or later. See LICENSE.
/** The shared font stacks. They must equal `--ui` and `--mono` in `source/styles/tokens.css`; a conformance test checks this. */
export const FONT_UI = '-apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif';
export const FONT_MONO = 'ui-monospace, "SF Mono", SFMono-Regular, Menlo, "Cascadia Mono", Consolas, monospace';

/** Role fonts for canvas text: `ctx.font = roleFont("mono", 11)`. Sizes are in px. */
export function roleFont(family: "ui" | "mono", size: number, weight: 400 | 600 | 700 = 400): string {
  return `${weight === 400 ? "" : `${weight} `}${size}px ${family === "ui" ? FONT_UI : FONT_MONO}`;
}
