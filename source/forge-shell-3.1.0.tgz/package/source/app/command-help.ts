// Licensed under the GNU General Public License v2 or later. See LICENSE.

import type { CommandSpec } from "./command-spec";
import type { ConsoleResult } from "./terminal";

export interface HelpDetails {
  forms?: string[];
  notes?: string[];
  choices?: [string, string][];
  /** The choice used when the argument is omitted; its row ends with `(default)`. */
  defaultChoice?: string;
  example?: string;
}

export interface HelpCatalog {
  commands: readonly CommandSpec[];
  helpCommands: readonly CommandSpec[];
  availableOnWelcome: ReadonlySet<string>;
  details: Readonly<Record<string, HelpDetails>>;
  welcomeForms: Readonly<Record<string, { syntax: string; description: string }>>;
  welcomeTopics: Readonly<Record<string, string>>;
  groups: readonly (readonly [string, readonly string[]])[];
  /** Commands whose choice list is useful even when they have custom help forms. */
  alwaysChoices?: ReadonlySet<string>;
  noDocumentMessage: string;
}

/** Format one command's syntax, choices, notes and example from app-supplied data. */
export function commandHelp(topic: string, welcome: boolean, catalog: HelpCatalog): ConsoleResult {
  const name = topic.split(" ")[0];
  if (welcome) {
    const special = catalog.welcomeForms[name];
    if (special) return topic === name || topic === catalog.welcomeTopics[name]
      ? { lines: [{ label: special.syntax, comment: special.description, indent: 0, subdued: true }] }
      : { lines: [catalog.noDocumentMessage] };
    if (!catalog.availableOnWelcome.has(name)) return { lines: [catalog.noDocumentMessage] };
  }
  const entry = catalog.commands.find((command) => command.name === name);
  const forms = entry?.subcommands?.filter((form) => form.syntax === topic || form.syntax.startsWith(topic + " "));
  if (!entry || (topic !== name && !forms?.length)) return { lines: [`${topic}: no help available. Type help to list commands.`] };
  const info = catalog.details[topic] ?? {};
  const usage = info.forms ?? (forms?.length ? forms.map((form) => form.syntax) : [entry.syntax]);
  const choices = info.choices ?? (topic === name && !entry.subcommands && (!info.forms || catalog.alwaysChoices?.has(name))
    ? entry.choices?.filter((choice) => choice !== "help").map((choice): [string, string] => [choice, ""])
    : undefined);
  const example = info.example ?? (topic === name ? entry.example : undefined);
  const width = Math.max(...usage.map((form) => form.length));
  const choiceWidth = Math.max(0, ...(choices ?? []).map(([label]) => label.length));
  return { lines: [
    ...usage.map((label) => ({ label, comment: forms?.find((form) => form.syntax === label)?.description ?? (usage.length === 1 ? entry.description : ""), indent: 0, subdued: true, labelWidth: width })),
    ...(choices ?? []).map(([label, comment]) => ({ label, comment: label === info.defaultChoice ? `${comment ? `${comment} ` : ""}(default)` : comment, indent: 1, subdued: true, labelWidth: choiceWidth })),
    ...(info.notes ?? []).map((note) => ({ label: "", comment: note, indent: 0, subdued: true, labelWidth: 0 })),
    ...(example ? [{ label: "Example", comment: example, indent: 0, subdued: true, labelWidth: 0 }] : []),
  ] };
}

/** Format the grouped Help overview from the app's registry and group order. */
export function generalHelp(welcome: boolean, catalog: HelpCatalog): ConsoleResult {
  const byName = new Map(catalog.helpCommands.map((entry) => [entry.name, entry]));
  const listed = new Set(catalog.groups.flatMap(([, names]) => [...names]));
  const other = catalog.helpCommands.filter((entry) => !listed.has(entry.name)).map((entry) => entry.name);
  const order = (title: string): number => ({ File: 0, Edit: 1, View: 2, Console: 5 }[title] ?? 3);
  const ordered = [...catalog.groups, ...(other.length ? [["Other", other] as const] : [])]
    .map((group, index) => ({ group, index }))
    .sort((a, b) => order(a.group[0]) - order(b.group[0]) || a.index - b.index)
    .map(({ group }) => group);
  const groups = ordered.map(([title, names]) => ({
    title,
    items: [...names].sort().flatMap((name) => {
      if (welcome && catalog.welcomeForms[name]) return [{ label: name, comment: catalog.welcomeForms[name].description }];
      if (welcome && !catalog.availableOnWelcome.has(name)) return [];
      const entry = byName.get(name);
      return entry ? [{ label: entry.name, comment: entry.description }] : [];
    }),
  }));
  return { lines: ["help <command> for details. <value> required; [value] optional."], groups: groups.filter((group) => group.items.length) };
}

/** Bad syntax shows the valid forms, so the user does not have to ask for help. */
export function invalidUsage(entry: CommandSpec): ConsoleResult {
  const forms = entry.subcommands?.length ? entry.subcommands : [{ syntax: entry.syntax, description: entry.description }];
  const labelWidth = Math.max(...forms.map((form) => form.syntax.length));
  return { lines: [
    "Invalid arguments. Usage:",
    ...forms.map((form) => ({ label: form.syntax, comment: form.description, indent: 1, subdued: true, labelWidth })),
    `Type help ${entry.name} for details.`,
  ] };
}

/** `plot -h`, `plot --help` and `plot ?` mean `help plot`; `-h` and `--help` alone mean `help`. Returns null for any other input. */
export function helpAlias(input: string): string | null {
  const text = input.trim();
  if (/^(?:-h|--help)$/.test(text)) return "help";
  const match = /^(\S.*?)\s+(?:-h|--help|\?)$/.exec(text);
  return match ? `help ${match[1]}` : null;
}

/**
 * Check one syntax string against the help conventions: a lowercase verb, `<required>` and `[optional]`
 * placeholders in lowercase words, balanced brackets, and `...` only after a placeholder. Returns the problems found.
 */
export function checkCommandSyntax(syntax: string): string[] {
  const problems: string[] = [];
  const words = syntax.trim().split(/\s+/);
  if (!/^[a-z][a-z0-9-]*$/.test(words[0] ?? "")) problems.push(`${syntax}: the verb must be lowercase`);
  const depth = [...syntax].reduce((open, char) => (char === "[" || char === "<" ? open + 1 : char === "]" || char === ">" ? open - 1 : open), 0);
  if (depth !== 0) problems.push(`${syntax}: unbalanced brackets`);
  for (const match of syntax.matchAll(/<([^<>]*)>/g)) {
    if (!/^[a-z][a-z0-9]*(?:[ -][a-z0-9]+)*$/.test(match[1])) problems.push(`${syntax}: placeholder <${match[1]}> must be lowercase words`);
  }
  if (/(?<![>\]])\.\.\./.test(syntax)) problems.push(`${syntax}: "..." must follow a placeholder`);
  return problems;
}
