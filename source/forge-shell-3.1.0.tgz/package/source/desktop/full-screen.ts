// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** The parts of an Electron `BrowserWindow` that full-screen forwarding uses. */
export interface FullScreenWindow {
  isFullScreen(): boolean;
  on(event: "enter-full-screen" | "leave-full-screen", listener: () => void): unknown;
  webContents: { send(channel: string, ...args: unknown[]): void; on(event: "did-finish-load", listener: () => void): unknown };
}

/** Tell the page when its window enters or leaves full screen, and its state once loaded. The page listens through `onFullScreen`. */
export function forwardFullScreen(win: FullScreenWindow): void {
  const send = (on: boolean): void => win.webContents.send("fullScreen", on);
  win.on("enter-full-screen", () => send(true));
  win.on("leave-full-screen", () => send(false));
  win.webContents.on("did-finish-load", () => send(win.isFullScreen()));
}
