// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The window's top row. macOS keeps its native menu and draws the traffic lights over the tool strip; Windows hides
// its title bar, keeps its native minimise, maximise and close buttons, and the page draws the menu bar beside them.

/** Height of the drawn title bar on Windows, in px; the page's `#menubar.title-bar` has the same height. */
export const TITLE_BAR_HEIGHT = 32;
/** The colours of the Windows window controls: the drawn menu bar's background and the page's text. */
export interface TitleBarColors { color: string; symbolColor: string }
// Dark appearance until the page reports its own: `--raised` and `--text` of tokens.css.
export const DARK_TITLE_BAR: TitleBarColors = { color: "#303030", symbolColor: "#dadada" };
/** The window's background until the page paints (`--window` of tokens.css in Dark), for `BrowserWindow`'s `backgroundColor`. */
export const DARK_WINDOW_BACKGROUND = "#1e1e1e";

/** `BrowserWindow` options for the top row of a Forge window on `platform`. */
export function windowChrome(platform: string, colors: TitleBarColors = DARK_TITLE_BAR): Record<string, unknown> {
  if (platform === "darwin") return { titleBarStyle: "hidden", trafficLightPosition: { x: 16, y: 14 } };
  if (platform === "win32") return { titleBarStyle: "hidden", titleBarOverlay: { ...colors, height: TITLE_BAR_HEIGHT } };
  return {};
}

/** Whether the native application menu is installed: on Windows the page draws the menus instead. */
export function usesNativeMenu(platform: string): boolean {
  return platform !== "win32";
}

/** The parts of the main-process IPC and `BrowserWindow` that the title bar uses. */
export interface TitleBarIpc { on(channel: string, handler: (event: { sender: unknown }, ...args: any[]) => void): unknown }
export interface TitleBarWindow { setTitleBarOverlay?(options: TitleBarColors & { height?: number }): void }

const colour = (value: unknown): value is string => typeof value === "string" && /^(#[0-9a-f]{3,8}|rgba?\([\d\s.,%]+\))$/i.test(value.trim());

/** Recolour the Windows window controls when the page changes its appearance (`setTitleBar` from the bridge). */
export function registerTitleBarIpc(ipc: TitleBarIpc, windowFor: (event: { sender: unknown }) => TitleBarWindow | null): void {
  ipc.on("setTitleBar", (event, colors: Partial<TitleBarColors>) => {
    if (!colour(colors?.color) || !colour(colors?.symbolColor)) return;
    try { windowFor(event)?.setTitleBarOverlay?.({ color: colors.color, symbolColor: colors.symbolColor, height: TITLE_BAR_HEIGHT }); } catch { /* not a Windows window with controls */ }
  });
}
