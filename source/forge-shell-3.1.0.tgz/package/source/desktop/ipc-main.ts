// Licensed under the GNU General Public License v2 or later. See LICENSE.
import type { MenuNode } from "../app/menus";
import { DesktopWindowState } from "./window-state";

export interface ShellIpcEvent { sender: { id: number } }
export interface ShellIpcRegistry {
  on(channel: string, handler: (event: ShellIpcEvent, ...args: any[]) => void): unknown;
  handle(channel: string, handler: (event: ShellIpcEvent, ...args: any[]) => unknown): unknown;
}
export interface ShellWindow {
  setTitle(title: string): void;
  setDocumentEdited(edited: boolean): void;
  close(): void;
}
export interface ShellMainIpcOptions<File> {
  windows: DesktopWindowState<File>;
  windowFor(event: ShellIpcEvent): ShellWindow | null;
  focusedWindow(): ShellWindow | null;
  installMenu(menu: MenuNode[]): void;
  newWindow(): void;
  canWriteFile(event: ShellIpcEvent, path: string): boolean;
  writeFile(path: string, text: string): Promise<void>;
  /** Electron's `app.addRecentDocument`, for File › Open recent and the system's recent documents. */
  addRecentDocument?(path: string): void;
}

/** Register the main-process IPC shared by all Forge desktop apps. */
export function registerShellMainIpc<File>(ipc: ShellIpcRegistry, options: ShellMainIpcOptions<File>): void {
  const { windows } = options;
  ipc.handle("initialFiles", (event) => windows.takeStartupFiles(event.sender.id));
  ipc.on("setMenu", (event, nodes: MenuNode[]) => {
    const window = options.windowFor(event);
    if (!options.focusedWindow() || options.focusedWindow() === window) options.installMenu(nodes);
  });
  ipc.on("setTitle", (event, title: string) => options.windowFor(event)?.setTitle(title));
  ipc.on("setEdited", (event, value: boolean) => {
    windows.setEdited(event.sender.id, value);
    options.windowFor(event)?.setDocumentEdited(value);
  });
  ipc.on("newWindow", () => options.newWindow());
  ipc.on("closeWindow", (event) => {
    windows.confirmClose(event.sender.id);
    options.windowFor(event)?.close();
  });
  ipc.on("closeCancelled", () => windows.cancelQuit());
  ipc.on("addRecentDocument", (_event, path: unknown) => { if (typeof path === "string" && path) options.addRecentDocument?.(path); });
  ipc.handle("writeFile", (event, path: string, text: string) => {
    if (typeof path !== "string" || !path || typeof text !== "string" || !options.canWriteFile(event, path)) {
      throw new Error("Save permission required. Choose a path in the save dialog.");
    }
    return options.writeFile(path, text);
  });
}
