// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The record of a silent setup run: a plain-text log and Electron's local crash dumps, in one folder.
import { appendFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

// The folder of the log and the crash dumps, unless `FORGE_SETUP_LOG_DIR` names another.
export const LOG_DIR_VARIABLE = "FORGE_SETUP_LOG_DIR";

/** The folder for one family's setup logs and crash dumps: `<temp>\<family> setup`, or the folder in `FORGE_SETUP_LOG_DIR`. */
export function setupLogDir({ env = process.env, temp, family }) {
  return env[LOG_DIR_VARIABLE] || join(temp, `${family} setup`);
}

/** One log line: ISO time, then the text; an Error gives its stack and code. */
export function logLine(time, entry) {
  const text = entry instanceof Error ? `${entry.code ? `[${entry.code}] ` : ""}${entry.stack ?? entry.message}` : typeof entry === "string" ? entry : JSON.stringify(entry);
  return `${time.toISOString()} ${text}\n`;
}

/**
 * Open `<dir>\<id>-setup.log` for appending and return a writer. Each line is written synchronously,
 * so the lines before a native crash are on disk. A log that cannot be written never stops the setup.
 */
export function openSetupLog(dir, id, now = () => new Date()) {
  const path = join(dir, `${id}-setup.log`);
  try { mkdirSync(dir, { recursive: true }); } catch {}
  const write = (entry) => { try { appendFileSync(path, logLine(now(), entry)); } catch {} };
  return { path, write };
}
