// Licensed under the GNU General Public License v2 or later. See LICENSE.
// A Forge Terminal that installs. The banner stays; every command clears the screen under it and
// prints only what the user needs next. Details are available on request with `status`.
(() => {
  const api = window.setup;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const body = document.getElementById("screen");
  const stateEl = document.getElementById("state");
  const buttons = document.getElementById("buttons");
  let info = null;
  let phase = "idle"; // idle | running | done
  let installedNow = false;
  let ticker = 0;
  let run = null; // the install in progress: { p, tick, label, paint }

  const scr = Object.assign(document.createElement("div"), { id: "scr" });
  const pg = Object.assign(document.createElement("div"), { className: "pg" });
  pg.innerHTML = '<span class="pr">&gt;</span><input type="text" spellcheck="false" autocapitalize="off" autocomplete="off" aria-label="Setup command">';
  const input = pg.querySelector("input");
  const esc = (t) => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;");

  function line(text, cls = "") {
    const el = document.createElement("div");
    el.className = `l ${cls}${reduce ? "" : " fade"}`;
    el.textContent = text;
    scr.append(el);
    return el;
  }
  function html(markup, cls = "") {
    const el = document.createElement("div");
    el.className = `l ${cls}${reduce ? "" : " fade"}`;
    el.innerHTML = markup;
    scr.append(el);
    return el;
  }
  const gap = () => scr.append(Object.assign(document.createElement("div"), { className: "gap" }));
  const echo = (text) => html(`<i>&gt;</i> ${esc(text)}`, "c");
  function clear() {
    clearInterval(ticker);
    ticker = 0;
    scr.replaceChildren();
  }

  /* [=====|     ] : the = grows, the character at its end rotates. */
  const SPIN = ["|", "/", "-", "\\"];
  const WIDTH = 30;
  function bar(p, tick) {
    const filled = Math.min(WIDTH, Math.floor(p * WIDTH));
    const head = p >= 1 ? "" : reduce ? ">" : SPIN[tick % 4];
    const rest = " ".repeat(Math.max(0, WIDTH - filled - head.length));
    return `[<span class="on">${"=".repeat(filled)}${head}</span>${rest}]`;
  }

  function setFooter() {
    stateEl.textContent = phase === "running" ? "Installing" : phase === "done" ? "Done" : "Ready";
    if (phase === "running") buttons.innerHTML = '<button class="btn" data-c="cancel">Cancel</button>';
    else if (phase === "done") buttons.innerHTML = '<button class="btn" data-c="exit">Exit</button><button class="btn pri" data-c="open">Open</button>';
    else buttons.innerHTML = `<button class="btn" data-c="exit">Exit</button><button class="btn pri" data-c="install">${esc(readyVerb())}</button>`;
    pg.classList.toggle("off", phase === "running");
  }
  function readyVerb() {
    return info.plan.kind === "downgrade" ? "Replace" : info.plan.verb;
  }

  /** The ready screen: what this setup will do, and the one next step. */
  function ready() {
    clear();
    phase = "idle";
    const { kind, installed, incoming, blocked } = info.plan;
    const name = info.product;
    if (blocked) {
      line(`${name} is running.`, "w");
      gap();
      line("Close it, then press Enter.");
    } else if (kind === "downgrade") {
      line(`${name} ${installed} is newer than this setup.`, "w");
      gap();
      line("Type install force to replace it, or exit to close.");
    } else {
      if (kind === "repair") line(`${name} ${incoming} is already installed.`, "s");
      else if (kind === "upgrade") { line(`Upgrade ${name} from ${installed} to ${incoming}.`, "s"); line("Your circuits and settings stay as they are."); }
      else line(`${name} ${incoming} is ready to install.`, "s");
      gap();
      line(kind === "repair" ? "Type install to repair it, or exit to close." : "Type install to continue, or exit to close.");
    }
    setFooter();
  }

  function finished() {
    clear();
    phase = "done";
    installedNow = true;
    line(`${info.product} ${info.plan.incoming} is installed.`, "s");
    gap();
    line("Type open to start it, or exit to close.");
    setFooter();
    input.focus();
  }

  function problem(result) {
    clear();
    phase = "idle";
    const name = info.product;
    const text = {
      RUNNING: [`${name} is running.`, "Close it, then press Enter to try again.", "w"],
      BUSY: [`${name} is in use.`, "Close it, then press Enter to try again.", "w"],
      CHECKSUM: ["A file failed its check. Nothing was changed.", "Download the setup again, then run it.", "e"],
      NEWER: [`${name} is newer than this setup.`, "Type install force to replace it.", "w"],
      ABORT: ["Cancelled. Nothing was changed.", "Type install to try again, or exit to close.", "w"],
    }[result.code] ?? [`${result.message}`, "Nothing was changed. Type install to try again.", "e"];
    line(text[0], text[2]);
    gap();
    line(text[1]);
    setFooter();
  }

  async function install(force) {
    if (phase === "running") return;
    if (info.plan.blocked) {
      info = await api.state(); // the app may have been closed since setup started
      if (info.plan.blocked) { clear(); echo("install"); gap(); line(`${info.product} is running. Close it, then press Enter.`, "w"); return; }
    }
    if (info.plan.kind === "downgrade" && !force) {
      clear(); echo("install"); gap();
      line(`${info.product} ${info.plan.installed} is newer than this setup.`, "w");
      line("Type install force to replace it, or exit to close.");
      return;
    }
    clear();
    phase = "running";
    echo(force ? "install force" : "install");
    gap();
    line(`Installing ${info.product} ${info.plan.incoming}`, "s");
    const state = { p: 0, tick: 0, label: "Checking" };
    const row = html("", "bar");
    const paint = () => { row.innerHTML = `${bar(state.p, state.tick)} ${String(Math.round(state.p * 100)).padStart(3, " ")}%  ${esc(state.label)}`; };
    state.paint = paint;
    run = state;
    paint();
    ticker = setInterval(() => { state.tick++; paint(); }, 110);
    setFooter();
    const result = await api.install({ force });
    if (result.ok) {
      state.p = 1;
      state.label = "Done";
      paint();
      clearInterval(ticker);
      setTimeout(finished, reduce ? 0 : 500);
    } else {
      info = await api.state();
      problem(result);
      input.focus();
    }
  }

  function help() {
    clear();
    echo("help");
    gap();
    const rows = [["install", `${readyVerb()} ${info.product}`], ["open", `Start ${info.product}`], ["status", "Show details"], ["exit", "Close setup"]];
    for (const [verb, text] of rows) html(`<span class="vb">${verb.padEnd(10)}</span>${esc(text)}`);
  }

  function status() {
    clear();
    echo("status");
    gap();
    const { installed, incoming, keepsPrevious } = info.plan;
    line(`Installed   ${installed ?? "not installed"}`);
    line(`This setup  ${incoming}`);
    line(`Folder      ${info.installDir}`);
    if (keepsPrevious && installed) line(`Kept        ${installed} stays available to restore`);
  }

  async function exec(raw) {
    const text = raw.trim();
    if (!text) { if (phase === "idle") return install(false); return; }
    if (phase === "running") return;
    const [verb, arg] = text.toLowerCase().split(/\s+/);
    if (["install", "upgrade", "repair", "reinstall"].includes(verb)) return install(arg === "force");
    if (verb === "help") return help();
    if (verb === "status") { info = await api.state(); return status(); }
    if (verb === "clear") return phase === "done" ? finished() : ready();
    if (verb === "open") {
      clear(); echo("open"); gap();
      if (phase === "done" || installedNow) { line(`Starting ${info.product}...`, "s"); return api.open(); }
      line(`${info.product} is not installed yet. Type install first.`, "w");
      return;
    }
    if (verb === "exit" || verb === "quit") return api.close();
    if (verb === "theme") {
      clear(); echo(text); gap();
      if (["dark", "light", "pride"].includes(arg)) { document.body.dataset.theme = arg; line(`${arg[0].toUpperCase()}${arg.slice(1)} mode enabled.`); }
      else line("Invalid arguments. Type help theme for usage.");
      return;
    }
    clear(); echo(text); gap();
    line("Unknown command. Type help to list commands.", "w");
  }

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { const v = input.value; input.value = ""; void exec(v); }
    else if (e.key === "Escape") input.blur();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "c" && e.ctrlKey && phase === "running") { e.preventDefault(); api.cancel(); }
    else if (phase !== "running" && document.activeElement !== input && !e.ctrlKey && !e.metaKey && !e.altKey && e.key.length === 1) input.focus();
  });
  buttons.addEventListener("click", (e) => {
    const c = e.target.getAttribute?.("data-c");
    if (c === "cancel") api.cancel();
    else if (c === "exit") api.close();
    else if (c === "open") void exec("open");
    else if (c === "install") void exec("install");
  });
  document.getElementById("close").addEventListener("click", () => api.close());
  body.addEventListener("click", () => { if (!getSelection()?.toString()) input.focus(); });

  async function start() {
    info = await api.state();
    document.title = `${info.product} setup`;
    document.getElementById("title").textContent = `${info.product} setup`;
    document.body.dataset.theme = matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    const pre = Object.assign(document.createElement("pre"), { className: "wordmark", textContent: info.logo.replace(/\s+$/, "") });
    pre.setAttribute("aria-hidden", "true");
    const tag = Object.assign(document.createElement("div"), { className: "tag" });
    tag.innerHTML = `${esc(info.purpose)}   <b>setup v${esc(info.plan.incoming)}</b>`;
    body.replaceChildren(pre, tag, scr, pg);
    api.onEvent((e) => {
      if (!run) return;
      if (e.step === "unpack" && e.status === "start") run.label = "Unpacking files";
      else if (e.step === "unpack" && e.status === "done") run.label = "Finishing";
      else if (e.progress) run.p = e.progress.total ? e.progress.done / e.progress.total : 0;
      else if (e.step === "switch" && e.status === "done") { run.p = 1; run.label = "Done"; }
      run.paint();
    });
    ready();
    input.focus();
  }
  start();
})();
