// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Administrator rights for the setup. The executable is marked asInvoker, because Chromium starts its sandboxed
// helper processes (GPU, renderer) with a restricted token, and Windows refuses that for an executable marked
// requireAdministrator (error 740, ERROR_ELEVATION_REQUIRED). The setup instead starts a second, elevated copy of itself.

// Mandatory integrity levels of an elevated token: High and System.
export const ELEVATED_LEVELS = ["S-1-16-12288", "S-1-16-16384"];
// An elevated process started through User Account Control receives a fresh environment, so the variables the
// setup reads travel as one argument: base64url-encoded JSON.
export const ENV_ARGUMENT = "--forge-setup-env=";
// The exit code of a run in which the User Account Control prompt was declined: the code for Cancelled.
export const DECLINED = 5;

/** Does `whoami /groups` output show an elevated token? */
export function isElevated(groups) {
  return ELEVATED_LEVELS.some((sid) => groups.includes(sid));
}

/** The environment variables the setup reads: the portable wrapper's and every `FORGE_` one. */
export function forwardedEnv(env) {
  return Object.fromEntries(Object.entries(env).filter(([name]) => name.startsWith("FORGE_") || name.startsWith("PORTABLE_EXECUTABLE_")));
}

/** The argument that carries `forwardedEnv(env)` to the elevated copy. */
export function envArgument(env) {
  return `${ENV_ARGUMENT}${Buffer.from(JSON.stringify(forwardedEnv(env))).toString("base64url")}`;
}

/** Copy the forwarded variables into `env` and return the arguments without the carrier. */
export function restoreEnv(argv, env) {
  const carrier = argv.find((arg) => arg.startsWith(ENV_ARGUMENT));
  if (carrier) Object.assign(env, JSON.parse(Buffer.from(carrier.slice(ENV_ARGUMENT.length), "base64url").toString("utf8")));
  return argv.filter((arg) => arg !== carrier);
}

/**
 * The PowerShell script that starts `exe` elevated with `args`, waits, and exits with its exit code,
 * or with `DECLINED` when the prompt is declined. Single quotes are doubled inside PowerShell literals.
 */
export function elevationScript(exe, args) {
  const literal = (text) => `'${text.replaceAll("'", "''")}'`;
  const line = args.map((arg) => (/[\s"]/.test(arg) ? `"${arg.replaceAll('"', '\\"')}"` : arg)).join(" ");
  return [
    "$ErrorActionPreference = 'Stop'",
    `try { $p = Start-Process -FilePath ${literal(exe)} -ArgumentList ${literal(line)} -Verb RunAs -Wait -PassThru } catch { exit ${DECLINED} }`,
    "if ($null -eq $p.ExitCode) { exit 1 }",
    "exit $p.ExitCode",
  ].join("\n");
}

/** `-EncodedCommand` takes the script as base64 of its UTF-16LE text, which needs no quoting. */
export function encodedCommand(script) {
  return Buffer.from(script, "utf16le").toString("base64");
}

/** The environment for the installed app: the setup's own variables removed, so the app does not start as a setup. */
export function appEnvironment(env) {
  return Object.fromEntries(Object.entries(env).filter(([name]) => !name.startsWith("FORGE_SETUP") && !name.startsWith("PORTABLE_EXECUTABLE_")));
}
