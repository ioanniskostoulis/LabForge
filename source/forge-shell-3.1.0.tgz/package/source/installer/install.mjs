// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { mkdir, readdir, rm, rmdir } from "node:fs/promises";
import { dirname, join } from "node:path";
import { installLayout } from "./layout.mjs";
import { copyPayload } from "./payload.mjs";
import { decideInstall } from "./plan.mjs";
import { readRegistry, writeRegistry } from "./registry.mjs";
import { swapIn } from "./swap.mjs";

/** Read what is installed and what installing would do, without changing anything. */
export async function inspectInstall({ root, product, id, incoming, running = false, family }) {
  const layout = installLayout(root, product, family);
  const registry = await readRegistry(layout.registry);
  const installed = registry.apps[id]?.version ?? null;
  return { layout, installed, plan: decideInstall({ installed, incoming, running }) };
}

/**
 * Check, unpack and verify, then switch. Events: { step, status, detail } and { progress }.
 * Errors carry a code: RUNNING, NEWER, CHECKSUM, BUSY, SWITCH, ABORT.
 */
export async function runInstall({ root, product, id, version, source, manifest, running = false, force = false, onEvent = () => {}, signal, family }) {
  const { layout, installed, plan } = await inspectInstall({ root, product, id, incoming: version, running, family });
  onEvent({ step: "check", status: "done", detail: installed ? `${installed} found` : "not installed" });
  if (plan.blocked) throw Object.assign(new Error(`${product} is running. Close it, then try again.`), { code: "RUNNING" });
  if (plan.kind === "downgrade" && !force) throw Object.assign(new Error(`${product} ${installed} is newer than this setup (${version}).`), { code: "NEWER" });

  await rm(layout.staging, { recursive: true, force: true });
  await mkdir(layout.staging, { recursive: true });
  onEvent({ step: "unpack", status: "start", detail: { files: manifest.files.length, bytes: manifest.bytes } });
  try {
    await copyPayload({ source, manifest, destination: layout.staging, signal, onProgress: (progress) => onEvent({ progress }) });
  } catch (error) {
    await rm(layout.staging, { recursive: true, force: true });
    if (error?.name === "AbortError" || error?.code === "ABORT_ERR") throw Object.assign(new Error("Cancelled."), { code: "ABORT" });
    throw error;
  }
  onEvent({ step: "unpack", status: "done", detail: `${manifest.files.length} files match their SHA-256` });

  onEvent({ step: "switch", status: "start", detail: plan.keepsPrevious ? `${installed} is kept in .previous` : "" });
  const { previous } = await swapIn({ layout, oldVersion: installed, keepPrevious: plan.keepsPrevious });
  const registry = await readRegistry(layout.registry);
  registry.apps[id] = { name: product, version, path: layout.app, previous, installedAt: new Date().toISOString() };
  await writeRegistry(layout.registry, registry);
  onEvent({ step: "switch", status: "done", detail: version });
  return { layout, kind: plan.kind, previous, installed };
}

/**
 * Remove the app, its kept version and its staging leftovers, and the family's shared files once no app is left.
 * User data lives outside the family folder and is left alone. Only this product's entries in `.previous` go.
 */
export async function runUninstall({ root, product, id, family }) {
  const layout = installLayout(root, product, family);
  const registry = await readRegistry(layout.registry);
  await rm(layout.app, { recursive: true, force: true });
  for (const entry of await readdir(layout.previous).catch(() => [])) if (entry.startsWith(`${product}-`)) await rm(join(layout.previous, entry), { recursive: true, force: true });
  await rm(layout.staging, { recursive: true, force: true });
  await rm(layout.trash, { recursive: true, force: true });
  delete registry.apps[id];
  if (Object.keys(registry.apps).length) await writeRegistry(layout.registry, registry);
  else await rm(layout.registry, { force: true });
  // Remove folders that are now empty; a folder that still holds another app's files stays.
  for (const folder of [layout.previous, dirname(layout.staging), layout.family]) await rmdir(folder).catch(() => {});
  return { layout };
}
