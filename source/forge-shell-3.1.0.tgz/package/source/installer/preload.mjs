// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("setup", {
  state: () => ipcRenderer.invoke("setup:state"),
  install: (options) => ipcRenderer.invoke("setup:install", options),
  cancel: () => ipcRenderer.send("setup:cancel"),
  open: () => ipcRenderer.send("setup:open"),
  close: () => ipcRenderer.send("setup:close"),
  onEvent: (callback) => { ipcRenderer.on("setup:event", (_event, data) => callback(data)); },
});
