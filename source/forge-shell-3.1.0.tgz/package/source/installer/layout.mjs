// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { join } from "node:path";

/** The default family folder name, shared by the install folder, the publisher and the registry keys. */
export const DEFAULT_FAMILY = "Forge";

/** Every path the installer touches, under one family folder. User data is never inside it. */
export function installLayout(root, product, family = DEFAULT_FAMILY) {
  const base = join(root, family);
  return {
    family: base,
    app: join(base, product),
    previous: join(base, ".previous"),
    staging: join(base, ".staging", product),
    trash: join(base, ".staging", `${product}-old`),
    registry: join(base, "installed.json"),
  };
}
