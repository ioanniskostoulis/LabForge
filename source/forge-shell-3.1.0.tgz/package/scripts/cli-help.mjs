// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** Help for the `forge-shell` command, written to the command-line help rules in GUIDELINES.md section 7. */
export const helpText = `Build and check tools for a Forge app, from the shared forge-shell package.

Usage: forge-shell command [options]

Commands:
  check-app                 Check the built app against its profile and the installed shell.
  workflows [--out dir]     Write the four build workflows of the app into .github/workflows.
  licenses                  Print the licence text of every production dependency; fails if one has none.
  release-notes             Print the CHANGELOG.md section of the version in VERSION; fails if there is none.
  package-config            Write build/electron-builder.json from forge.config.json.
  dmg-background [--force]  Draw the macOS disk image window into build/dmg; skipped on other systems.
  wordmark [name] [--out f] Print the text wordmark of the app (or name); --out writes it, as to assets/logo.txt.
  new-app Name [options]    Create a complete empty app in a new folder (default: ./Name).
  brand-css                 Write build/app/forge-brand.css from the profile's theme.
  installer [options]       Stage the Windows setup around an unpacked desktop build.

Options for installer:
  --payload dir             Unpacked desktop build to package (default: build/release/win-unpacked).
  --out dir                 Folder for the setup (default: build/release).
  --stage-only              Stage the files without building the executable.

Options for new-app:
  --ext ext                 Document extension (default: first letter of the name and fg, such as pfg).
  --accent #rrggbb          The one accent colour; the five Dark accents are derived from it (default: #3fae6a).
  --purpose text            What the app is for, as in its About window (default: Name workspace).
  --author name             Copyright holder and package author.
  --port number             Port of the browser preview (default: derived from the name).
  --repo owner/name         Public GitHub repository whose releases Check for updates reads.
  --shell spec              The forge-shell dependency (default: file:source/forge-shell-<version>.tgz).
  --out dir                 Folder to create; it must be new or empty.

Options:
  -h, --help                Show this help.

Environment:
  FORGE_STYLE_LINT=error    Make style lint problems in check-app fail (default: warnings only).

Run from the app's root, where forge.config.json is, except new-app. More detail: documentation/GUIDELINES.md, section 7.
`;
