// Serves build/app for development at the port in forge.config.json.
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { readFileSync } from "node:fs";
import { extname, join, normalize } from "node:path";

const root = "build/app";
const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json",
  ".txt": "text/plain; charset=utf-8", ".png": "image/png", ".map": "application/json", ".svg": "image/svg+xml",
  ".xml": "application/xml" };
const config = JSON.parse(readFileSync("forge.config.json", "utf8"));
const port = Number(process.env.PORT ?? config.identity.port);
const updatesPath = `/__${config.identity.id}_updates`;
const reloadPrompt = JSON.stringify(`${config.identity.name} was updated. Reload now? Unsaved edits will be lost.`).replaceAll("<", "\\u003c");

export function startServer({ liveReload = false, resolveFile } = {}) {
  const clients = new Set();
  // Builds wipe build/app. Keep serving static source files and the last served bundles
  // during that window, rather than replacing the user's preview with a 404.
  const lastGood = new Map();
  const staticFiles = {
    "/icon.png": "assets/icon.png", "/logo.txt": "assets/logo.txt", "/LICENSE": "LICENSE",
    "/CHANGELOG.md": "CHANGELOG.md", "/NOTICE.md": "NOTICE.md",
  };
  const server = createServer(async (req, res) => {
  if (liveReload && req.url === updatesPath) {
    res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-store", connection: "keep-alive" });
    res.write(": connected\n\n");
    clients.add(res);
    req.on("close", () => clients.delete(res));
    return;
  }
  let path;
  try { path = normalize(decodeURIComponent(new URL(req.url, "http://x").pathname)).replace(/^(\.\.[/\\])+/, ""); }
  catch { res.writeHead(400).end("bad request"); return; }
  const file = resolveFile?.(path) ?? join(root, path.endsWith("/") ? path + "index.html" : path);
  try {
    let body;
    try {
      body = await readFile(file);
      lastGood.set(file, body);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      if (lastGood.has(file)) body = lastGood.get(file);
      else body = await readFile(staticFiles[path] ?? join("public", path.endsWith("/") ? path + "index.html" : path));
    }
    if (liveReload && extname(file) === ".html") {
      body = Buffer.from(body.toString().replace("</body>", `<script>
        new EventSource('${updatesPath}').addEventListener('update', () => {
          if (document.querySelector('.doc-tab.dirty')) {
            if (!confirm(${reloadPrompt})) return;
          }
          location.reload();
        });
      </script></body>`));
    }
    res.writeHead(200, { "content-type": types[extname(file)] ?? "application/octet-stream", "cache-control": "no-store" });
    res.end(body);
  } catch {
    res.writeHead(404).end("not found");
  }
  });
  server.listen(port, "127.0.0.1", () => console.log(`${config.identity.name} web: http://127.0.0.1:${port}/`));
  return { server, reload: () => { for (const client of clients) client.write("event: update\ndata: ready\n\n"); } };
}
