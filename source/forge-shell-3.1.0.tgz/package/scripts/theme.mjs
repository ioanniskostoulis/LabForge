// Licensed under the GNU General Public License v2 or later. See LICENSE.
const names = {
  accent: "--accent",
  accentLight: "--accent-light",
  accentAbout: "--accent-about",
  accentFill: "--accent-fill",
  accentHover: "--accent-hover",
};

function luminance(hex) {
  const channels = hex.slice(1).match(/../g).map((part) => parseInt(part, 16) / 255);
  const [r, g, b] = channels.map((value) => value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrastRatio(first, second) {
  const values = [luminance(first), luminance(second)].sort((a, b) => b - a);
  return (values[0] + 0.05) / (values[1] + 0.05);
}

/**
 * Fill in the accents an app leaves out. In Dark, `accentLight` and `accentAbout` default to `accent`. Light is the calmer
 * appearance: unless the app specifies it, every Light accent is the Dark fill and the Light hover is the Dark hover.
 */
export function resolveTheme(theme) {
  const dark = { ...theme?.dark };
  dark.accentLight ??= dark.accent;
  dark.accentAbout ??= dark.accent;
  const light = { accent: dark.accentFill, accentLight: dark.accentFill, accentAbout: dark.accentFill, accentFill: dark.accentFill, accentHover: dark.accentHover, ...theme?.light };
  return { dark, light };
}

/** Reject accents that lose text readability on the shared neutral surfaces. */
export function checkBrandAccents(input) {
  const theme = resolveTheme(input);
  for (const mode of ["dark", "light"]) {
    const colors = theme?.[mode];
    for (const key of Object.keys(names)) {
      if (!/^#[0-9a-fA-F]{6}$/.test(colors?.[key] ?? "")) throw new Error(`theme.${mode}.${key} must be a six-digit hex color`);
    }
    const well = mode === "dark" ? "#1b1b1b" : "#f8f8f7";
    for (const key of ["accent", "accentLight", "accentAbout"]) {
      if (contrastRatio(colors[key], well) < 4.5) throw new Error(`theme.${mode}.${key} needs 4.5:1 contrast on the shared input surface`);
    }
    for (const key of ["accentFill", "accentHover"]) {
      if (contrastRatio(colors[key], "#ffffff") < 4.5) throw new Error(`theme.${mode}.${key} needs 4.5:1 contrast with white control labels`);
    }
  }
}

/** Each app supplies only its five brand accents; neutral and Pride tokens stay shared. */
export function brandCss(input) {
  checkBrandAccents(input);
  const theme = resolveTheme(input);
  const block = (selector, colors) => `${selector} {\n${Object.entries(names).map(([key, name]) => `  ${name}: ${colors[key]};`).join("\n")}\n}\n`;
  return `${block(":root", theme.dark)}\n${block('body[data-theme="light"]', theme.light)}`;
}

// MARK: accents from one hue

const hexToHsl = (hex) => {
  const [r, g, b] = hex.slice(1).match(/../g).map((part) => parseInt(part, 16) / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min;
  if (!d) return [0, 0, l];
  const s = d / (1 - Math.abs(2 * l - 1));
  const h = max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [(h * 60 + 360) % 360, s, l];
};
const hslToHex = (h, s, l) => {
  const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = l - c / 2;
  const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
  return `#${[r, g, b].map((v) => Math.round((v + m) * 255).toString(16).padStart(2, "0")).join("")}`;
};
/** The colour of `hue` and `saturation` with the lightness nearest `from`, in the direction `step`, that meets `ok`. */
const searchLightness = (h, s, from, step, ok) => {
  for (let l = from; l >= 0 && l <= 1; l += step) { const hex = hslToHex(h, s, l); if (ok(hex)) return hex; }
  return hslToHex(h, s, step > 0 ? 1 : 0);
};

/**
 * The five Dark accents of an application from one colour, as `brandCss` requires them: `accent` and `accentLight`
 * are the colour lightened until it has 4.5:1 on the input surface (#1b1b1b); `accentAbout` is 6 % lighter still;
 * `accentFill` is darkened until white labels on it, and it on the Light input surface (#f8f8f7), have 4.5:1; `accentHover` is 6 % darker than the fill. Light takes
 * the shell's defaults from these (`resolveTheme`).
 */
export function deriveAccents(colour) {
  if (!/^#[0-9a-fA-F]{6}$/.test(colour)) throw new Error(`An accent is a six-digit hex colour, not "${colour}".`);
  const [h, s, l] = hexToHsl(colour.toLowerCase());
  const margin = 4.6; // a little above 4.5, so that rounding to whole channels never falls below it
  const accent = searchLightness(h, s, l, 0.005, (hex) => contrastRatio(hex, "#1b1b1b") >= margin);
  const [, , accentL] = hexToHsl(accent);
  const accentAbout = hslToHex(h, s, Math.min(0.92, accentL + 0.06));
  // The fill also serves as the Light accent, on the Light input surface (#f8f8f7), which is a little stricter than white.
  const accentFill = searchLightness(h, s, Math.min(l, 0.5), -0.005, (hex) => contrastRatio(hex, "#ffffff") >= margin && contrastRatio(hex, "#f8f8f7") >= margin);
  const [, , fillL] = hexToHsl(accentFill);
  const accentHover = hslToHex(h, s, Math.max(0.05, fillL - 0.06));
  const theme = { dark: { accent, accentLight: accent, accentAbout, accentFill, accentHover } };
  checkBrandAccents(theme);
  return theme;
}
