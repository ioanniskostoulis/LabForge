#!/usr/bin/env node
// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Release forge-shell and pin the new archive in the apps listed in `release.local.json` (not committed).
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { copyFileSync, cpSync, existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

const usage = `Release forge-shell and pin it in the apps.

Usage: npm run release -- <version> [options]

Options:
  --message <text>   Commit message body (default: none).
  --no-push          Commit and tag, but do not push.
  --dry-run          Print what would happen and change nothing.
  -h, --help         Show this help.

Setup: release.local.json (not committed) lists the apps:
  { "apps": [ { "path": "../AppOne", "commit": true, "push": true, "docs": ["documentation/INTERFACE.md"] } ] }
An app with "commit": false only gets its files updated. "docs" are files where the old version is replaced.
The CHANGELOG must have an "## Unreleased" section; it becomes "## <version>".
`;

export const semver = /^\d+\.\d+\.\d+$/;
export const greater = (a, b) => { const [x, y] = [a, b].map((v) => v.split(".").map(Number)); return x[0] - y[0] || x[1] - y[1] || x[2] - y[2]; };

/** Set the version in package.json text (the first `"version"` field). */
export const setPackageVersion = (text, version) => text.replace(/"version": "[^"]+"/, `"version": "${version}"`);
/** Set both version fields at the top of a package-lock.json text. */
export const setLockVersion = (text, version) => { let n = 0; return text.replace(/"version": "[^"]+"/g, (m) => (n++ < 2 ? `"version": "${version}"` : m)); };
/** Turn the Unreleased changelog heading into the version heading. */
export function stampChangelog(text, version) {
  if (!/^## Unreleased$/m.test(text)) throw new Error('CHANGELOG.md has no "## Unreleased" section.');
  return text.replace(/^## Unreleased$/m, `## ${version}`);
}
/** Point an app's package.json or lockfile at the new archive. */
export const repinArchive = (text, version) => text.replace(/forge-shell-\d+\.\d+\.\d+\.tgz/g, `forge-shell-${version}.tgz`);
/** Set the version and integrity of the installed forge-shell entry in a lockfile. */
export function repinLockEntry(text, version, integrity) {
  const pattern = /("node_modules\/forge-shell": \{\s*"version": )"[^"]+"(,\s*"resolved": "file:source\/forge-shell-[\d.]+\.tgz",\s*"integrity": )"[^"]+"/;
  if (!pattern.test(text)) throw new Error("The lockfile has no forge-shell archive entry.");
  return text.replace(pattern, (_m, a, b) => `${a}"${version}"${b}"${integrity}"`);
}

const run = (command, args, cwd, quiet = false) => execFileSync(command, args, { cwd, encoding: "utf8", stdio: quiet ? ["ignore", "pipe", "pipe"] : ["ignore", "inherit", "inherit"] });
const step = (text) => console.log(`\n== ${text}`);

export function release(argv = process.argv.slice(2)) {
  if (argv.includes("-h") || argv.includes("--help")) return console.log(usage);
  const version = argv.find((a) => semver.test(a));
  const dry = argv.includes("--dry-run");
  const push = !argv.includes("--no-push");
  const message = argv.includes("--message") ? argv[argv.indexOf("--message") + 1] : "";
  if (!version) { console.error(`Missing or invalid version.\n\n${usage}`); process.exitCode = 2; return; }
  const root = resolve(".");
  const read = (path) => readFileSync(join(root, path), "utf8");
  const write = (path, text) => { if (!dry) writeFileSync(join(root, path), text); };
  const current = read("VERSION").trim();
  if (greater(version, current) <= 0) throw new Error(`${version} must be greater than the current version ${current}.`);
  if (run("git", ["branch", "--show-current"], root, true).trim() !== "main") throw new Error("Release from the main branch.");
  if (run("git", ["tag", "--list", `v${version}`], root, true).trim()) throw new Error(`Tag v${version} already exists.`);
  const configPath = join(root, "release.local.json");
  const apps = existsSync(configPath) ? JSON.parse(readFileSync(configPath, "utf8")).apps ?? [] : [];

  step(`Set version ${current} -> ${version}`);
  // Every new text is computed before any file is written, so that a failure leaves the tree unchanged.
  const changelog = stampChangelog(read("CHANGELOG.md"), version);
  const packageText = setPackageVersion(read("package.json"), version);
  const lockText = setLockVersion(read("package-lock.json"), version);
  write("VERSION", `${version}\n`);
  write("package.json", packageText);
  write("package-lock.json", lockText);
  write("CHANGELOG.md", changelog);
  if (dry) { console.log("Dry run: would check, test, commit, tag, push, pack and pin."); for (const app of apps) console.log(`  pin ${app.path} (commit: ${!!app.commit}, push: ${!!app.push})`); return; }

  step("Check and test");
  run("npm", ["run", "check"], root);
  run("npm", ["test"], root);
  const pkg = JSON.parse(read("package.json"));
  const lock = JSON.parse(read("package-lock.json"));
  if (![pkg.version, lock.version, lock.packages[""].version].every((v) => v === version)) throw new Error("Version fields disagree.");

  step("Commit and tag");
  run("git", ["add", "-A"], root);
  run("git", ["commit", "-q", "-m", `chore: release forge-shell ${version}${message ? `\n\n${message}` : ""}`], root);
  run("git", ["tag", `v${version}`], root);
  if (push) run("git", ["push", "origin", "main", `v${version}`], root);

  step("Pack from a clean checkout of the tag");
  const work = mkdtempSync(join(tmpdir(), "forge-release-"));
  run("git", ["clone", "-q", "--branch", `v${version}`, root, join(work, "src")], root, true);
  run("npm", ["pack", "--pack-destination", work], join(work, "src"), true);
  const archive = join(work, `forge-shell-${version}.tgz`);
  const integrity = `sha512-${createHash("sha512").update(readFileSync(archive)).digest("base64")}`;
  const unpacked = join(work, "unpacked");
  run("mkdir", ["-p", unpacked], root, true);
  run("tar", ["-xzf", archive, "-C", unpacked], root, true);

  for (const app of apps) {
    step(`Pin ${app.path}`);
    const dir = resolve(root, app.path);
    if (app.commit && run("git", ["status", "--porcelain"], dir, true).trim()) { console.error(`  ${app.path} has uncommitted changes; not pinning it. Commit or stash them and pin it by hand.`); continue; }
    for (const old of readdirSync(join(dir, "source")).filter((f) => /^forge-shell-\d+\.\d+\.\d+\.tgz$/.test(f))) rmSync(join(dir, "source", old));
    copyFileSync(archive, join(dir, "source", `forge-shell-${version}.tgz`));
    const edit = (file, fn) => writeFileSync(join(dir, file), fn(readFileSync(join(dir, file), "utf8")));
    edit("package.json", (t) => repinArchive(t, version));
    edit("package-lock.json", (t) => repinLockEntry(repinArchive(t, version), version, integrity));
    for (const doc of app.docs ?? []) edit(doc, (t) => t.replaceAll(`v${current}`, `v${version}`).replace(/forge-shell-\d+\.\d+\.\d+\.tgz/g, `forge-shell-${version}.tgz`));
    rmSync(join(dir, "node_modules", "forge-shell"), { recursive: true, force: true });
    cpSync(join(unpacked, "package"), join(dir, "node_modules", "forge-shell"), { recursive: true });
    // The four build workflows come from the installed shell, so they stay in step with its pin.
    if (app.workflows !== false) run("node", [join("node_modules", "forge-shell", "scripts", "forge-shell.mjs"), "workflows"], dir, true);
    if (app.commit) {
      run("git", ["add", "-A"], dir);
      run("git", ["commit", "-q", "-m", `chore: pin forge-shell ${version}`], dir);
      if (app.push) run("git", ["push", "origin", "HEAD"], dir);
    }
    console.log(`  pinned ${version}${app.commit ? " and committed" : " (files only)"}${app.commit && app.push ? " and pushed" : ""}`);
  }
  rmSync(work, { recursive: true, force: true });
  console.log(`\nReleased forge-shell ${version}.`);
}

if (process.argv[1] && resolve(process.argv[1]) === new URL(import.meta.url).pathname) {
  try { release(); } catch (error) { console.error(`\nRelease stopped: ${error.message}`); process.exitCode = 1; }
}
