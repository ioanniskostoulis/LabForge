// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Every test of the shell: each tests/conformance/*.ts built and run, each tests/conformance/*.mjs run, and the editor
// tests. The files are found, not listed, so that no test is left out by a list that was not updated.
import { build } from "esbuild";
import { existsSync, mkdirSync, readdirSync, rmSync } from "node:fs";
import { spawnSync } from "node:child_process";

const dir = "tests/conformance";
const typed = readdirSync(dir).filter((name) => name.endsWith(".ts")).sort();
const plain = readdirSync(dir).filter((name) => name.endsWith(".mjs")).sort();
// Built afresh each run, so that no stale test file runs.
rmSync("build/tests", { recursive: true, force: true });
mkdirSync("build/tests", { recursive: true });
await build({ entryPoints: typed.map((name) => `${dir}/${name}`), bundle: true, platform: "node", format: "esm", outdir: "build/tests", logLevel: "error" });
// The editor tests import CodeMirror, which only the shell and the applications that use the editor install.
await build({ entryPoints: ["tests/editor/code-editor.ts"], bundle: true, platform: "node", format: "esm", outfile: "build/tests/code-editor.js", logLevel: "error" });
// The desktop tests run scripts and write files, which applications' copies of the conformance tests must not do.
const desktop = readdirSync("tests/desktop").filter((name) => name.endsWith(".ts")).sort();
await build({ entryPoints: desktop.map((name) => `tests/desktop/${name}`), bundle: true, platform: "node", format: "esm", outdir: "build/tests/desktop", logLevel: "error" });
const files = [...typed.map((name) => `build/tests/${name.replace(/\.ts$/, ".js")}`), "build/tests/code-editor.js",
  ...desktop.map((name) => `build/tests/desktop/${name.replace(/\.ts$/, ".js")}`), ...plain.map((name) => `${dir}/${name}`)];
const missing = files.filter((file) => !existsSync(file));
if (missing.length) throw new Error(`Test files missing after the build: ${missing.join(", ")}.`);
const result = spawnSync(process.execPath, ["--test", ...files], { stdio: "inherit" });
process.exit(result.status ?? 1);
