// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";

export const FONT_SIZES = [10, 11, 12, 13, 15];
export const FONT_WEIGHTS = [400, 600, 700];
const colorPattern = /(?<![&\w])#[0-9a-fA-F]{3,8}\b|\b(?:rgba?|hsla?)\(/g;

const lines = (text) => text.split("\n");
const stripComments = (text) => text.replace(/\/\*[\s\S]*?\*\//g, (match) => match.replace(/[^\n]/g, " "));

/** Return style problems in one app stylesheet. The shell stylesheets are not linted: they define the scale. */
export function lintCss(text, file, { dataColors = [] } = {}) {
  const allowed = new Set(dataColors.map((color) => color.toLowerCase()));
  const found = [];
  lines(stripComments(text)).forEach((line, index) => {
    const at = `${file}:${index + 1}`;
    for (const match of line.matchAll(colorPattern)) {
      if (match[0].startsWith("#") ? !allowed.has(match[0].toLowerCase()) : true) found.push(`${at} raw colour ${match[0]}; use a token or list it under dataColors`);
    }
    for (const match of line.matchAll(/font(?:-size)?:\s*(?:[^;}]*?\s)?(\d+(?:\.\d+)?)px/g)) {
      if (!FONT_SIZES.includes(Number(match[1]))) found.push(`${at} font size ${match[1]}px is off the scale (${FONT_SIZES.join(", ")})`);
    }
    for (const match of line.matchAll(/font-weight:\s*(\d+)/g)) {
      if (!FONT_WEIGHTS.includes(Number(match[1]))) found.push(`${at} font weight ${match[1]} is off the scale (${FONT_WEIGHTS.join(", ")})`);
    }
    for (const match of line.matchAll(/font:\s*(\d{3})\s/g)) {
      if (!FONT_WEIGHTS.includes(Number(match[1]))) found.push(`${at} font weight ${match[1]} is off the scale (${FONT_WEIGHTS.join(", ")})`);
    }
    if (/text-transform:\s*uppercase/.test(line)) found.push(`${at} text-transform: uppercase is only for tab and section titles; use t-tab or t-section`);
    if (/!important/.test(line)) found.push(`${at} !important`);
  });
  return found;
}

/** Return style problems in one source file: inline font or colour styles and raw colours. */
export function lintSource(text, file, { dataColors = [] } = {}) {
  const allowed = new Set(dataColors.map((color) => color.toLowerCase()));
  const found = [];
  lines(text).forEach((line, index) => {
    const at = `${file}:${index + 1}`;
    if (/style\s*=\s*["'`][^"'`]*(?:color|font)/i.test(line) || /\.style\.(?:color|background(?:Color)?|font\w*)\b/.test(line)
      || /style\.setProperty\(\s*["'](?:color|background|font)/.test(line) || /cssText[^\n]*(?:color|font)/.test(line)) {
      found.push(`${at} inline font or colour style; use a class`);
    }
    if (/(?<!document)\.title\s*=\s*[`"'{]/.test(line)) found.push(`${at} tooltip written with .title; use setTip`);
    for (const match of line.matchAll(colorPattern)) {
      if (match[0].startsWith("#") && allowed.has(match[0].toLowerCase())) continue;
      found.push(`${at} raw colour ${match[0]}; use a token or list it under dataColors`);
    }
  });
  return found;
}

/** Icon-only buttons need an accessible name; inline icons use the 1.25 px line. */
// The path data of every shared icon (TOOL_ICONS, STATUS_ICONS, UI_ICONS), read from the shell's own source, by name.
const sharedIconSource = readFileSync(new URL("../source/app/tool-icons.ts", import.meta.url), "utf8");
export const SHARED_ICON_PATHS = new Map([...sharedIconSource.matchAll(/^\s*(\w+): toolIcon\('([^']*)'\)/gm)]
  .flatMap(([, name, body]) => [...body.matchAll(/\bd="([^"]+)"/g)].map(([, d]) => [d, name])));

export function lintIcons(text, file) {
  const found = [];
  const lineOf = (offset) => text.slice(0, offset).split("\n").length;
  for (const match of text.matchAll(/<button\b([^>]*)>\s*<svg[\s\S]*?<\/svg>\s*<\/button>/g)) {
    if (!/aria-label\s*=|aria-labelledby\s*=/.test(match[1])) found.push(`${file}:${lineOf(match.index)} icon-only button without an accessible name`);
  }
  // An application draws no shared icon itself: it takes it from TOOL_ICONS, STATUS_ICONS or UI_ICONS.
  for (const match of text.matchAll(/\bd="([^"]+)"/g)) {
    const name = SHARED_ICON_PATHS.get(match[1]);
    if (name) found.push(`${file}:${lineOf(match.index)} draws the shared ${name} icon itself; use the shell's icon`);
  }
  for (const match of text.matchAll(/stroke-width\s*=\s*["']?([\d.]+)/g)) {
    if (Number(match[1]) !== 1.25) found.push(`${file}:${lineOf(match.index)} icon stroke width ${match[1]} is off the 1.25 convention`);
  }
  return found;
}

const walk = (dir, extensions, out = []) => {
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) walk(path, extensions, out);
    else if (extensions.test(entry.name)) out.push(path);
  }
  return out;
};

/** Lint an app's own CSS and source. Returns an array of messages. */
export function lintApp({ cssFiles, sourceDir = "source", dataColors = [] }) {
  const found = [];
  for (const file of cssFiles) if (existsSync(file)) found.push(...lintCss(readFileSync(file, "utf8"), file, { dataColors }));
  for (const file of walk(sourceDir, /\.(?:ts|js|mjs|html)$/)) { const text = readFileSync(file, "utf8"); found.push(...lintSource(text, file, { dataColors }), ...lintIcons(text, file)); }
  return found;
}

export function checkDataColors(dataColors) {
  if (dataColors === undefined) return [];
  if (!Array.isArray(dataColors) || dataColors.some((color) => !/^#[0-9a-fA-F]{3,8}$/.test(color))) throw new Error("dataColors must be a list of hex colours");
  return dataColors;
}
