// Licensed under the GNU General Public License v2 or later. See LICENSE.
import assert from "node:assert/strict";
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { brandCss } from "./theme.mjs";
import { lintApp, checkDataColors } from "./style-lint.mjs";

const sharedStyle = (name) => fileURLToPath(new URL(`../source/styles/${name}`, import.meta.url));
const read = (path) => readFileSync(path, "utf8");
const shellSource = fileURLToPath(new URL("../source/", import.meta.url));

const escape = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** Catch product identifiers and formats accidentally copied into shared source. */
export function checkShellSource(sourceDir = shellSource, { name, id, extension } = {}) {
  const terms = [name, id, id && `${id.toUpperCase()}_[A-Z_]+`, "CircuitJS", extension && `\\.${escape(extension.replace(/^\./, ""))}`]
    .filter(Boolean).map((term, index) => (index === 2 || term.startsWith("\\.")) ? term : escape(term));
  const forbidden = new RegExp(terms.map((term) => term.startsWith("\\.") ? `${term}\\b` : `\\b${term}\\b`).join("|"), "i");
  const visit = (dir) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      if (entry.isDirectory()) visit(path);
      else if (/\.(?:ts|js|mjs|css|html)$/.test(entry.name)) {
        assert.doesNotMatch(read(path), forbidden, `app-specific text in shared shell source: ${path}`);
      }
    }
  };
  visit(sourceDir);
}

/** Check the built app's shell boundary, using the app's own profile and generated output. */
export function checkForgeApp({ configPath = "forge.config.json", appDir = "build/app", renderer = "app.js", sourceDir = "source", appCss = "public/app.css", strictStyle = process.env.FORGE_STYLE_LINT === "error", warn = console.warn } = {}) {
  const config = JSON.parse(read(configPath));
  checkShellSource(shellSource, { name: config.identity.name, id: config.identity.id, extension: config.document?.extension });
  if (config.document) {
    assert.ok(config.document.noun && config.document.plural && config.document.extension, "incomplete saved-document profile");
    assert.equal(typeof config.document.containsMultipleFiles, "boolean", "document profile must say whether it contains multiple files");
    assert.ok(config.document.tabs?.noun && config.document.tabs?.newTitle && config.document.tabs?.closeTitle,
      "document profile must describe its tab noun and controls");
  }
  const html = read(join(appDir, "index.html"));
  const css = read(join(appDir, "app.css"));
  const productName = config.identity.name.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
  assert.ok(!html.includes("__FORGE_"), "unfilled shell HTML slot");
  assert.ok(html.includes(`<title>${productName}</title>`), "built page has the wrong product name");
  assert.ok(html.includes(`localStorage.getItem("${config.identity.id}.settings")`), "built page uses the wrong settings key");
  for (const id of ["menubar", "toolstrip", "doc-tabs", "workspace", "center", "bottom", "bottom-tabs", "terminal-pane", "messages-pane", "inspector", "statusbar", "overlay-root"]) {
    assert.match(html, new RegExp(`id="${id}"`), `missing shared ${id} element`);
  }
  for (const slot of [config.html.center, config.html.panes]) {
    assert.ok(html.includes(read(slot).trim()), `built page does not contain ${slot}`);
  }
  assert.match(css, /^@import url\("forge-tokens\.css"\);\s*@import url\("forge-brand\.css"\);\s*@import url\("forge-shell\.css"\);/,
    "app CSS must load shared tokens, brand accents, and chrome in order");
  assert.equal(read(join(appDir, "forge-brand.css")), brandCss(config.theme), "built brand accents differ from the app profile");
  for (const name of ["tokens.css", "shell.css"]) {
    const output = join(appDir, `forge-${name === "tokens.css" ? "tokens" : "shell"}.css`);
    assert.equal(read(output), read(sharedStyle(name)), `${output} differs from the installed forge-shell package`);
  }
  assert.ok(!/(?:^|[;{\s])--(?:window|panel|raised|control|control-hover|well|separator|hairline|text|text-strong|text2|text3|warning)\s*:/m.test(css),
    "app CSS overrides a shared neutral chrome token");
  const styleProblems = lintApp({ cssFiles: [appCss], sourceDir, dataColors: checkDataColors(config.dataColors) });
  if (strictStyle) assert.deepEqual(styleProblems, [], "style lint failed");
  for (const problem of styleProblems) warn(`style: ${problem}`);
  if (renderer) assert.ok(existsSync(join(appDir, renderer)), `missing renderer ${renderer}`);
  return { product: config.identity.name, appDir };
}
