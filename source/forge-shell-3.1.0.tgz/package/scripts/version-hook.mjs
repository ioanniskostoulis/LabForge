// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { execFileSync } from "node:child_process";
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const files = ["VERSION", "package.json", "package-lock.json"];
const git = (...args) => execFileSync("git", args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
const fail = (message) => {
  console.error(`Version bump: ${message}`);
  process.exit(1);
};

export function nextPatchVersion(version) {
  const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(version);
  if (!match) throw new Error(`expected a major.minor.patch version, got ${version}.`);
  return `${match[1]}.${match[2]}.${BigInt(match[3]) + 1n}`;
}

export function versionsAgree(read) {
  const version = read("VERSION").trim();
  const pkg = JSON.parse(read("package.json"));
  const lock = JSON.parse(read("package-lock.json"));
  if (version !== pkg.version || version !== lock.version || version !== lock.packages?.[""]?.version) {
    fail("VERSION, package.json and package-lock.json must agree.");
  }
  return version;
}

/** Preserve the app's existing pre-commit version behavior. */
export function bumpPatchVersion({ requiredHookFiles }) {
  const apply = (version) => {
    writeFileSync("VERSION", `${version}\n`);
    for (const file of files.slice(1)) {
      const data = JSON.parse(readFileSync(file, "utf8"));
      data.version = version;
      if (file === "package-lock.json") data.packages[""].version = version;
      writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);
    }
    execFileSync("git", ["add", "--", ...files]);
  };

  const written = readFileSync("VERSION", "utf8").trim();
  let head = null;
  try { head = git("show", "HEAD:VERSION"); } catch {}
  if (head === null || written !== head) {
    if (!/^\d+\.\d+\.\d+$/.test(written)) fail(`expected a major.minor.patch version, got ${written}.`);
    apply(written);
    console.log(`Version: ${written} (from VERSION)`);
    return;
  }

  const current = versionsAgree((file) => git("show", `HEAD:${file}`));
  let next;
  try { next = nextPatchVersion(current); } catch (error) { fail(error.message); }
  for (const file of files) {
    try { execFileSync("git", ["diff", "--quiet", "--", file]); }
    catch { fail(`${file} has unstaged changes. Stage or discard those changes before committing.`); }
  }
  const staged = versionsAgree((file) => git("show", `:${file}`));
  for (const file of requiredHookFiles) {
    try { execFileSync("git", ["cat-file", "-e", `:${file}`]); }
    catch { fail(`stage ${file} so the version hook is included in this commit.`); }
  }
  if (staged === next) {
    console.log(`Version bump: ${next} is already staged.`);
    return;
  }
  if (staged !== current) fail(`staged version ${staged} differs from HEAD ${current}; resolve it before committing.`);
  apply(next);
  console.log(`Version bump: ${current} → ${next}`);
}

/** Install only our own hook; leave unrelated user hooks alone. */
export function installVersionHook({ marker, script = "scripts/bump-version.mjs" }) {
  let hooks;
  try { hooks = resolve(execFileSync("git", ["rev-parse", "--git-path", "hooks"], { encoding: "utf8" }).trim()); }
  catch { return; }
  const path = resolve(hooks, "pre-commit");
  const contents = `#!/bin/sh\n${marker}\nexec node ${script}\n`;
  if (existsSync(path) && readFileSync(path, "utf8") === contents) {
    console.log(`Version hook already installed at ${path}`);
    return;
  }
  if (existsSync(path) && !readFileSync(path, "utf8").includes(marker)) {
    console.warn(`Version hook not installed: ${path} already exists.`);
    return;
  }
  mkdirSync(hooks, { recursive: true });
  writeFileSync(path, contents);
  chmodSync(path, 0o755);
  console.log(`Installed ${path}`);
}
