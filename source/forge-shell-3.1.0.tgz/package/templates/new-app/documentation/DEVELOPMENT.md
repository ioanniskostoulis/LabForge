# Development

__NAME__ follows the shell's `PROJECT-STRUCTURE.md`. The frame (menus, tool strip, panels, Terminal, Messages, status bar, welcome screen) comes from the shell; the domain lives in `source/engine` and the domain parts of `source/app`.

| Step | Command |
|---|---|
| Wordmark | `npx forge-shell wordmark __NAME__ --out assets/logo.txt` |
| Application icon | `assets/icon.png`, 1024 × 1024 px; the generated one is a plain square in the accent, to be replaced before a release |
| Document icons | Made by `forge-shell new-app` when Python 3 with Pillow is installed; otherwise, and after changing `assets/icon.png`, run `python3 node_modules/forge-shell/scripts/file-icon.py` before `npm run dist` |
| Shell update | Pin a released archive in `source/` and run `npm install`, following the shell's `UPDATING.md` |
