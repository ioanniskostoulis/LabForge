# Changelog

## 0.1.0

- Created __NAME__, __PURPOSE__, from the shell's application scaffold: the frame, menus, Terminal, Messages, panels and build workflows, with no domain features yet.
