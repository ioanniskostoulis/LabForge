// Install the local Git hook that raises the patch version on each commit.
import { installVersionHook } from "forge-shell/scripts/version-hook";

installVersionHook({ marker: "# __NAME__ automatic patch version hook" });
