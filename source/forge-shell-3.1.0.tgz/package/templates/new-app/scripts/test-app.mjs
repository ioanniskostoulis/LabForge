// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The interface tests of __NAME__ and the shell's conformance tests that every application runs: `npm run test:app`.
import { build } from "esbuild";
import { spawnSync } from "node:child_process";
import { readdirSync, rmSync } from "node:fs";

const shellDir = "node_modules/forge-shell/tests/conformance";
const shellTests = readdirSync(shellDir).filter((name) => name.endsWith(".ts"));
if (!shellTests.length) throw new Error(`No conformance tests in ${shellDir}. Run npm install.`);
rmSync("build/tests/shell", { recursive: true, force: true });
await build({ entryPoints: shellTests.map((name) => `${shellDir}/${name}`), bundle: true, platform: "node", format: "cjs", outdir: "build/tests/shell", outExtension: { ".js": ".cjs" }, logLevel: "error" });
// Each file is named: a folder given to node --test runs only files named like *.test.js.
const files = shellTests.map((name) => `build/tests/shell/${name.replace(/\.ts$/, ".cjs")}`);
const result = spawnSync(process.execPath, ["--test", ...files], { stdio: "inherit" });
process.exit(result.status ?? 1);
