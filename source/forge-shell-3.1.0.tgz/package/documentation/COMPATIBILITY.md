# Document models

The shell supports two saved-document models. The `ForgeDocumentProfile` of an application records which model it uses, so that shared code assumes no file format.

| Model | Saved document | Top tabs | Profile |
|---|---|---|---|
| One file per tab | A single file with the application's extension; each open document is one tab | The open documents | `containsMultipleFiles: false` |
| Project archive | One saved project containing several files | The internal file views of the open project | `containsMultipleFiles: true` |

## Profiles

| Profile | Records |
|---|---|
| `ForgeDocumentProfile` | The saved-document noun, the tab noun and whether the saved document contains several files |
| Runtime profile | The application's menu builder, command catalogues, inspector sections and pane order |

The tab, Messages, Terminal, panel, desktop and build modules of the shell accept application behaviour through callbacks or profile data.

## Panes and accents

The bottom panes are Terminal and Messages, with any domain panes the application adds between them. Accents are checked against the shared Dark input well at a contrast ratio of 4.5:1 before an application builds (see [GUIDELINES.md](GUIDELINES.md), section 2). The versioned update path is described in [UPDATING.md](UPDATING.md).
