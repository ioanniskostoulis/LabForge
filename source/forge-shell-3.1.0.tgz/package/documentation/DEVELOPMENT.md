# Development and releases

The source package exports TypeScript from `source/app` and CSS from `source/styles`. Applications use esbuild and the `Bundler` module resolution of TypeScript. No compiled `dist` directory and no prepare step exist.

The shell is released through versioned tags. An application pins the package archive of a release, so that its continuous integration does not depend on a local sibling checkout.

## Release of the shell

| Step | Content |
|---|---|
| 1 | `VERSION`, `package.json`, the lockfile and `CHANGELOG.md` are updated together; migrations of a breaking change are documented. |
| 2 | The shell checks and conformance suite run, followed by the full gate and packaged launch checks of each consuming application. |
| 3 | The commit is tagged `vX.Y.Z` in this repository and the tag is published to its remote. |
| 4 | For each application, a clean checkout of the tag is packed, the versioned archive and lockfile are updated, the full gate runs, and the update is committed. Other applications retain their previous archive. |

`npm run release -- <version>` performs steps 1 to 4 for the applications listed in `release.local.json`; see [UPDATING.md](UPDATING.md).
