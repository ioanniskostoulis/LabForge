# Releasing the shell and updating applications

The shell is source-only. Each application bundles the TypeScript of the package with its own renderer and Electron entry points. The profile in `forge.config.json` supplies the identity, document metadata, accents, HTML slots and desktop packaging metadata; domain menus, commands, models and views remain in the application.

| Subject | Description |
|---|---|
| Windows setup | An unpacked desktop build is packaged by the shared [setup](INSTALLER.md). |
| Document icons | The profile records `desktop.document.iconSource`, `iconInk`, `iconLabel` and `iconStem`. `scripts/file-icon.py` generates the PNG, ICNS and ICO files after a change of icon source or ink. |

## Release of the shell

| Step | Content |
|---|---|
| 1 | `VERSION`, `package.json` and the lockfile carry the same semantic version; a matching changelog section exists, with migration notes for a breaking release. |
| 2 | `npm run check`, `npm test` and `npm pack --dry-run` pass, and the archive contains the application, desktop, style, script and template entries. |
| 3 | The proposed version is tested in every application that consumes the shell: typecheck, domain tests, conformance check, desktop package build and packaged launch check, with the automated installer and screenshot job on Windows. A new application runs the same checks before it adopts a tag; its migration does not gate the first release. |
| 4 | The commit is tagged `v<VERSION>` and the tag is published to the remote. A tag that an application has pinned is not moved. |

### Release by script

`npm run release -- <version> [--dry-run] [--no-push] [--message <text>]` performs the steps in order.

| Stage | Action |
|---|---|
| Version | Sets `VERSION`, `package.json` and the lockfile; renames `## Unreleased` to the version section |
| Verification | Runs the checks and tests |
| Publication | Commits, tags `v<version>` and pushes |
| Packing | Packs the tag from a clean checkout and computes the lockfile integrity |
| Pinning | Pins the archive in each application listed in `release.local.json` |

`release.local.json` is not committed. For each application it records the `path`, whether to `commit` and `push`, and the `docs` in which the previous version string is replaced. An application set to commit is skipped, with a message, when it has uncommitted changes. A published tag is never moved; an error is corrected by the next patch version.

## Workflows of the shell

Each action is a separate workflow, listed by name in the Actions sidebar, with its own **Run workflow** button.

| Workflow | Action |
|---|---|
| Check shell | Typechecks and runs the tests; also runs on pushes to the main branch and on pull requests |
| Build package | Checks, packs the archive and keeps it as a workflow artifact |
| Publish release | Checks, packs and publishes the archive to the release `v<VERSION>` with its changelog notes; also runs on a pushed version tag |
| Clear all | Deletes every release, tag and workflow run; builds nothing, is irreversible, and acts only when **confirm** is `clear all` |

## Workflows of an application

The shell writes the four build workflows of an application, so that every application is built, checked and published identically. `forge-shell workflows` writes them into `.github/workflows/`, and `npm run release` regenerates them in each pinned application. Each workflow is self-contained, appears by name in the Actions sidebar of the application and has its own **Run workflow** button. No workflow of the shell repository is called, so that the access settings of a private shell repository do not apply.

| Workflow (file) | Action |
|---|---|
| Build desktop apps (`build-desktop-apps.yml`) | Checks, builds the macOS and Windows applications and publishes both installers to the release `v<VERSION>`; also runs on pushes to the main branch and on version tags |
| Build for mac (`build-for-mac.yml`) | Checks, builds and publishes the macOS application only |
| Build for windows (`build-for-windows.yml`) | Checks, builds and publishes the Windows application only |
| Clear all (`clear-all.yml`) | Deletes every release, tag and workflow run of the repository; builds nothing, is irreversible, and acts only when **confirm** is `clear all` |

| Subject | Description |
|---|---|
| Release file names | `<Name>-v<version>.dmg` (macOS) and `<Name>-v<version>.exe` (Windows), for example `Example-v1.2.3.dmg`. The names are set by `artifactName()` and `artifactPattern()`, which the configuration, the setup build and the workflow share. The archive of the shell keeps the package name `forge-shell-<version>.tgz`. |
| Command line | `gh workflow run "Build for mac"` starts a workflow from a terminal. |
| Release notes | The publish step runs `forge-shell release-notes`, which requires a `## <VERSION>` section in `CHANGELOG.md`. |
| Artifacts | The installers pass from the build jobs to the publish job as artifacts kept for 1 day; the launch screenshots and setup logs are kept for 7 days. Artifacts count against the Actions storage of the account (500 MB for private repositories on the Free plan), and the installers stay in the release. |
| Generated files | The workflows are generated and are not edited by hand; a change belongs to the shell and reaches an application with its next pin. |
| Scripts required of the application | `check`, `test`, `test:app` and `test:shell`, `scripts/check-release.mjs --mac\|--win`, and `scripts/check-windows-capture.ps1` and `scripts/check-windows-installer.ps1`. |

## Update of an application

| Step | Content |
|---|---|
| 1. Pin | One exact release is pinned. `github:<owner>/forge-shell#vX.Y.Z` serves when the application and its CI can read the repository. Otherwise `npm pack` is run on a clean checkout of the tag, the archive `forge-shell-X.Y.Z.tgz` is kept in the application and referenced as `file:source/forge-shell-X.Y.Z.tgz`, and `package-lock.json` is regenerated; its integrity field pins the bytes of the archive. The `VERSION` of the application need not match that of the shell. |
| 2. Changes | The changelog of the shell is read from the old tag to the new one. The profile is updated for new required fields; accents, document icons, domain menus and domain commands remain in the application. |
| 3. Release source | `node_modules/forge-shell` is included in the release-source copy under `vendor/forge-shell` and verified; an archive dependency is included with its hash checked against the lockfile. The previous archive is removed only after the new version passes all checks. |
| 4. Verification | `npm ci`, `npm run check`, the unit and interface tests, `node scripts/check-shell.mjs`, `npm run dist` and the release-source check run. The served application is inspected in Dark and Light, and the packaged macOS application is launched. The Windows CI build and launch screenshot cover Windows. |
| 5. Record | The new shell version is noted in the application's changelog. A failed check is rolled back by restoring the previous tag and lockfile. |

The release check verifies a pinned archive against the lockfile and the installed package version. The saved-document shapes supported by the shell are described in [COMPATIBILITY.md](COMPATIBILITY.md).
