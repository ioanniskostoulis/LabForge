# Windows setup

`scripts/build-installer.mjs` packs the `build/release/win-unpacked` directory of an application, once, as a portable setup executable. The setup runs inside the application: started from the setup executable, the application's own Electron runs the shell's setup instead of the application, so the executable carries one copy of Electron and the files it installs. The setup interface is shared by all Forge applications and reads the product name, purpose, wordmark, accents, desktop icon and optional document extension and icon from `forge.config.json`. The application supplies its packaged payload; the installer contains no domain code.

## Build

| Step | Content |
|---|---|
| 1 | `buildForgeApp` builds the renderer and the Electron main process. The main process (`package.json` `main`, such as `build/desktop/main.cjs`) is built as `app-main.cjs` beside a generated entry (`setupEntry`), and the setup is bundled into `build/desktop/setup` (`buildSetupBundle`): its main process, preload, window files and `setup.json`. electron-builder then packages an unpacked Windows x64 application (`--win --x64 --dir`), with the en-US locale only. |
| 2 | `node scripts/build-installer.mjs` runs in the application, through a wrapper calling `buildInstaller` from `forge-shell/scripts/build-installer`. The unpacked application is copied to `build/setup/app` with the document icon and `resources/payload.json`, the SHA-256 manifest of every other file, and electron-builder packs that folder as it is (`--prepackaged`) into `build/release/<Product>-v<version>.exe`. |
| 3 | The Windows release check, the packaged-application launch screenshot, the setup window screenshot and the silent installation check run before the executable is published. `--stage-only` produces the setup files and the payload manifest without the executable. |

| Entry | Runs |
|---|---|
| Windows, started from the setup executable (the portable wrapper sets `PORTABLE_EXECUTABLE_FILE`), or with a `--forge-setup` argument (the elevated copy) | The setup, from `build/desktop/setup/main.cjs`, under the name `<Product> Setup` with its own settings folder, so that an open copy of the application neither holds its single-instance lock nor shares its settings |
| Anything else, macOS included | The application, from `app-main.cjs` |

The setup installs the files of the folder it runs from, and treats the application as running only when the executable at the installation path runs, since the setup is a copy of the same executable. It starts the installed application without its own variables, so that the application starts as itself.

The wrapper requires a shell archive containing the installer export; the application therefore pins a clean, tagged release and updates its lockfile before its installer wiring is committed. `npm pack --dry-run` lists `source/installer/` and `scripts/build-installer.mjs`.

## Installation

| Property | Behaviour |
|---|---|
| Scope | All users, under `C:\Program Files\Forge\<Product>` (`Forge` is the family folder). |
| Rights | The setup executable is marked `asInvoker`. Started without administrator rights, it starts an elevated copy of itself through User Account Control (Windows displays the prompt), waits for it and exits with its exit code; a declined prompt gives exit code 5. The `FORGE_` variables and those of the portable wrapper are passed to the copy as one argument, since an elevated process receives a fresh environment. An executable marked `requireAdministrator` cannot start the sandboxed helper processes of Chromium (Windows error 740), and the setup then crashes. |
| Registration | The Settings entry and the file association are written under `HKLM`; the shortcut is placed in the common Start menu. |
| Payload | The payload is carried inside the setup; nothing is downloaded. Every file is verified against its SHA-256 manifest before the application folder is switched. |
| Family name | The family folder name is also the publisher and the registry prefix (`Forge.<id>`). `desktop.installer.family` in `forge.config.json` changes it and must be a valid folder name. |
| Upgrade and downgrade | One previous version is kept under `.previous`. A repair replaces the current files. A running application blocks replacement. A downgrade requires confirmation in the interface or `/force` in silent mode. |
| Application data | `%APPDATA%` lies outside the installation folder and is preserved. |
| Document icon | A generated `assets/icon/<desktop.document.iconStem>.ico` is copied with the setup and registered for the document type. |

### Silent operation

`/S` or `--silent` installs without an interface.

| Exit code | Meaning |
|---|---|
| 0 | Success |
| 1 | Other error |
| 2 | A newer version blocks the installation |
| 3 | The application is running or files are busy |
| 4 | A payload checksum failed |
| 5 | Cancelled |

### Setup log and crash dumps

A silent installation or any uninstallation records each stage, one timed line per entry, in `<id>-setup.log`. Each line is written to disk before the next stage begins, so that the lines preceding a native crash are kept. Electron writes its crash dumps (`.dmp`) to the same folder; nothing is uploaded.

| Subject | Value |
|---|---|
| Folder | `%TEMP%\<family> setup` (for example `%TEMP%\Forge setup`), or the folder named by `FORGE_SETUP_LOG_DIR` |
| File | `<id>-setup.log`, appended by every run |
| Entries | The start (version, arguments, setup path, resources, installation root, Electron version, process id), `Ready.`, each installation step, the registration, an error with its code and stack, a lost child process, and `Exit <code>.` followed by `Process exit <code>.` |
| CI | The generated Windows job sets `FORGE_SETUP_LOG_DIR` to `build/release/setup-log` for the installer check. When the check fails, the job prints the log and uploads the folder as the `windows-setup-log` artifact. |

| Last entry of the log | Reading |
|---|---|
| A stage of the installation, without `Exit` | The setup crashed during that stage. |
| `Exit <code>.` with a different process exit code | The setup finished the stage and crashed while closing. |
| No entry for the run | The setup crashed before its main process started, or the portable wrapper failed. |

A process exit code of `-2147483645` (`0x80000003`, breakpoint) or `-1073741819` (`0xC0000005`, access violation) is a crash of Electron and not one of the exit codes above; the dump in the folder identifies the crashing thread.

## Uninstallation

Each application appears in Settings › Apps and in the Control Panel (Programs and Features) as `<Product>`, with an Uninstall button only. The button runs the copy of the setup kept in the family folder as `<Product>-Setup.exe /uninstall`, and Windows requests administrator approval.

| Mode | Behaviour |
|---|---|
| Interactive (`/uninstall`) | Offers **Uninstall, keep settings**, **Uninstall and delete settings** and **Cancel**. |
| Silent (`/uninstall /S`) | Keeps settings unless `/purge` is given. |

| Removed | Retained |
|---|---|
| The application folder, its kept previous version (only the entries of this application in `.previous`) and the staging remnants | Documents, always |
| The shortcut, the `HKLM` entries and the file association | Settings, unless deletion is chosen |
| The shared registry file when no application remains; the copy of the uninstaller and the empty family folder, removed by a detached command after the uninstaller exits | |

Deletion of settings removes `%APPDATA%\<Product>` and `%LOCALAPPDATA%\<Product>` of the account that runs the uninstallation. When Windows elevates as a different administrator account, those are the folders of that account.

The setup removes neither an older NSIS all-users installation in Program Files nor an earlier per-user installation under `%LOCALAPPDATA%\AppForge\<Product>` made by a setup that preceded this behaviour. The migration notes of the application describe the removal of these installations; the per-user one is removed by its own `/uninstall`.

## Verification limits

The conformance suite covers version decisions, payload hashes, safe paths, installation, rollback, uninstallation, the construction of registry commands and the packaging configuration. It does not establish Defender behaviour, the behaviour of the real Windows registry and shortcuts, or the displayed progress rate; the Windows CI installation and screenshot check establish them before publication. An application with a multi-file project format requires its own packaged Windows check.
