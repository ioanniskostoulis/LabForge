import assert from "node:assert/strict";
import { test } from "node:test";
import { bandsFromRects, joinBands, roundedPath } from "../../source/app/selection-shape";

test("client rectangles on one line merge into one band", () => {
  const bands = bandsFromRects([{ left: 40, right: 80, top: 0, bottom: 14 }, { left: 0, right: 40, top: 1, bottom: 15 }, { left: 0, right: 60, top: 20, bottom: 34 }, { left: 5, right: 5.2, top: 40, bottom: 54 }]);
  assert.deepEqual(bands, [{ left: 0, right: 80, top: 0, bottom: 15 }, { left: 0, right: 60, top: 20, bottom: 34 }]);
});

test("neighbouring bands meet at the middle of the gap", () => {
  const joined = joinBands([{ left: 0, right: 10, top: 0, bottom: 14 }, { left: 0, right: 20, top: 18, bottom: 32 }]);
  assert.equal(joined[0].bottom, 16);
  assert.equal(joined[1].top, 16);
});

test("lines that overlap form one rounded shape, separate lines form two", () => {
  const one = roundedPath(joinBands([{ left: 0, right: 40, top: 0, bottom: 14 }, { left: 0, right: 60, top: 14, bottom: 28 }]), 4);
  assert.equal(one.split("Z").length - 1, 1);
  assert.ok(one.includes("Q"));
  const two = roundedPath([{ left: 0, right: 10, top: 0, bottom: 14 }, { left: 50, right: 60, top: 14, bottom: 28 }], 4);
  assert.equal(two.split("Z").length - 1, 2);
});
