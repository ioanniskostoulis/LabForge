import assert from "node:assert/strict";
import { test } from "node:test";
import { checkTipWording, tipText } from "../../source/app/tips";
import { editableTip } from "../../source/app/inspector-widgets";

test("tip text joins label, shortcut and note", () => {
  assert.equal(tipText({ label: "Undo", shortcut: "CmdOrCtrl+Z" }, (key) => key.replace("CmdOrCtrl", "Ctrl")), "Undo (Ctrl+Z)");
  assert.equal(tipText({ label: "Add wire", note: "Click to start." }), "Add wire: Click to start.");
});

test("tip wording rules accept action and sentence tips and flag the rest", () => {
  for (const good of ["Undo (⌘Z)", "Fit", "Set the random seed for reproducible variation.", "Sets language= in the class line of main.tex."]) assert.deepEqual(checkTipWording(good), [], good);
  assert.ok(checkTipWording("set the random seed.").length > 0);
  assert.ok(checkTipWording("Set the random seed for reproducible variation").length > 0);
  assert.ok(checkTipWording(`Set ${"x ".repeat(70)}.`).length > 0);
});

test("an editable readout's tip is the application's sentence with a final period, and passes the wording check", () => {
  assert.equal(editableTip("Enter a speed ratio, such as 0.01, or a rate, such as 2 ms/s"), "Enter a speed ratio, such as 0.01, or a rate, such as 2 ms/s.");
  assert.equal(editableTip("Enter a value from 0 to 255."), "Enter a value from 0 to 255.", "a period is not doubled");
  assert.equal(editableTip("Quality"), "Quality.");
  for (const tip of ["Enter a speed ratio, such as 0.01, or a rate, such as 2 ms/s", "Set marker speed from 0.1× to 5×"].map(editableTip)) assert.deepEqual(checkTipWording(tip), []);
});
