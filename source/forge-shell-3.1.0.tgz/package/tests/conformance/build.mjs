import assert from "node:assert/strict";
import test from "node:test";
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { buildForgeApp } from "../../scripts/build.mjs";
import { checkForgeApp } from "../../scripts/check-app.mjs";
import { checkReleaseSource } from "../../scripts/check-release.mjs";

test("a second app builds the shared HTML frame from its own profile and slots", async () => {
  const prior = process.cwd();
  const root = mkdtempSync(join(tmpdir(), "forge-shell-build-"));
  try {
    process.chdir(root);
    mkdirSync("public");
    mkdirSync("assets");
    mkdirSync("shell-src");
    writeFileSync("shell-src/index.ts", "export const shell = true;\n");
    writeFileSync("VERSION", "1.0.0\n");
    writeFileSync("package.json", JSON.stringify({ name: "testforge", version: "1.0.0" }));
    writeFileSync("package-lock.json", JSON.stringify({ version: "1.0.0", packages: { "": { version: "1.0.0" } } }));
    for (const name of ["LICENSE", "NOTICE.md", "CHANGELOG.md", "README.md"]) writeFileSync(name, `${name} for TestForge\n`);
    const red = { accent: "#f09090", accentLight: "#f09090", accentAbout: "#f09090", accentFill: "#963939", accentHover: "#7c2626" };
    const lightRed = { accent: "#a52b2b", accentLight: "#a52b2b", accentAbout: "#a52b2b", accentFill: "#963939", accentHover: "#7c2626" };
    writeFileSync("forge.config.json", JSON.stringify({ identity: { id: "testforge", name: "TestForge", versionSource: "VERSION" },
      theme: { dark: red, light: lightRed }, html: { center: "public/center.html", panes: "public/panes.html", prePaintScript: "public/prepaint.js" } }));
    // "$&" and "$'" are replacement patterns in String.replace; app HTML must pass through unchanged.
    writeFileSync("public/center.html", '<main id="editor">Work</main>\n<script>const cost = "$&", rest = "$\'";</script>\n');
    writeFileSync("public/panes.html", '<div id="results-pane" class="pane">Results</div>\n');
    writeFileSync("public/prepaint.js", 'if (saved.customSurface) document.body.classList.add("custom-surface");\n');
    writeFileSync("public/app.css", '@import url("forge-tokens.css");\n\n@import url("forge-brand.css");\n\n@import url("forge-shell.css");\n');
    writeFileSync("assets/icon.png", "test icon");
    // The icon is not listed: the page names icon.png, so the build copies assets/icon.png itself.
    await buildForgeApp({ targets: [], staticFiles: [
      ["LICENSE", "LICENSE"], ["NOTICE.md", "NOTICE.md"], ["CHANGELOG.md", "CHANGELOG.md"]],
      releaseDirs: ["public", "assets"],
      releaseCopies: [{ from: "shell-src", to: "vendor/forge-shell" }],
      releaseFiles: ["LICENSE", "NOTICE.md", "CHANGELOG.md", "README.md", "VERSION", "forge.config.json", "package.json", "package-lock.json"],
    });
    const html = readFileSync("build/app/index.html", "utf8");
    assert.match(html, /<title>TestForge<\/title>/);
    assert.match(readFileSync("build/app/forge-brand.css", "utf8"), /--accent: #a52b2b/);
    assert.match(html, /localStorage\.getItem\("testforge\.settings"\)/);
    assert.match(html, /if \(saved\.customSurface\) document\.body\.classList\.add\("custom-surface"\)/);
    assert.doesNotMatch(readFileSync(new URL("../../templates/app/index.html", import.meta.url), "utf8"), /whiteBackground|paper/);
    assert.match(html, /<main id="editor">Work<\/main>/);
    assert.ok(html.includes('const cost = "$&", rest = "$\'";'), "dollar sequences in app HTML were altered");
    assert.match(html, /<div id="results-pane" class="pane">Results<\/div>/);
    assert.match(html, /href="icon\.png\?v=/);
    assert.equal(readFileSync("build/app/icon.png", "utf8"), "test icon");
    // The generated licence texts ship with the corresponding source as well as with the app.
    assert.equal(readFileSync("build/app/release-source/THIRD-PARTY-LICENSES.md", "utf8"), readFileSync("build/app/THIRD-PARTY-LICENSES.md", "utf8"));
    assert.doesNotMatch(html, /__FORGE_/);
    assert.deepEqual(checkForgeApp({ renderer: null }), { product: "TestForge", appDir: "build/app" });
    assert.equal(checkReleaseSource({ roots: ["public", "assets"],
      files: ["LICENSE", "NOTICE.md", "CHANGELOG.md", "README.md", "VERSION", "forge.config.json", "package.json", "package-lock.json"],
      releaseCopies: [{ from: "shell-src", to: "vendor/forge-shell" }], expectedDependencies: {} }).copies.length, 1);
  } finally {
    process.chdir(prior);
    rmSync(root, { recursive: true, force: true });
  }
});

test("the Electron main process is built beside a generated entry and the bundled setup", async () => {
  const prior = process.cwd();
  const root = mkdtempSync(join(tmpdir(), "forge-shell-build-"));
  try {
    process.chdir(root);
    for (const dir of ["public", "assets", "desktop-src"]) mkdirSync(dir);
    writeFileSync("desktop-src/main.ts", "export const desktop = true;\n");
    writeFileSync("VERSION", "1.0.0\n");
    writeFileSync("package.json", JSON.stringify({ name: "testforge", version: "1.0.0", main: "build/desktop/main.cjs" }));
    writeFileSync("package-lock.json", JSON.stringify({ version: "1.0.0", packages: { "": { version: "1.0.0" } } }));
    writeFileSync("public/center.html", "<main></main>\n");
    writeFileSync("public/panes.html", "<div></div>\n");
    writeFileSync("assets/logo.txt", "TestForge\n");
    const red = { accent: "#f09090", accentLight: "#f09090", accentAbout: "#f09090", accentFill: "#963939", accentHover: "#7c2626" };
    writeFileSync("forge.config.json", JSON.stringify({ identity: { id: "testforge", name: "TestForge", purpose: "test app", versionSource: "VERSION" },
      theme: { dark: red, light: { ...red, accent: "#a52b2b", accentLight: "#a52b2b", accentAbout: "#a52b2b" } }, document: null,
      html: { center: "public/center.html", panes: "public/panes.html" } }));
    // esbuild keeps the working folder it started in, so the test names absolute paths.
    await buildForgeApp({ targets: [{ entryPoints: [join(root, "desktop-src/main.ts")], outfile: "build/desktop/main.cjs", absWorkingDir: root, platform: "node", format: "cjs", external: ["electron"] }] });
    assert.match(readFileSync("build/desktop/main.cjs", "utf8"), /require\(setup \? "\.\/setup\/main\.cjs" : "\.\/app-main\.cjs"\)/);
    assert.match(readFileSync("build/desktop/app-main.cjs", "utf8"), /desktop = true/);
    for (const file of ["main.cjs", "preload.cjs", "index.html", "renderer.js", "setup.css", "forge-tokens.css", "forge-brand.css", "setup.json"]) {
      assert.ok(readFileSync(join("build/desktop/setup", file)).length > 0, `setup/${file}`);
    }
    assert.equal(JSON.parse(readFileSync("build/desktop/setup/setup.json", "utf8")).product, "TestForge");
  } finally {
    process.chdir(prior);
    rmSync(root, { recursive: true, force: true });
  }
});

test("only tracked files ship as the corresponding source; a file kept only on disk stays out, with no list naming it", async () => {
  const { spawnSync } = await import("node:child_process");
  const { existsSync } = await import("node:fs");
  const prior = process.cwd();
  const root = mkdtempSync(join(tmpdir(), "forge-shell-tracked-"));
  try {
    process.chdir(root);
    for (const dir of ["public", "documentation"]) mkdirSync(dir);
    writeFileSync("VERSION", "1.0.0\n");
    writeFileSync("package.json", JSON.stringify({ name: "testforge", version: "1.0.0" }));
    writeFileSync("package-lock.json", JSON.stringify({ version: "1.0.0", packages: { "": { version: "1.0.0" } } }));
    for (const name of ["LICENSE", "NOTICE.md", "CHANGELOG.md"]) writeFileSync(name, `${name}\n`);
    const red = { accent: "#f09090", accentLight: "#f09090", accentAbout: "#f09090", accentFill: "#963939", accentHover: "#7c2626" };
    writeFileSync("forge.config.json", JSON.stringify({ identity: { id: "testforge", name: "TestForge", versionSource: "VERSION" }, theme: { dark: red, light: { ...red, accent: "#a52b2b", accentLight: "#a52b2b", accentAbout: "#a52b2b" } }, html: { center: "public/center.html", panes: "public/panes.html" } }));
    writeFileSync("public/center.html", "<main></main>\n");
    writeFileSync("public/panes.html", "<div></div>\n");
    writeFileSync("documentation/GUIDE.md", "public guide\n");
    writeFileSync("documentation/NOTES.md", "kept on disk only\n");
    const git = (...args) => spawnSync("git", args, { encoding: "utf8" });
    git("init", "-q");
    git("add", "VERSION", "package.json", "package-lock.json", "LICENSE", "NOTICE.md", "CHANGELOG.md", "forge.config.json", "public", "documentation/GUIDE.md");
    await buildForgeApp({ targets: [], staticFiles: [["LICENSE", "LICENSE"], ["NOTICE.md", "NOTICE.md"], ["CHANGELOG.md", "CHANGELOG.md"]], releaseDirs: ["public", "documentation"], releaseFiles: ["LICENSE", "VERSION"] });
    assert.ok(existsSync("build/app/release-source/documentation/GUIDE.md"));
    assert.ok(!existsSync("build/app/release-source/documentation/NOTES.md"), "an untracked file shipped");
    const result = checkReleaseSource({ roots: ["public", "documentation"], files: ["LICENSE", "VERSION"] });
    assert.ok(!result.paths.some((path) => path.endsWith("NOTES.md")));
  } finally {
    process.chdir(prior);
    rmSync(root, { recursive: true, force: true });
  }
});
