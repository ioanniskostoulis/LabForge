import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { checkShellSource } from "../../scripts/check-app.mjs";

test("shell source scan rejects a copied app identifier", () => {
  const dir = mkdtempSync(join(tmpdir(), "forge-shell-source-"));
  try {
    const file = join(dir, "example.ts");
    writeFileSync(file, 'export const label = "generic";\n');
    assert.doesNotThrow(() => checkShellSource(dir));
    const identity = { name: "TestForge", id: "testforge", extension: "tfg" };
    assert.doesNotThrow(() => checkShellSource(dir, identity));
    for (const text of ["TestForge", "TESTFORGE_HOME", "CircuitJS", "file.tfg"]) {
      writeFileSync(file, `export const label = "${text}";\n`);
      assert.throws(() => checkShellSource(dir, identity), /app-specific text/, text);
    }
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
