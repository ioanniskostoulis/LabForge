import assert from "node:assert/strict";
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { collectLicenses, licensesMarkdown } from "../../scripts/licenses.mjs";

function project(packages) {
  const root = mkdtempSync(join(tmpdir(), "forge-licenses-"));
  const lock = { packages: { "": {} } };
  for (const [name, { lock: info, files = {}, meta = {} }] of Object.entries(packages)) {
    lock.packages[`node_modules/${name}`] = info;
    const dir = join(root, "node_modules", name);
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, "package.json"), JSON.stringify({ name, ...meta }));
    for (const [file, text] of Object.entries(files)) writeFileSync(join(dir, file), text);
  }
  writeFileSync(join(root, "package-lock.json"), JSON.stringify(lock));
  return root;
}

test("production packages are listed with their licence text; dev packages and the shell are skipped", () => {
  const root = project({
    alpha: { lock: { version: "1.0.0", license: "MIT" }, files: { LICENSE: "Alpha licence text.\n", "NOTICE.md": "Alpha notice." }, meta: { repository: { url: "git+https://github.com/example/alpha.git" } } },
    beta: { lock: { version: "2.0.0", license: "Apache-2.0" } },
    gamma: { lock: { version: "3.0.0", license: "MIT", dev: true } },
    "forge-shell": { lock: { version: "9.9.9", license: "GPL-2.0-or-later" } },
  });
  try {
    const { entries, missing } = collectLicenses({ lockfile: join(root, "package-lock.json"), modules: join(root, "node_modules") });
    assert.deepEqual(entries.map((entry) => entry.name), ["alpha", "beta"]);
    assert.equal(entries[0].repository, "https://github.com/example/alpha");
    assert.deepEqual(entries[0].texts.map((item) => item.file), ["LICENSE", "NOTICE.md"]);
    assert.deepEqual(missing, []);
    const markdown = licensesMarkdown(entries);
    assert.match(markdown, /## alpha 1\.0\.0/);
    assert.match(markdown, /Alpha licence text\./);
    assert.match(markdown, /carries no separate licence text/);
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("a package that declares no licence is reported", () => {
  const root = project({ delta: { lock: { version: "1.0.0" } } });
  try {
    const { missing } = collectLicenses({ lockfile: join(root, "package-lock.json"), modules: join(root, "node_modules") });
    assert.deepEqual(missing, ["delta@1.0.0"]);
  } finally { rmSync(root, { recursive: true, force: true }); }
  assert.match(licensesMarkdown([]), /No third-party packages are bundled\./);
});
