import assert from "node:assert/strict";
import test from "node:test";
import { cacheKeyValues } from "../../scripts/cache-key.mjs";

test("cache key ignores the app version but changes with dependencies", () => {
  const lock = { version: "1.0.0", packages: {
    "": { version: "1.0.0" },
    "node_modules/electron": { version: "44.5.1" },
    "node_modules/electron-builder": { version: "26.15.3" },
  } };
  const first = cacheKeyValues(lock);
  lock.version = lock.packages[""].version = "1.0.1";
  assert.deepEqual(cacheKeyValues(lock), first);
  lock.packages["node_modules/electron"].version = "44.5.2";
  assert.notEqual(cacheKeyValues(lock).dependencies, first.dependencies);
});
