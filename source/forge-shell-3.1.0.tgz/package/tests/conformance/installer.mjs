import assert from "node:assert/strict";
import { test } from "node:test";
import { mkdtemp, mkdir, readFile, readdir, rm, writeFile, access } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { compareVersions, parseVersion } from "../../source/installer/version.mjs";
import { decideInstall } from "../../source/installer/plan.mjs";
import { buildManifest, copyPayload, safeRelativePath } from "../../source/installer/payload.mjs";
import { installLayout } from "../../source/installer/layout.mjs";
import { readRegistry } from "../../source/installer/registry.mjs";
import { inspectInstall, runInstall, runUninstall } from "../../source/installer/install.mjs";
import { isRunning, registerApp, unregisterApp } from "../../source/installer/windows.mjs";
import { logLine, openSetupLog, setupLogDir } from "../../source/installer/log.mjs";
import { DECLINED, ENV_ARGUMENT, appEnvironment, elevationScript, encodedCommand, envArgument, forwardedEnv, isElevated, restoreEnv } from "../../source/installer/elevate.mjs";
import { buildInstaller, setupConfig, setupEntry } from "../../scripts/build-installer.mjs";
import { readFileSync } from "node:fs";

const exists = (path) => access(path).then(() => true, () => false);
async function scratch() { return mkdtemp(join(tmpdir(), "forge-installer-")); }
async function payload(root, version) {
  const dir = join(root, `payload-${version}`);
  await mkdir(join(dir, "resources"), { recursive: true });
  await writeFile(join(dir, "TestForge.exe"), `exe ${version}`);
  await writeFile(join(dir, "resources", "app.asar"), `asar ${version} `.repeat(2000));
  return { dir, manifest: await buildManifest(dir, { id: "testforge", version }) };
}
const common = (root) => ({ root: join(root, "local"), product: "TestForge", id: "testforge" });

test("versions compare numerically, not as text", () => {
  assert.deepEqual(parseVersion("2.7.13"), [2, 7, 13]);
  assert.equal(parseVersion("2.7"), null);
  assert.equal(compareVersions("2.7.6", "2.7.13"), -1);
  assert.equal(compareVersions("2.8.0", "2.7.13"), 1);
  assert.equal(compareVersions("2.7.6", "2.7.6"), 0);
  assert.throws(() => compareVersions("x", "2.7.6"), /Invalid version/);
});

test("the overwrite decision covers install, upgrade, repair, downgrade and a running app", () => {
  assert.deepEqual(decideInstall({ installed: null, incoming: "2.7.7" }).kind, "install");
  assert.equal(decideInstall({ installed: "2.7.6", incoming: "2.7.7" }).verb, "Upgrade");
  assert.equal(decideInstall({ installed: "2.7.6", incoming: "2.7.7" }).keepsPrevious, true);
  assert.equal(decideInstall({ installed: "2.7.7", incoming: "2.7.7" }).kind, "repair");
  assert.equal(decideInstall({ installed: "2.7.7", incoming: "2.7.7" }).keepsPrevious, false);
  assert.equal(decideInstall({ installed: "2.8.0", incoming: "2.7.7" }).kind, "downgrade");
  assert.equal(decideInstall({ installed: "2.7.6", incoming: "2.7.7", running: true }).blocked, "running");
});

test("payload copy verifies every file and rejects a changed one", async () => {
  const root = await scratch();
  try {
    const { dir, manifest } = await payload(root, "2.7.7");
    const events = [];
    const result = await copyPayload({ source: dir, manifest, destination: join(root, "out"), onProgress: (p) => events.push(p.done) });
    assert.equal(result.files, 2);
    assert.equal(await readFile(join(root, "out", "TestForge.exe"), "utf8"), "exe 2.7.7");
    assert.ok(events.length > 0 && events.at(-1) === manifest.bytes);
    await writeFile(join(dir, "TestForge.exe"), "tampered");
    await assert.rejects(copyPayload({ source: dir, manifest: { ...manifest, files: manifest.files.map((f) => f.path === "TestForge.exe" ? { ...f, size: 8 } : f) }, destination: join(root, "bad") }), { code: "CHECKSUM" });
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("manifest paths cannot leave the destination", () => {
  assert.throws(() => safeRelativePath("../evil.dll"), { code: "UNSAFE" });
  assert.throws(() => safeRelativePath("/etc/passwd"), { code: "UNSAFE" });
  assert.throws(() => safeRelativePath("C:\\Windows\\x.dll"), { code: "UNSAFE" });
  assert.ok(safeRelativePath("resources/app.asar"));
});

test("a fresh install lands in the family folder and is recorded", async () => {
  const root = await scratch();
  try {
    const one = await payload(root, "2.7.6");
    const steps = [];
    const result = await runInstall({ ...common(root), version: "2.7.6", source: one.dir, manifest: one.manifest, onEvent: (e) => e.step && steps.push(`${e.step}:${e.status}`) });
    assert.equal(result.kind, "install");
    const layout = installLayout(common(root).root, "TestForge");
    assert.equal(await readFile(join(layout.app, "TestForge.exe"), "utf8"), "exe 2.7.6");
    assert.equal((await readRegistry(layout.registry)).apps.testforge.version, "2.7.6");
    assert.deepEqual(steps, ["check:done", "unpack:start", "unpack:done", "switch:start", "switch:done"]);
    assert.equal(await exists(layout.staging), false);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("an upgrade keeps exactly one previous version and leaves user data alone", async () => {
  const root = await scratch();
  try {
    const data = join(root, "appdata", "TestForge", "settings.json");
    await mkdir(join(root, "appdata", "TestForge"), { recursive: true });
    await writeFile(data, "keep me");
    for (const version of ["2.7.5", "2.7.6", "2.7.7"]) {
      const p = await payload(root, version);
      await runInstall({ ...common(root), version, source: p.dir, manifest: p.manifest });
    }
    const layout = installLayout(common(root).root, "TestForge");
    assert.equal(await readFile(join(layout.app, "TestForge.exe"), "utf8"), "exe 2.7.7");
    assert.deepEqual(await readdir(layout.previous), ["TestForge-2.7.6"]);
    assert.equal(await readFile(data, "utf8"), "keep me");
    const state = await inspectInstall({ ...common(root), incoming: "2.7.7" });
    assert.equal(state.plan.kind, "repair");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("a downgrade needs force, and a running app blocks before anything changes", async () => {
  const root = await scratch();
  try {
    const newer = await payload(root, "2.8.0");
    await runInstall({ ...common(root), version: "2.8.0", source: newer.dir, manifest: newer.manifest });
    const older = await payload(root, "2.7.7");
    await assert.rejects(runInstall({ ...common(root), version: "2.7.7", source: older.dir, manifest: older.manifest }), { code: "NEWER" });
    await assert.rejects(runInstall({ ...common(root), version: "2.7.7", source: older.dir, manifest: older.manifest, force: true, running: true }), { code: "RUNNING" });
    const layout = installLayout(common(root).root, "TestForge");
    assert.equal(await readFile(join(layout.app, "TestForge.exe"), "utf8"), "exe 2.8.0");
    const forced = await runInstall({ ...common(root), version: "2.7.7", source: older.dir, manifest: older.manifest, force: true });
    assert.equal(forced.kind, "downgrade");
    assert.deepEqual(await readdir(layout.previous), ["TestForge-2.8.0"]);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("a corrupted payload leaves the installed version untouched and no staging folder", async () => {
  const root = await scratch();
  try {
    const good = await payload(root, "2.7.6");
    await runInstall({ ...common(root), version: "2.7.6", source: good.dir, manifest: good.manifest });
    const next = await payload(root, "2.7.7");
    await writeFile(join(next.dir, "resources", "app.asar"), "flipped");
    await assert.rejects(runInstall({ ...common(root), version: "2.7.7", source: next.dir, manifest: next.manifest }), { code: "CHECKSUM" });
    const layout = installLayout(common(root).root, "TestForge");
    assert.equal(await readFile(join(layout.app, "TestForge.exe"), "utf8"), "exe 2.7.6");
    assert.equal(await exists(layout.staging), false);
    assert.equal((await readRegistry(layout.registry)).apps.testforge.version, "2.7.6");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("cancelling stops the copy and removes the staging folder", async () => {
  const root = await scratch();
  try {
    const p = await payload(root, "2.7.6");
    const controller = new AbortController();
    await assert.rejects(runInstall({ ...common(root), version: "2.7.6", source: p.dir, manifest: p.manifest, signal: controller.signal, onEvent: (e) => { if (e.progress) controller.abort(); } }), { code: "ABORT" });
    const layout = installLayout(common(root).root, "TestForge");
    assert.equal(await exists(layout.staging), false);
    assert.equal(await exists(layout.app), false);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("uninstall removes the app and its kept version but not user data", async () => {
  const root = await scratch();
  try {
    for (const version of ["2.7.6", "2.7.7"]) {
      const p = await payload(root, version);
      await runInstall({ ...common(root), version, source: p.dir, manifest: p.manifest });
    }
    await mkdir(join(root, "appdata"), { recursive: true });
    await writeFile(join(root, "appdata", "keep.txt"), "x");
    const { layout } = await runUninstall(common(root));
    assert.equal(await exists(layout.app), false);
    assert.equal(await exists(layout.previous), false);
    assert.equal((await readRegistry(layout.registry)).apps.testforge, undefined);
    assert.equal(await exists(join(root, "appdata", "keep.txt")), true);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("Windows registration writes a machine-wide uninstall entry and file association", () => {
  const calls = [];
  const run = (command, args) => { calls.push([command, ...args].join(" ")); return ""; };
  registerApp({ run, id: "testforge", name: "TestForge", version: "2.7.7", installDir: "C:\\Program Files\\Forge\\TestForge", exe: "C:\\Program Files\\Forge\\TestForge\\TestForge.exe", publisher: "Forge", uninstall: "\"C:\\L\\Setup.exe\" /uninstall", extension: "tfg", documentIcon: "C:\\Program Files\\Forge\\.setup\\document.ico" });
  assert.ok(calls.every((c) => c.startsWith("reg add HKLM\\")));
  assert.ok(calls.some((c) => c.includes("Uninstall\\Forge.testforge") && c.includes("DisplayVersion") && c.includes("2.7.7")));
  assert.ok(calls.some((c) => c.includes("Classes\\.tfg") && c.includes("Forge.testforge.tfg")));
  assert.ok(calls.some((c) => c.includes("DefaultIcon") && c.includes("document.ico")));
  calls.length = 0;
  unregisterApp({ run, id: "testforge", extension: "tfg" });
  assert.equal(calls.length, 3);
  // Only the installed executable counts: the setup is a copy of the same executable, run from elsewhere.
  const installed = "C:\\Program Files\\Forge\\TestForge\\TestForge.exe";
  const processes = (paths) => (command, args) => { calls.push([command, ...args].join(" ")); return paths.join("\r\n"); };
  assert.equal(isRunning(processes(["C:\\Users\\x\\AppData\\Local\\Temp\\2abc\\TestForge.exe"]), installed), false);
  assert.equal(isRunning(processes(["C:\\Users\\x\\AppData\\Local\\Temp\\2abc\\TestForge.exe", "c:\\program files\\forge\\testforge\\TestForge.exe"]), installed), true);
  assert.equal(isRunning(processes([]), installed), false);
  assert.match(calls[calls.length - 1], /Get-Process -Name 'TestForge'/);
  assert.equal(isRunning(() => { throw new Error("no PowerShell"); }, installed), false);
});

test("the setup packs the app's own build once, with its manifest and document icon, and no second Electron", async () => {
  const root = await scratch();
  const prior = process.cwd();
  try {
    process.chdir(root);
    await mkdir(join("assets", "icon"), { recursive: true });
    await mkdir(join("node_modules", "electron"), { recursive: true });
    await mkdir(join("payload", "resources"), { recursive: true });
    await mkdir(join("build", "desktop", "setup"), { recursive: true });
    await writeFile(join("node_modules", "electron", "package.json"), JSON.stringify({ name: "electron", version: "44.5.1" }));
    await writeFile("payload/TestForge.exe", "exe");
    await writeFile("payload/resources/app.asar", "asar");
    await writeFile("build/desktop/setup/main.cjs", "// setup");
    await writeFile("assets/icon/tfg.ico", "ico");
    await writeFile("assets/logo.txt", "TestForge\n");
    await writeFile("VERSION", "1.0.0\n");
    const accents = { accent: "#f09090", accentLight: "#f09090", accentAbout: "#f09090", accentFill: "#963939", accentHover: "#7c2626" };
    await writeFile("forge.config.json", JSON.stringify({ identity: { id: "testforge", name: "TestForge", purpose: "test app", versionSource: "VERSION", wordmarkPath: "logo.txt" },
      theme: { dark: accents, light: { ...accents, accent: "#a52b2b", accentLight: "#a52b2b", accentAbout: "#a52b2b" } }, document: { extension: "tfg" },
      desktop: { document: { iconStem: "tfg" } } }));
    const result = await buildInstaller({ payloadDir: "payload", stageOnly: true });
    const builder = JSON.parse(await readFile(result.builderConfig, "utf8"));
    assert.equal(builder.electronVersion, "44.5.1");
    // requireAdministrator stops Chromium's sandboxed helpers (Windows error 740); the setup elevates itself.
    assert.equal(builder.win.requestedExecutionLevel, "asInvoker");
    // The app's build is packed as it is: no files, extra resources or Electron of a separate setup app.
    assert.equal(builder.productName, "TestForge");
    assert.equal(builder.files, undefined);
    assert.equal(builder.extraResources, undefined);
    // the setup is built apart from the payload folder, or it would be embedded in itself
    assert.ok(builder.directories.output.endsWith(join("build", "setup", "out")));
    const staged = join("build", "setup", "app");
    assert.deepEqual(result.manifest.files.map((file) => file.path).sort(), ["TestForge.exe", "resources/app.asar", "resources/testforge-document.ico"]);
    assert.equal(JSON.parse(await readFile(join(staged, "resources", "payload.json"), "utf8")).files.length, 3, "the manifest lists every file but itself");
    assert.equal(await readFile(join(staged, "resources", "testforge-document.ico"), "utf8"), "ico");
    assert.equal(await exists(join("payload", "resources", "payload.json")), false, "the app's own build is left unchanged");
    await rm(join("build", "desktop", "setup", "main.cjs"));
    await assert.rejects(buildInstaller({ payloadDir: "payload", stageOnly: true }), /buildForgeApp/);
    await writeFile("build/desktop/setup/main.cjs", "// setup");
    await rm(join("node_modules", "electron"), { recursive: true });
    await assert.rejects(buildInstaller({ payloadDir: "payload", stageOnly: true }), /electron is not installed/);
  } finally { process.chdir(prior); await rm(root, { recursive: true, force: true }); }
});

test("the app's entry runs the setup only on Windows when started from the setup executable or with --forge-setup", () => {
  const entry = setupEntry();
  const runs = (platform, env, argv) => {
    const required = [];
    new Function("process", "require", entry)({ platform, env, argv }, (path) => required.push(path));
    return required[0];
  };
  assert.equal(runs("win32", { PORTABLE_EXECUTABLE_FILE: "D:\\TestForge-v1.0.0.exe" }, ["x"]), "./setup/main.cjs");
  assert.equal(runs("win32", {}, ["x", "--forge-setup-env=e30"]), "./setup/main.cjs");
  assert.equal(runs("win32", {}, ["x", "report.tfg"]), "./app-main.cjs");
  assert.equal(runs("darwin", { PORTABLE_EXECUTABLE_FILE: "x" }, ["x"]), "./app-main.cjs");
  assert.deepEqual(setupConfig({ identity: { id: "a", name: "A", purpose: "p" }, document: null }, "1.0.0").documentIcon, null);
});

test("the installed app starts without the setup's variables, so it starts as itself", () => {
  const env = { PATH: "C:\\Windows", PORTABLE_EXECUTABLE_FILE: "D:\\A.exe", PORTABLE_EXECUTABLE_DIR: "D:\\", FORGE_SETUP_LOG_DIR: "D:\\logs", FORGE_CAPTURE: "x.png" };
  assert.deepEqual(appEnvironment(env), { PATH: "C:\\Windows", FORGE_CAPTURE: "x.png" });
  const source = readFileSync(new URL("../../source/installer/main.mjs", import.meta.url), "utf8");
  assert.ok(source.includes("env: appEnvironment(process.env)"));
  assert.ok(source.includes("dirname(process.execPath)"), "the files to install are the app's own folder");
  assert.ok(source.indexOf('app.setPath("userData"') < source.indexOf("requestSingleInstanceLock"), "the setup has its own settings folder before it takes the lock");
});

test("the setup reads its own packaged files before turning asar handling off", () => {
  // process.noAsar hides everything inside the setup's own app.asar, including setup.json.
  const source = readFileSync(new URL("../../source/installer/main.mjs", import.meta.url), "utf8");
  const read = source.indexOf('join(__dirname, "setup.json")');
  const off = source.indexOf("process.noAsar = true");
  assert.ok(read > 0 && off > 0, "both statements are present");
  assert.ok(read < off, "setup.json must be read before process.noAsar is set");
});

test("the install folder is Program Files-style: <root>\\Forge\\<Product>, and the family can be changed", () => {
  const layout = installLayout("C:\\Program Files", "TestForge");
  assert.ok(layout.app.endsWith(join("Forge", "TestForge")));
  assert.ok(installLayout("C:\\Program Files", "TestForge", "Other").app.endsWith(join("Other", "TestForge")));
  const calls = [];
  registerApp({ run: (command, args) => { calls.push([command, ...args].join(" ")); return ""; }, id: "testforge", name: "TestForge", version: "1.0.0", installDir: "x", exe: "y", publisher: "Other", uninstall: "z", extension: "tfg", family: "Other" });
  assert.ok(calls.some((c) => c.includes("Uninstall\\Other.testforge")));
});

test("uninstall removes only its own kept versions and cleans up when the last app goes", async () => {
  const root = await scratch();
  try {
    const other = (r) => ({ ...common(r), product: "OtherForge", id: "otherforge" });
    for (const make of [common, other]) {
      for (const version of ["1.0.0", "1.1.0"]) {
        const p = await payload(root, version);
        await runInstall({ ...make(root), version, source: p.dir, manifest: p.manifest });
      }
    }
    const { layout } = await runUninstall(common(root));
    assert.deepEqual((await readdir(layout.previous)).filter((name) => name.startsWith("TestForge-")), []);
    assert.equal((await readdir(layout.previous)).some((name) => name.startsWith("OtherForge-")), true);
    assert.equal(await exists(layout.registry), true);
    await runUninstall(other(root));
    assert.equal(await exists(layout.registry), false);
    assert.equal(await exists(layout.family), false);
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("a silent setup logs to <temp>\\<family> setup unless FORGE_SETUP_LOG_DIR names a folder", () => {
  assert.equal(setupLogDir({ env: {}, temp: "T", family: "Forge" }), join("T", "Forge setup"));
  assert.equal(setupLogDir({ env: { FORGE_SETUP_LOG_DIR: "" }, temp: "T", family: "Forge" }), join("T", "Forge setup"));
  assert.equal(setupLogDir({ env: { FORGE_SETUP_LOG_DIR: "D:\\logs" }, temp: "T", family: "Forge" }), "D:\\logs");
});

test("the setup log appends one timed line per entry, with an error's code and stack", async () => {
  const root = await scratch();
  try {
    const time = new Date("2026-10-17T19:13:20.000Z");
    assert.equal(logLine(time, "Ready."), "2026-10-17T19:13:20.000Z Ready.\n");
    assert.equal(logLine(time, { step: "unpack", status: "done" }), '2026-10-17T19:13:20.000Z {"step":"unpack","status":"done"}\n');
    const error = Object.assign(new Error("Checksum mismatch: a.txt."), { code: "CHECKSUM" });
    assert.ok(logLine(time, error).startsWith("2026-10-17T19:13:20.000Z [CHECKSUM] Error: Checksum mismatch: a.txt."));
    const log = openSetupLog(join(root, "nested", "setup-log"), "testforge", () => time);
    log.write("Start.");
    log.write("Exit 0.");
    assert.equal(log.path, join(root, "nested", "setup-log", "testforge-setup.log"));
    assert.equal(readFileSync(log.path, "utf8"), "2026-10-17T19:13:20.000Z Start.\n2026-10-17T19:13:20.000Z Exit 0.\n");
    // A log that cannot be written is ignored rather than stopping the setup.
    assert.doesNotThrow(() => openSetupLog(join(log.path, "under-a-file"), "testforge").write("Lost."));
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("a silent setup records its stages and keeps crash dumps locally, beside the log", () => {
  const source = readFileSync(new URL("../../source/installer/main.mjs", import.meta.url), "utf8");
  const dumps = source.indexOf('app.setPath("crashDumps"');
  const start = source.indexOf("crashReporter.start({ uploadToServer: false })");
  assert.ok(dumps > 0 && start > dumps, "the dump folder is set before the crash reporter starts");
  for (const entry of ['record.write("Ready.")', "record.write(`Exit ${code}.`)", '"child-process-gone"', "record.write(error)"]) assert.ok(source.includes(entry), `logs ${entry}`);
});

test("an elevated token is recognised from its mandatory level in whoami /groups", () => {
  const medium = "Mandatory Label\\Medium Mandatory Level Label S-1-16-8192";
  assert.equal(isElevated(medium), false);
  assert.equal(isElevated("Mandatory Label\\High Mandatory Level Label S-1-16-12288"), true);
  assert.equal(isElevated("Mandatory Label\\System Mandatory Level Label S-1-16-16384"), true);
  assert.equal(isElevated(""), false);
});

test("the elevated copy receives the setup's variables through one argument", () => {
  const env = { PATH: "C:\\Windows", FORGE_CAPTURE: "D:\\a b\\setup-window.png", FORGE_SETUP_LOG_DIR: "D:\\logs", PORTABLE_EXECUTABLE_FILE: "D:\\Example-v1.0.0.exe" };
  assert.deepEqual(Object.keys(forwardedEnv(env)).sort(), ["FORGE_CAPTURE", "FORGE_SETUP_LOG_DIR", "PORTABLE_EXECUTABLE_FILE"]);
  const carrier = envArgument(env);
  assert.ok(carrier.startsWith(ENV_ARGUMENT));
  assert.match(carrier.slice(ENV_ARGUMENT.length), /^[A-Za-z0-9_-]+$/, "base64url needs no quoting");
  const restored = { PATH: "unchanged" };
  assert.deepEqual(restoreEnv(["/S", carrier], restored), ["/S"]);
  assert.deepEqual(restored, { PATH: "unchanged", FORGE_CAPTURE: env.FORGE_CAPTURE, FORGE_SETUP_LOG_DIR: env.FORGE_SETUP_LOG_DIR, PORTABLE_EXECUTABLE_FILE: env.PORTABLE_EXECUTABLE_FILE });
  assert.deepEqual(restoreEnv(["/uninstall"], restored), ["/uninstall"]);
});

test("the elevation script waits for the elevated copy, passes its exit code and reports a declined prompt as Cancelled", () => {
  const script = elevationScript("C:\\Temp\\O'Brien\\Example Setup.exe", ["/S", "/force", "with space"]);
  assert.ok(script.includes("-FilePath 'C:\\Temp\\O''Brien\\Example Setup.exe'"), "single quotes are doubled");
  assert.ok(script.includes(`-ArgumentList '/S /force "with space"'`));
  assert.ok(script.includes("-Verb RunAs -Wait -PassThru"));
  assert.ok(script.includes(`catch { exit ${DECLINED} }`) && DECLINED === 5);
  assert.ok(script.endsWith("exit $p.ExitCode"));
  assert.equal(Buffer.from(encodedCommand(script), "base64").toString("utf16le"), script);
});

test("the setup restores forwarded variables before reading any, and elevates before it opens a window", () => {
  const source = readFileSync(new URL("../../source/installer/main.mjs", import.meta.url), "utf8");
  const restore = source.indexOf("restoreEnv(process.argv.slice(1), process.env)");
  assert.ok(restore > 0 && restore < source.indexOf("process.env.FORGE_SETUP_RESOURCES"), "restored before the first read");
  const elevate = source.indexOf("elevationScript(process.execPath");
  assert.ok(elevate > 0 && elevate < source.indexOf("requestSingleInstanceLock") && elevate < source.indexOf("new BrowserWindow"));
});
