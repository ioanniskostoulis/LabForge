import assert from "node:assert/strict";
import { test } from "node:test";
import { TOOL_GROUP_ORDER, dialogButtonOrder, toolGroupIndex, type DialogButton } from "../../source/app/layout-order";

test("tool strip groups take the shared order whatever order an application adds them in", () => {
  assert.deepEqual([...TOOL_GROUP_ORDER], ["history", "clipboard", "view", "app", "search"]);
  // search first, then history, then an app group: search stays at the right
  const placed: (typeof TOOL_GROUP_ORDER)[number][] = [];
  for (const kind of ["search", "history", "app", "view", "clipboard"] as const) placed.splice(toolGroupIndex(placed, kind), 0, kind);
  assert.deepEqual(placed, ["history", "clipboard", "view", "app", "search"]);
  // two app groups keep the order they were added in
  assert.equal(toolGroupIndex(["history", "app", "search"], "app"), 2);
});

test("dialog buttons follow the platform: macOS ends with Cancel and the primary action, Windows starts with it", () => {
  const buttons: DialogButton[] = [{ label: "Cancel", role: "cancel" }, { label: "Save", role: "primary" }, { label: "Don't save", role: "destructive" }];
  const labels = (mac: boolean) => dialogButtonOrder(buttons, mac).map((button) => button?.label ?? "—");
  assert.deepEqual(labels(true), ["Don't save", "—", "Cancel", "Save"]);
  assert.deepEqual(labels(false), ["—", "Save", "Don't save", "Cancel"]);
});
