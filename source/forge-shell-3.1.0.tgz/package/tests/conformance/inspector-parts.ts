import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { createButton, createButtonGroup, createInfoLines } from "../../source/app/builders";
import { TREE_STATUS, treeBadges, type TreeFile } from "../../source/app/file-tree";
import { createViewHeader } from "../../source/app/view-header";
import { UI_ICONS } from "../../source/app/tool-icons";

const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");
/** The declarations of the first rule whose selector list is exactly `selector`. */
const rule = (selector: string) => {
  const start = css.indexOf(`${selector} {`);
  assert.ok(start >= 0, `missing ${selector}`);
  return css.slice(start, css.indexOf("}", start));
};

class Element {
  className = ""; textContent = ""; type = ""; disabled = false; children: Element[] = []; attributes: Record<string, string> = {}; dataset: Record<string, string> = {};
  append(...items: Element[]) { this.children.push(...items); }
  replaceChildren(...items: Element[]) { this.children = items; }
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
  addEventListener() {}
}
const doc = { createElement: () => new Element() } as unknown as Pick<Document, "createElement">;

test("every file in the tree shows its status, editable or read-only or the app's own, and folders show none", () => {
  const host = { status: (file: TreeFile) => (file.path === "main.tex" ? "editable" as const : file.path.endsWith(".csv") ? { icon: UI_ICONS.lock, label: "Linked data file." } : "readOnly" as const) };
  assert.deepEqual(treeBadges(host, { path: "main.tex", kind: "tex" }), [TREE_STATUS.editable]);
  assert.deepEqual(treeBadges(host, { path: "figures/plot.png", kind: "image" }), [TREE_STATUS.readOnly]);
  assert.deepEqual(treeBadges(host, { path: "data/run.csv", kind: "data" }), [{ icon: UI_ICONS.lock, label: "Linked data file." }]);
  assert.deepEqual(treeBadges(host, { path: "figures", kind: "folder" }), [], "a folder has no status");
  assert.deepEqual(treeBadges(host, undefined), [], "nor does a folder made from a file's path");
  assert.deepEqual(TREE_STATUS, { editable: { icon: UI_ICONS.edit, label: "Editable file." }, readOnly: { icon: UI_ICONS.readOnly, label: "Read-only file." } });
  const both = { status: () => "readOnly" as const, badges: () => [{ icon: UI_ICONS.link, label: "Linked." }] };
  assert.deepEqual(treeBadges(both, { path: "a.txt", kind: "text" }).map((badge) => badge.label), ["Read-only file.", "Linked."], "the status comes first");
  assert.deepEqual(treeBadges({}, { path: "a.txt", kind: "text" }), [], "an app without statuses shows none");
});

test("info lines show the item's name, then its values, and the empty sentence when there is no item", () => {
  const info = createInfoLines("Hover or click a part.", doc);
  const shown = () => (info.element as unknown as Element).children.map((child) => [child.className, child.textContent]);
  assert.equal((info.element as unknown as Element).className, "info-lines");
  assert.deepEqual(shown(), [["muted", "Hover or click a part."]]);
  info.show(["R1", "I = 1.2 mA", "V = 3.3 V"]);
  assert.deepEqual(shown(), [["first", "R1"], ["", "I = 1.2 mA"], ["", "V = 3.3 V"]]);
  info.show([]);
  assert.deepEqual(shown(), [["muted", "Hover or click a part."]], "no lines is no item");
  assert.match(rule(".info-lines"), /var\(--mono\)/);
  assert.match(rule(".info-lines .first"), /var\(--ui\)/);
});

test("buttons share a group's width at 24 px, and each kind shows whether it can be clicked", () => {
  const group = createButtonGroup([createButton({ label: "Run", primary: true }, doc), createButton({ label: "Open PDF", disabled: true }, doc)], doc) as unknown as Element;
  assert.equal(group.className, "buttons");
  assert.deepEqual(group.children.map((button) => [button.className, button.disabled]), [["panel-button primary", false], ["panel-button", true]]);
  assert.match(rule(".panel-button"), /flex: 1;[\s\S]*height: calc\(var\(--control-height\) - 2px\);[\s\S]*border-radius: var\(--radius\);[\s\S]*background: var\(--control\);/);
  assert.match(rule(".panel-button.primary"), /background: var\(--accent-fill\); color: var\(--accent-foreground\);/);
  // hover changes only an enabled, idle button
  assert.ok(css.includes(".panel-button:hover:not(:disabled):not([aria-busy=\"true\"]) { background: var(--control-hover); }"));
  assert.ok(css.includes(".panel-button.primary:hover:not(:disabled):not([aria-busy=\"true\"]) { background: var(--accent-hover); }"));
  // a disabled button of either kind keeps its fill: the ordinary one dims its label to --text3, the primary one to the
  // foreground mixed into the accent fill
  assert.match(rule(".panel-button:disabled"), /color: var\(--text3\); cursor: default;/);
  assert.doesNotMatch(rule(".panel-button:disabled"), /background/, "the ordinary fill is kept");
  assert.match(rule(".panel-button.primary:disabled"), /color: color-mix\(in srgb, var\(--accent-foreground\) 55%, var\(--accent-fill\)\);/);
  assert.doesNotMatch(rule(".panel-button.primary:disabled"), /background/, "the accent fill is kept");
  assert.match(rule(".panel-button[aria-busy=\"true\"]"), /cursor: progress/);
  assert.match(rule(".panel-button:focus-visible"), /outline: 1px solid var\(--accent-light\)/);
});

test("a disabled primary label is the foreground 55 % into the accent fill: legible, and clearly dimmer than enabled", async () => {
  const { contrastRatio } = await import("../../scripts/theme.mjs");
  /** `foreground` mixed into `fill` by `share`, as CSS color-mix in sRGB does. */
  const mix = (foreground: string, fill: string, share: number) => {
    const rgb = (hex: string) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
    const [f, b] = [rgb(foreground), rgb(fill)];
    return `#${f.map((value, i) => Math.round(value * share + b[i] * (1 - share)).toString(16).padStart(2, "0")).join("")}`;
  };
  // accent fills in use across the family, and the Pride purple
  for (const fill of ["#1e8052", "#2e7f4d", "#3c56aa", "#a82a2d", "#773c8d"]) {
    const disabled = contrastRatio(mix("#ffffff", fill, 0.55), fill), enabled = contrastRatio("#ffffff", fill);
    assert.ok(disabled >= 2.5, `${fill}: disabled label ${disabled.toFixed(2)}:1 is legible`);
    assert.ok(enabled - disabled >= 1.8, `${fill}: ${disabled.toFixed(2)}:1 against ${enabled.toFixed(2)}:1 enabled is clearly dimmer`);
  }
  // --text3 on the fill, the rule it replaces, all but disappears
  assert.ok(contrastRatio("#666666", "#2e7f4d") < 1.2);
});

test("chips are a button group: 24 px, radius 4, sharing the width, the chosen one in the accent fill", () => {
  assert.match(rule(".chips"), /display: flex; gap: var\(--gap\);/);
  const chip = rule(".chip");
  for (const part of ["flex: 1;", "height: calc(var(--control-height) - 2px);", "border-radius: var(--radius);", "background: var(--control);", "color: var(--text);"]) assert.ok(chip.includes(part), part);
  assert.doesNotMatch(chip, /border-radius: 11px|border: 1px/, "no pill and no outline");
  assert.match(rule(".chip[aria-checked=\"true\"]"), /background: var\(--accent-fill\); color: var\(--accent-foreground\);/);
  assert.match(rule(".chip:disabled"), /color: var\(--text3\)/);
  assert.match(rule(".chip[aria-checked=\"true\"]:disabled"), /color: color-mix\(in srgb, var\(--accent-foreground\) 55%, var\(--accent-fill\)\)/);
  assert.match(rule(".chip:focus-visible"), /outline: 1px solid var\(--accent-light\)/);
});

test("a file's status is shown in the tree only: a view header carries no editable or read-only icon", () => {
  class Node extends Element { innerHTML = ""; title = ""; }
  const saved = (globalThis as { document?: unknown }).document;
  (globalThis as { document?: unknown }).document = { createElement: () => new Node() };
  try {
    const kinds = (header: Element) => header.children.map((child) => child.className);
    const header = createViewHeader({ title: "main.tex", dirty: true, mode: "readOnly", onClose() {} }) as unknown as Element;
    assert.deepEqual(kinds(header), ["view-dirty on", "view-title", "view-space", "view-action view-close"], "the deprecated mode adds nothing");
    assert.ok(header.children.every((child) => !(child as Node).innerHTML.includes(UI_ICONS.edit) && !(child as Node).innerHTML.includes(UI_ICONS.readOnly)));
  } finally {
    (globalThis as { document?: unknown }).document = saved;
  }
  assert.doesNotMatch(css, /\.view-mode/);
});
