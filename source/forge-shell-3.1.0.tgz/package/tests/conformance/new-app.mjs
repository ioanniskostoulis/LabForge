import assert from "node:assert/strict";
import { mkdtempSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { createNewApp, fillTemplate, missingIcons, newAppConfig, newAppOptions, solidPng } from "../../scripts/new-app.mjs";
import { electronBuilderConfig } from "../../scripts/package-config.mjs";
import { lintApp } from "../../scripts/style-lint.mjs";
import { checkBrandAccents, contrastRatio } from "../../scripts/theme.mjs";
import { renderWordmark } from "../../scripts/wordmark.mjs";

const files = (dir, base = dir) => readdirSync(dir).flatMap((entry) => {
  const path = join(dir, entry);
  return statSync(path).isDirectory() ? files(path, base) : [path.slice(base.length + 1)];
});

test("a new app is named by one capitalised word; its extension is the first letter and fg unless given", () => {
  const options = newAppOptions({ name: "Example", accent: "#4c8fe8" });
  assert.equal(options.id, "example");
  assert.equal(options.extension, "efg");
  assert.equal(newAppOptions({ name: "Example", extension: ".exm" }).extension, "exm");
  assert.ok(options.port >= 1024 && options.port < 65536);
  assert.match(options.shellDependency, /^file:source\/forge-shell-\d+\.\d+\.\d+\.tgz$/);
  assert.throws(() => newAppOptions({ name: "example" }), /one word starting with a capital letter/);
  assert.throws(() => newAppOptions({ name: "Two Words" }), /one word/);
  assert.throws(() => newAppOptions({ name: "Example", extension: "x" }), /2 to 8 lowercase letters/);
  assert.throws(() => newAppOptions({ name: "Example", repository: "https://github.com/owner/example" }), /owner\/name/);
  assert.equal(newAppConfig(newAppOptions({ name: "Example", repository: "owner/example" })).identity.repository, "owner/example");
  assert.equal("repository" in newAppConfig(newAppOptions({ name: "Example" })).identity, false);
  assert.throws(() => newAppConfig(newAppOptions({ name: "Example", accent: "blue" })), /six-digit hex colour/);
});

test("the profile of a new app has both appearances' accents, readable on the shared surfaces, and packages as is", () => {
  for (const accent of ["#3fae6a", "#e84c4c", "#4c8fe8", "#f2c94c", "#101010"]) {
    const config = newAppConfig(newAppOptions({ name: "Example", accent }));
    assert.deepEqual(Object.keys(config.theme), ["dark", "light"]);
    checkBrandAccents(config.theme);
    assert.ok(contrastRatio(config.theme.dark.accent, "#1b1b1b") >= 4.5);
    assert.ok(contrastRatio("#ffffff", config.theme.dark.accentFill) >= 4.5);
    const builder = electronBuilderConfig(config);
    assert.equal(builder.appId, "com.example.app");
    assert.equal(config.document.extension, "efg");
    assert.equal(config.document.containsMultipleFiles, false);
  }
});

test("templates take the name, id, extension and the other placeholders", () => {
  const options = newAppOptions({ name: "Example", purpose: "test workspace", author: "Someone", port: 4999 });
  assert.equal(fillTemplate("__NAME__ __ID__ .__EXT__ __PURPOSE__ __AUTHOR__ __PORT__", options), "Example example .efg test workspace Someone 4999");
});

test("the placeholder icon is a valid square PNG in the accent", () => {
  const png = solidPng("#4c8fe8", 16);
  assert.deepEqual([...png.subarray(0, 8)], [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  assert.equal(png.readUInt32BE(16), 16);
  assert.equal(png.readUInt32BE(20), 16);
});

test("a new app is written whole: no placeholder left, its wordmark, workflows, icon and licence, and clean style", () => {
  const dir = mkdtempSync(join(tmpdir(), "new-app-"));
  try {
    const target = join(dir, "Example");
    const written = createNewApp(target, { name: "Example", accent: "#4c8fe8", author: "Someone" });
    const present = files(target).sort();
    assert.deepEqual(written, present);
    for (const file of ["forge.config.json", "package.json", "VERSION", "LICENSE", ".gitignore", "assets/logo.txt", "assets/icon.png",
      "source/app/main.ts", "source/desktop/main.ts", "source/desktop/preload.ts", "public/center.html", "public/panes.html", "public/app.css",
      "scripts/build.mjs", "scripts/check-windows-capture.ps1", "scripts/check-windows-installer.ps1", ".github/workflows/build-desktop-apps.yml"]) {
      assert.ok(present.includes(file), `missing ${file}`);
    }
    for (const file of present.filter((file) => !file.endsWith(".png") && file !== "LICENSE")) {
      assert.doesNotMatch(readFileSync(join(target, file), "utf8"), /__(NAME|ID|EXT|PURPOSE|AUTHOR|PORT|SHELL_DEP)__/, `placeholder left in ${file}`);
    }
    assert.equal(readFileSync(join(target, "assets/logo.txt"), "utf8"), `${renderWordmark("Example")}\n`);
    // The document icons are made when Python 3 with Pillow is present, and reported missing otherwise.
    assert.equal(missingIcons(target), !present.includes("assets/icon/efg.icns"));
    const pkg = JSON.parse(readFileSync(join(target, "package.json"), "utf8"));
    assert.equal(pkg.name, "example");
    assert.equal(pkg.version, readFileSync(join(target, "VERSION"), "utf8").trim());
    const config = JSON.parse(readFileSync(join(target, "forge.config.json"), "utf8"));
    assert.equal(config.identity.name, "Example");
    // The profile's repository is optional: an app generated without one still type-checks.
    assert.match(readFileSync(join(target, "source/app/main.ts"), "utf8"), /\(config\.identity as \{ repository\?: string \}\)\.repository/);
    // The generated source draws nothing itself: no raw colours, inline styles or hand-drawn shared icons.
    const problems = lintApp({ cssFiles: [join(target, "public/app.css")], sourceDir: join(target, "source"), dataColors: config.dataColors ?? [] });
    assert.deepEqual(problems, []);
    // A new app is never written over an existing one.
    writeFileSync(join(dir, "taken"), "");
    assert.throws(() => createNewApp(dir, { name: "Example" }), /is not empty/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
