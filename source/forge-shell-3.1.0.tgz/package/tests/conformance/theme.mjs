import assert from "node:assert/strict";
import test from "node:test";
import { brandCss, checkBrandAccents, contrastRatio } from "../../scripts/theme.mjs";

test("brand accents are app-specific while low-contrast controls are rejected", () => {
  const mode = { accent: "#f09090", accentLight: "#f09090", accentAbout: "#f09090", accentFill: "#963939", accentHover: "#7c2626" };
  const theme = { dark: mode, light: { ...mode, accent: "#a52b2b", accentLight: "#a52b2b", accentAbout: "#a52b2b" } };
  assert.doesNotThrow(() => checkBrandAccents(theme));
  assert.match(brandCss(theme), /body\[data-theme="light"\]/);
  assert.ok(contrastRatio("#963939", "#ffffff") >= 4.5);
  assert.throws(() => checkBrandAccents({ ...theme, light: { ...theme.light, accentFill: "#dddddd" } }), /4.5:1 contrast/);
});

const nodeLike = { accent: "#7b90df", accentLight: "#7b90df", accentAbout: "#899de6", accentFill: "#3c56aa", accentHover: "#344c98" };

test("an omitted Light theme is the calmer fill-based set, and omitted Dark variants default to the accent", () => {
  const css = brandCss({ dark: nodeLike });
  const light = css.slice(css.indexOf('body[data-theme="light"]'));
  for (const name of ["accent", "accent-light", "accent-about", "accent-fill"]) assert.match(light, new RegExp(`--${name}: #3c56aa;`));
  assert.match(light, /--accent-hover: #344c98;/);
  const minimal = brandCss({ dark: { accent: "#7b90df", accentFill: "#3c56aa", accentHover: "#344c98" } });
  assert.match(minimal, /:root \{[^}]*--accent-light: #7b90df;[^}]*--accent-about: #7b90df;/);
});

test("a partial Light theme keeps what the app specifies and derives the rest", () => {
  const css = brandCss({ dark: nodeLike, light: { accent: "#425dc3" } });
  const light = css.slice(css.indexOf('body[data-theme="light"]'));
  assert.match(light, /--accent: #425dc3;/);
  assert.match(light, /--accent-fill: #3c56aa;/);
});

test("a derived Light set that fails contrast is rejected", () => {
  assert.throws(() => brandCss({ dark: { ...nodeLike, accentFill: "#8899dd" } }), /4.5:1 contrast/);
});
