import assert from "node:assert/strict";
import { test } from "node:test";
import { SPLIT_MIN, splitShare } from "../../source/app/splitter";
import { outlineNumbers } from "../../source/app/outline-list";
import { filterRows } from "../../source/app/dialogs";

test("a divider keeps each pane at least 160 px, and an area too small for both splits in half", () => {
  assert.equal(SPLIT_MIN, 160);
  assert.equal(splitShare(500, 1000), 0.5);
  assert.equal(splitShare(100, 1000), 0.16, "the first pane keeps 160 px");
  assert.equal(splitShare(990, 1000), 0.84, "so does the second");
  assert.equal(splitShare(100, 300), 0.5);
});

test("an outline is numbered by level, and a deeper level restarts when a shallower one advances", () => {
  assert.deepEqual(outlineNumbers([{ level: 1 }, { level: 2 }, { level: 2 }, { level: 1 }, { level: 2 }, { level: 3 }]), ["1", "1.1", "1.2", "2", "2.1", "2.1.1"]);
  // levels that start deeper than 1 count from their own top level; a jump down two levels fills the gap with 1
  assert.deepEqual(outlineNumbers([{ level: 2 }, { level: 4 }, { level: 2 }]), ["1", "1.1.1", "2"]);
});

test("a table picker keeps the rows that contain every word typed, ignoring case", () => {
  const rows = [{ id: "a", cells: ["1N4148", "Diode", "fast switching"] }, { id: "b", cells: ["1N4007", "Diode", "rectifier"] }, { id: "c", cells: ["2N2222", "Transistor", "NPN"] }];
  assert.deepEqual(filterRows(rows, "").map((row) => row.id), ["a", "b", "c"]);
  assert.deepEqual(filterRows(rows, "diode").map((row) => row.id), ["a", "b"]);
  assert.deepEqual(filterRows(rows, "DIODE rect").map((row) => row.id), ["b"]);
  assert.deepEqual(filterRows(rows, "zener").map((row) => row.id), []);
});
