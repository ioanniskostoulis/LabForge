import assert from "node:assert/strict";
import { test } from "node:test";
import { DARK_TITLE_BAR, DARK_WINDOW_BACKGROUND, TITLE_BAR_HEIGHT, registerTitleBarIpc, usesNativeMenu, windowChrome } from "../../source/desktop/title-bar";

test("Windows hides its title bar and keeps its window controls beside the drawn menu bar; macOS keeps its traffic lights", () => {
  assert.deepEqual(windowChrome("win32"), { titleBarStyle: "hidden", titleBarOverlay: { ...DARK_TITLE_BAR, height: 32 } });
  assert.equal(TITLE_BAR_HEIGHT, 32);
  assert.deepEqual(windowChrome("darwin"), { titleBarStyle: "hidden", trafficLightPosition: { x: 16, y: 14 } });
  assert.deepEqual(windowChrome("linux"), {});
  assert.equal(DARK_WINDOW_BACKGROUND, "#1e1e1e");
  assert.equal(usesNativeMenu("win32"), false);
  assert.equal(usesNativeMenu("darwin"), true);
});

test("the window controls take the page's colours, and anything that is not a colour is ignored", () => {
  const handlers = new Map<string, (event: { sender: unknown }, ...args: any[]) => void>();
  const set: unknown[] = [];
  registerTitleBarIpc({ on: (channel, handler) => handlers.set(channel, handler) }, () => ({ setTitleBarOverlay: (options) => set.push(options) }));
  const send = handlers.get("setTitleBar")!;
  send({ sender: 1 }, { color: "rgb(222, 222, 222)", symbolColor: "#222222" });
  send({ sender: 1 }, { color: "url(javascript:alert(1))", symbolColor: "#222222" });
  send({ sender: 1 }, null);
  assert.deepEqual(set, [{ color: "rgb(222, 222, 222)", symbolColor: "#222222", height: 32 }]);
  // a window without controls (macOS) is left alone
  registerTitleBarIpc({ on: (channel, handler) => handlers.set(channel, handler) }, () => ({}));
  assert.doesNotThrow(() => handlers.get("setTitleBar")!({ sender: 1 }, { color: "#000", symbolColor: "#fff" }));
});
