import assert from "node:assert/strict";
import { test } from "node:test";
import { greater, repinArchive, repinLockEntry, semver, setLockVersion, setPackageVersion, stampChangelog } from "../../scripts/release-shell.mjs";

test("versions are compared numerically", () => {
  assert.ok(semver.test("1.5.10") && !semver.test("1.5"));
  assert.ok(greater("1.5.10", "1.5.9") > 0);
  assert.ok(greater("1.5.5", "1.5.5") === 0);
  assert.ok(greater("2.0.0", "1.9.9") > 0);
});

test("version files and the changelog are stamped", () => {
  assert.equal(setPackageVersion('{\n  "name": "x",\n  "version": "1.5.4",\n  "dependencies": { "a": { "version": "9" } }\n}', "1.5.5").match(/"version": "([^"]+)"/)[1], "1.5.5");
  const lock = '{"version": "1.5.4", "packages": {"": {"version": "1.5.4"}, "node_modules/a": {"version": "3.0.0"}}}';
  assert.equal(setLockVersion(lock, "1.5.5"), '{"version": "1.5.5", "packages": {"": {"version": "1.5.5"}, "node_modules/a": {"version": "3.0.0"}}}');
  assert.equal(stampChangelog("# Changelog\n\n## Unreleased\n\n- x\n\n## 1.5.4\n", "1.5.5"), "# Changelog\n\n## 1.5.5\n\n- x\n\n## 1.5.4\n");
  assert.throws(() => stampChangelog("# Changelog\n\n## 1.5.4\n", "1.5.5"), /Unreleased/);
});

test("an app's archive pin and lockfile entry are rewritten", () => {
  assert.equal(repinArchive('"forge-shell": "file:source/forge-shell-1.5.4.tgz"', "1.5.5"), '"forge-shell": "file:source/forge-shell-1.5.5.tgz"');
  const lock = '"node_modules/forge-shell": {\n      "version": "1.5.4",\n      "resolved": "file:source/forge-shell-1.5.5.tgz",\n      "integrity": "sha512-old",';
  const next = repinLockEntry(lock, "1.5.5", "sha512-new");
  assert.match(next, /"version": "1.5.5"/);
  assert.match(next, /"integrity": "sha512-new"/);
  assert.throws(() => repinLockEntry("{}", "1.5.5", "x"), /no forge-shell/);
});
