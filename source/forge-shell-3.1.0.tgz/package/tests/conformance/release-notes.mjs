import assert from "node:assert/strict";
import test from "node:test";
import { releaseNotes } from "../../scripts/release-notes.mjs";

test("release notes select the requested version and fall back to the newest", () => {
  const changelog = "# Changes\n\n## 2.0.0\nNew work.\n\n## 1.9.0\nOlder work.\n";
  assert.equal(releaseNotes(changelog, "1.9.0"), "Older work.");
  assert.equal(releaseNotes(changelog, "1.8.0"), "New work.");
  assert.equal(releaseNotes("# Changes\n", "1.0.0"), null);
});

test("strict release notes require the version's own section", () => {
  const changelog = "# Changes\n\n## 2.0.0\nNew work.\n\n## 1.9.0\nOlder work.\n";
  assert.equal(releaseNotes(changelog, "2.0.0", { strict: true }), "New work.");
  assert.equal(releaseNotes(changelog, "1.8.0", { strict: true }), null);
});
