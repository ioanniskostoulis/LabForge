import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";

const read = (path) => readFileSync(new URL(`../../${path}`, import.meta.url), "utf8");
const tokens = read("source/styles/tokens.css");
const shell = read("source/styles/shell.css");

test("exported font stacks equal the font tokens", () => {
  const fonts = read("source/app/fonts.ts");
  for (const [name, token] of [["FONT_UI", "ui"], ["FONT_MONO", "mono"]]) {
    const exported = fonts.match(new RegExp(`${name} = '([^']+)'`))[1];
    assert.equal(exported, tokens.match(new RegExp(`--${token}: ([^;]+);`))[1], name);
  }
});

test("every text role class sets family, size, colour and alignment", () => {
  for (const role of ["label", "value", "mono", "quiet", "heading", "tab", "section", "kind", "marker"]) {
    const rules = [...shell.matchAll(new RegExp(`(?:^|\\n)[^\\n{]*\\.t-${role}\\b[^\\n{]*\\{([^}]*)\\}`, "g"))].map((m) => m[1]).join(";");
    assert.match(rules, /font:/, `.t-${role} font`);
    if (role !== "kind") assert.match(rules, /color:/, `.t-${role} colour`);
    assert.match(rules, /text-align:/, `.t-${role} alignment`);
  }
  assert.match(shell, /\.t-value \{[^}]*tabular-nums/);
  assert.match(shell, /\.t-marker \{[^}]*tabular-nums/);
});
