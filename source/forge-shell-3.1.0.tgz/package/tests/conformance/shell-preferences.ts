import assert from "node:assert/strict";
import test from "node:test";
import { shellPreferenceCommand } from "../../source/app/shell-preferences";

test("shared preference verbs update panel, inspector and appearance, and report them with no value", () => {
  const settings = { showBottomPanel: true, showInspector: true, inspectorSide: "right" as "left" | "right", appearance: "dark" as "dark" | "light" | "pride" };
  let selected = "";
  const host = {
    settings,
    update: (change: Partial<typeof settings>) => Object.assign(settings, change),
    panes: ["terminal", "graph", "messages"] as const,
    selectPane: (pane: string) => { selected = pane; },
  };
  assert.deepEqual(shellPreferenceCommand("panel", "graph", host), { lines: ["Showing graph panel."] });
  assert.equal(selected, "graph");
  assert.deepEqual(shellPreferenceCommand("inspector", "off", host), { lines: ["Inspector disabled."] });
  assert.equal(settings.showInspector, false);
  assert.deepEqual(shellPreferenceCommand("theme", "pride", host), { lines: ["Pride mode enabled."] });
  assert.equal(settings.appearance, "pride");
  assert.equal(shellPreferenceCommand("unknown", "", host), null);
  // with no value a verb reports its state; only on, off or a pane name changes the panel
  settings.showBottomPanel = false;
  assert.deepEqual(shellPreferenceCommand("panel", "", host), { lines: ["The bottom panel is off."] });
  assert.deepEqual(shellPreferenceCommand("inspector", "", host), { lines: ["The inspector is off."] });
  assert.equal(shellPreferenceCommand("panel", "nonsense", host), null);
  assert.equal(settings.showBottomPanel, false);
  assert.deepEqual(shellPreferenceCommand("panel", "on", host), { lines: ["Bottom panel enabled."] });
});

test("autosave reads and sets the preference where an application offers it, and refuses other values with a sentence", () => {
  const settings = { showBottomPanel: true, showInspector: true, inspectorSide: "right" as const, appearance: "dark" as const, autosave: "off" as "off" | "1m" | "5m" | "focus" };
  const host = { settings, update: (change: Partial<typeof settings>) => Object.assign(settings, change), panes: [] as string[], selectPane: () => {} };
  assert.deepEqual(shellPreferenceCommand("autosave", "", host), { lines: ["Autosave is off."] });
  assert.deepEqual(shellPreferenceCommand("autosave", "1m", host), { lines: ["Autosave set to after 1 minute."] });
  assert.deepEqual(shellPreferenceCommand("autosave", "1 min", host), { lines: ["Autosave is already after 1 minute."] });
  assert.deepEqual(shellPreferenceCommand("autosave", "focus", host), { lines: ["Autosave set to when the window loses focus."] });
  assert.deepEqual(shellPreferenceCommand("autosave", "off", host), { lines: ["Autosave disabled."] });
  assert.deepEqual(shellPreferenceCommand("autosave", "hourly", host), { lines: ["Autosave takes off, 1m, 5m or focus."] });
  // an application without autosave leaves the verb to itself
  const { autosave: _, ...without } = settings;
  assert.equal(shellPreferenceCommand("autosave", "1m", { ...host, settings: without }), null);
});
