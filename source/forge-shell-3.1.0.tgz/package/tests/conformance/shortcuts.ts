import assert from "node:assert/strict";
import { test } from "node:test";
import { collectShortcuts, displayKey, drawsMenubar, matchesKey, menuShortcutRows, shortcutText } from "../../source/app/menus";
import { tipText } from "../../source/app/tips";

test("shortcuts are written out with a space either side of each plus, in the platform's names and order", () => {
  // macOS: Control, Option, Shift, Cmd, as Apple orders them
  assert.equal(shortcutText("CmdOrCtrl+Shift+Z", true), "Shift + Cmd + Z");
  assert.equal(shortcutText("CmdOrCtrl+Alt+F", true), "Option + Cmd + F");
  assert.equal(shortcutText("Ctrl+CmdOrCtrl+F", true), "Control + Cmd + F");
  assert.equal(shortcutText("CmdOrCtrl+=", true), "Cmd + =");
  assert.equal(shortcutText("Escape", true), "Esc");
  assert.equal(shortcutText("Enter", true), "Return");
  assert.equal(shortcutText("CmdOrCtrl+Backspace", true), "Cmd + Delete");
  // Windows: Ctrl, Alt, Shift
  assert.equal(shortcutText("CmdOrCtrl+Shift+Z", false), "Ctrl + Shift + Z");
  assert.equal(shortcutText("Alt+Z", false), "Alt + Z");
  assert.equal(shortcutText("Enter", false), "Enter");
  assert.equal(shortcutText("CmdOrCtrl+Backspace", false), "Ctrl + Backspace");
  // a hint written with a glyph reads as its key
  assert.equal(shortcutText("⎋", true), "Esc");
  assert.equal(shortcutText("CmdOrCtrl+⌫", false), "Ctrl + Backspace");
  assert.equal(shortcutText("Tab", false), "Tab");
});

test("the keyboard-shortcut list and tooltips use the written form; menus keep the glyphs of native menus", () => {
  const rows = menuShortcutRows([{ id: "edit.redo", label: "Redo", key: "CmdOrCtrl+Shift+Z" }], ["edit"]);
  assert.deepEqual(rows, [[shortcutText("CmdOrCtrl+Shift+Z"), "Redo"]]);
  assert.equal(tipText({ label: "Undo", shortcut: "CmdOrCtrl+Z" }), `Undo (${shortcutText("CmdOrCtrl+Z")})`);
  assert.ok(!/ \+ /.test(displayKey("CmdOrCtrl+Shift+Z")), "a menu shortcut stays compact");
});

test("the page draws the menu bar in the browser and on Windows, never over the native macOS menu", () => {
  assert.equal(drawsMenubar("darwin", false), true);
  assert.equal(drawsMenubar("win32", true), true);
  assert.equal(drawsMenubar("darwin", true), false);
  assert.equal(drawsMenubar("linux", true), false);
});


import { UNIVERSAL_SHORTCUTS, appShortcut, checkShortcuts, normalizeKey, replaceShortcut, shortcutTier, CONVENTIONAL_SHORTCUTS } from "../../source/app/shortcuts";

test("shortcuts fall into tiers: the shell's universal keys, two-modifier app keys, and bare tool keys", () => {
  assert.equal(normalizeKey("Shift+CmdOrCtrl+b", true), "Shift+Cmd+B");
  assert.equal(normalizeKey("CmdOrCtrl+Alt+b", false), "Ctrl+Alt+B");
  assert.equal(shortcutTier("CmdOrCtrl+S", true), "universal");
  assert.equal(shortcutTier("CmdOrCtrl+Shift+S", true), "universal", "Save as is the shell's");
  assert.equal(shortcutTier("CmdOrCtrl+Shift+B", true), "app");
  assert.equal(shortcutTier("CmdOrCtrl+Shift+B", false), "app");
  assert.equal(shortcutTier("Alt+CmdOrCtrl+B", true), "secondary");
  assert.equal(shortcutTier("Alt+CmdOrCtrl+B", false), "invalid", "Ctrl+Alt is AltGr on Windows");
  assert.equal(shortcutTier("R", true), "tool");
  // an app command: Shift+Cmd and Ctrl+Shift; a rarer one: Option+Cmd on macOS and no default on Windows
  assert.equal(appShortcut("b", "app", true), "CmdOrCtrl+Shift+B");
  assert.equal(appShortcut("b", "secondary", true), "Alt+CmdOrCtrl+B");
  assert.equal(appShortcut("b", "secondary", false), undefined);
  assert.throws(() => appShortcut("é", "app", true), /letter or a digit/);
  assert.equal(replaceShortcut(true), "Alt+CmdOrCtrl+F");
  assert.equal(replaceShortcut(false), "CmdOrCtrl+H");
  for (const mac of [true, false]) assert.deepEqual(checkShortcuts(Object.entries(UNIVERSAL_SHORTCUTS).map(([id, key]) => ({ id, key, owner: "shell" as const })), mac), [], "the universal table is clean");
});

test("the shortcut check reports clashes, system keys, universal keys taken by an app and keys that type characters", () => {
  const mac = (entries: { id: string; key: string; owner?: "shell" | "app" }[]) => checkShortcuts(entries, true);
  const win = (entries: { id: string; key: string; owner?: "shell" | "app" }[]) => checkShortcuts(entries, false);
  assert.deepEqual(mac([{ id: "build", key: "CmdOrCtrl+Shift+B" }, { id: "bold", key: "Shift+CmdOrCtrl+B" }]), ["build and bold share Shift+Cmd+B on macOS."]);
  assert.deepEqual(mac([{ id: "hide", key: "CmdOrCtrl+H" }]), ["hide uses Cmd+H, which macOS keeps for itself."]);
  assert.deepEqual(mac([{ id: "run", key: "CmdOrCtrl+R" }]), ["run uses Cmd+R; an application command takes Shift+Cmd or Option+Cmd and a letter."]);
  assert.deepEqual(mac([{ id: "export", key: "CmdOrCtrl+S" }]), ["export uses Cmd+S, the shell's key for save."]);
  assert.deepEqual(mac([{ id: "mark", key: "Alt+M" }]), ["mark uses Alt+M, which types a character on macOS."]);
  assert.deepEqual(win([{ id: "mark", key: "CmdOrCtrl+Alt+M" }]), ["mark uses Ctrl+Alt+M; Ctrl+Alt is AltGr on Windows and types characters on many keyboards."]);
  assert.deepEqual(win([{ id: "mark", key: "Alt+M" }]), ["mark uses Alt+M, which opens a menu on Windows."]);
  assert.deepEqual(win([{ id: "mark", key: "Alt+Shift+M" }]), ["mark uses Alt+Shift+M, which switches the keyboard language on Windows."]);
  assert.deepEqual(win([{ id: "caps", key: "Shift+M" }]), ["caps uses Shift+M, which types a capital letter."]);
  assert.deepEqual(win([{ id: "build", key: "CmdOrCtrl+Shift+B" }, { id: "wire", key: "W" }]), [], "an app key and a tool key are fine");
});

test("a conventional shortcut may stay outside the tiers when it names its convention; anything else follows the tiers", () => {
  const registry = [
    { id: "view.fit", key: "CmdOrCtrl+0" },
    { id: "view.actualSize", key: "CmdOrCtrl+1" },
    { id: "edit.duplicate", key: "CmdOrCtrl+D" },
    { id: "sim.run", key: "CmdOrCtrl+Return", convention: "run" },
    { id: "sim.reset", key: "CmdOrCtrl+R", convention: "reload" },
    { id: "tab.next", key: "Ctrl+Tab" },
    { id: "text.bold", key: "CmdOrCtrl+B", convention: "bold" },
  ];
  for (const mac of [true, false]) assert.deepEqual(checkShortcuts(registry, mac), []);
  // The same keys without a convention break the tiers, and a convention does not cover another meaning's key.
  assert.match(checkShortcuts([{ id: "text.bold", key: "CmdOrCtrl+B" }], true)[0], /an application command takes/);
  assert.deepEqual(checkShortcuts([{ id: "edit.rotate", key: "CmdOrCtrl+E", convention: "bold" }], true), ["edit.rotate uses Cmd+E, but the bold convention is Cmd+B."]);
  assert.match(checkShortcuts([{ id: "edit.rotate", key: "CmdOrCtrl+]" }], true)[0], /the shell's key for bringForward/);
  assert.match(checkShortcuts([{ id: "x", key: "CmdOrCtrl+D", convention: "nonsense" }], true)[0], /not one of CONVENTIONAL_SHORTCUTS/);
  // A convention takes a universal key only where it says so: Fit may take Actual size's Cmd+0, Duplicate may not take Save's.
  assert.match(checkShortcuts([{ id: "text.bold", key: "CmdOrCtrl+S", convention: "bold" }], true)[0], /convention is Cmd\+B/);
  for (const [name, rule] of Object.entries(CONVENTIONAL_SHORTCUTS)) assert.ok(rule.keys.length && rule.usedBy, name);
});

test("menus show every named key as its platform shows it, never as upper-case text", () => {
  const mac = /Mac/.test(navigator.platform);
  const expected: Record<string, [string, string]> = { Return: ["↩", "Enter"], Enter: ["↩", "Enter"], Delete: ["⌦", "Del"], Backspace: ["⌫", "Backspace"], Escape: ["⎋", "Esc"],
    Space: ["Space", "Space"], Home: ["↖", "Home"], PageDown: ["⇟", "PgDn"], d: ["D", "D"] };
  for (const [key, [onMac, onWindows]] of Object.entries(expected)) assert.equal(displayKey(key), mac ? onMac : onWindows, key);
  assert.equal(displayKey("CmdOrCtrl+Shift+Return"), mac ? "⇧⌘↩" : "Ctrl+Shift+Enter");
});

test("a standard action takes its standard key and no other: Fit is Cmd+0 and Actual size Cmd+1 in every application", () => {
  assert.equal(UNIVERSAL_SHORTCUTS.fit, "CmdOrCtrl+0");
  assert.equal(UNIVERSAL_SHORTCUTS.actualSize, "CmdOrCtrl+1");
  assert.deepEqual(checkShortcuts([{ id: "view.fit", key: "CmdOrCtrl+0" }, { id: "view.actualSize", key: "CmdOrCtrl+1" }], true), []);
  assert.deepEqual(checkShortcuts([{ id: "view.fit", key: "CmdOrCtrl+Shift+F" }], true), ["view.fit uses Shift+Cmd+F; its standard key is Cmd+0."]);
  assert.match(checkShortcuts([{ id: "app.reset", key: "CmdOrCtrl+0" }], false)[0], /the shell's key for fit/);
});

test("the page's shortcut handler never takes a role's key, and matches punctuation and named keys on any layout", () => {
  const menus = [{ label: "Edit", submenu: [{ id: "edit.copy", role: "copy", label: "Copy", key: "CmdOrCtrl+C" }, { id: "edit.toggleComment", label: "Toggle comment", key: "CmdOrCtrl+/" }] }];
  assert.deepEqual(collectShortcuts(menus), [{ key: "CmdOrCtrl+/", id: "edit.toggleComment" }]);
  const mac = /Mac/.test(navigator.platform);
  const press = (code: string, key: string, extra: Record<string, boolean> = {}) => ({ code, key, metaKey: mac, ctrlKey: !mac, altKey: false, shiftKey: false, ...extra }) as unknown as KeyboardEvent;
  // On a Greek layout the key is a Greek letter or another symbol; the physical code still matches.
  assert.ok(matchesKey(press("Slash", "΄"), "CmdOrCtrl+/"));
  assert.ok(matchesKey(press("Comma", ","), "CmdOrCtrl+,"));
  assert.ok(matchesKey(press("BracketRight", "}", { shiftKey: true }), "CmdOrCtrl+Shift+]"));
  assert.ok(matchesKey(press("Digit0", "0"), "CmdOrCtrl+0"));
  assert.ok(matchesKey(press("Enter", "Enter"), "CmdOrCtrl+Return"));
  assert.ok(matchesKey(press("KeyN", "ν"), "CmdOrCtrl+N"));
  assert.ok(!matchesKey(press("Digit1", "1"), "CmdOrCtrl+0"));
  assert.ok(matchesKey({ code: "Tab", key: "Tab", metaKey: false, ctrlKey: true, altKey: false, shiftKey: false } as unknown as KeyboardEvent, "Ctrl+Tab"));
});
