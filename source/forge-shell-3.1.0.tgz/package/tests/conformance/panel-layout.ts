import assert from "node:assert/strict";
import { test } from "node:test";
import { BOTTOM_MAX, CLOSE_PAST, INSPECTOR_MAX, dragOutcome, panelSize } from "../../source/app/panel-layout";

// The default sizes of every Forge application, which are also the smallest sizes.
const WIDTH = 246, HEIGHT = 246;

test("a panel keeps its size within the limits and closes only well past its default size", () => {
  assert.equal(CLOSE_PAST, 96);
  assert.deepEqual(dragOutcome(300, WIDTH, INSPECTOR_MAX), { size: 300, close: false });
  assert.deepEqual(dragOutcome(500, WIDTH, INSPECTOR_MAX), { size: INSPECTOR_MAX, close: false });
  assert.deepEqual(dragOutcome(WIDTH - 1, WIDTH, INSPECTOR_MAX), { size: WIDTH, close: false });
  assert.deepEqual(dragOutcome(WIDTH - CLOSE_PAST, WIDTH, INSPECTOR_MAX), { size: WIDTH, close: false });
  assert.deepEqual(dragOutcome(WIDTH - CLOSE_PAST - 1, WIDTH, INSPECTOR_MAX), { size: WIDTH, close: true });
  assert.deepEqual(dragOutcome(-50, HEIGHT, BOTTOM_MAX), { size: HEIGHT, close: true });
});

test("a stored panel size below the default loads at the default size", () => {
  assert.equal(panelSize(110, HEIGHT, BOTTOM_MAX), HEIGHT);
  assert.equal(panelSize(HEIGHT - 1, HEIGHT, BOTTOM_MAX), HEIGHT);
  assert.equal(panelSize(HEIGHT, HEIGHT, BOTTOM_MAX), HEIGHT);
  assert.equal(panelSize(HEIGHT + 1, HEIGHT, BOTTOM_MAX), HEIGHT + 1);
  assert.equal(panelSize(900, WIDTH, INSPECTOR_MAX), INSPECTOR_MAX);
  assert.equal(panelSize(Number.NaN, WIDTH, INSPECTOR_MAX), WIDTH);
});
