import assert from "node:assert/strict";
import { test } from "node:test";
import { MessageLog } from "../../source/app/messages";

test("the log reports the worst unseen problem kind", () => {
  const log = new MessageLog();
  assert.equal(log.worstUnseen, null);
  log.add("info", "Ready.");
  assert.equal(log.worstUnseen, null);
  log.add("warning", "Check the value.");
  assert.equal(log.worstUnseen, "warning");
  log.add("error", "Could not save.");
  assert.equal(log.worstUnseen, "error");
  log.markSeen();
  assert.equal(log.worstUnseen, null);
  log.add("error", "Again.");
  log.clear();
  assert.equal(log.worstUnseen, null);
});
