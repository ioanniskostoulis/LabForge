import assert from "node:assert/strict";
import test from "node:test";
import { appBundle, cannotReplace, macSwapScript, windowsUpdateScript } from "../../source/desktop/updater";
import { updateAsset, type Release } from "../../source/app/updates";

const release: Release = { version: "3.1.0", url: "https://github.com/owner/app/releases/tag/v3.1.0", name: "3.1.0", assets: [
  { name: "Example-v3.1.0.dmg", url: "https://github.com/owner/app/releases/download/v3.1.0/Example-v3.1.0.dmg", size: 10, sha256: null },
  { name: "Example-v3.1.0.exe", url: "https://github.com/owner/app/releases/download/v3.1.0/Example-v3.1.0.exe", size: 20, sha256: null },
  { name: "Example-v3.1.0.dmg.blockmap", url: "https://github.com/owner/app/releases/download/v3.1.0/Example-v3.1.0.dmg.blockmap", size: 1, sha256: null },
] };

test("the update installs the release's disk image on macOS and its setup on Windows", () => {
  assert.equal(updateAsset(release, "Example", "darwin")?.name, "Example-v3.1.0.dmg");
  assert.equal(updateAsset(release, "Example", "win32")?.name, "Example-v3.1.0.exe");
  assert.equal(updateAsset(release, "Example", "linux"), null);
  assert.equal(updateAsset(release, "Other", "darwin"), null);
});

test("a macOS app replaces itself only from a real folder, never from its disk image or a translocated download", () => {
  assert.equal(appBundle("/Applications/Example.app/Contents/MacOS/Example"), "/Applications/Example.app");
  assert.equal(appBundle("/usr/local/bin/node"), null);
  assert.equal(cannotReplace("/Applications/Example.app"), null);
  assert.match(cannotReplace("/private/var/folders/x/AppTranslocation/1/d/Example.app")!, /Move it to Applications/);
  assert.match(cannotReplace("/Volumes/Example 3.1.0/Example.app")!, /Drag it to Applications/);
  assert.match(cannotReplace(null)!, /not in an app bundle/);
});

test("the swap scripts wait for the app, keep the old copy until the new one is in place, and quote paths", () => {
  const mac = macSwapScript({ pid: 42, bundle: "/Applications/It's.app", staged: "/Applications/It's.app.new", work: "/tmp/w" });
  assert.match(mac, /while kill -0 42/);
  assert.ok(mac.includes(`'/Applications/It'\\''s.app'`));
  assert.ok(mac.indexOf("mv '/Applications/It'\\''s.app' '/Applications/It'\\''s.app.old'") < mac.indexOf("mv '/Applications/It'\\''s.app.new'"));
  const windows = windowsUpdateScript({ pid: 7, setup: "C:\\Temp\\u\\Example-v3.1.0.exe", app: "C:\\Program Files\\Forge\\Example\\Example.exe" });
  assert.match(windows, /Wait-Process -Id 7/);
  assert.match(windows, /-ArgumentList '\/S' -Wait/);
  assert.ok(windows.indexOf("'/S'") < windows.indexOf("Start-Process -FilePath 'C:\\Program Files"));
});
