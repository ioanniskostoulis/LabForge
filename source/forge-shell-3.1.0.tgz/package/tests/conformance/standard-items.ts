import assert from "node:assert/strict";
import test from "node:test";
import { STANDARD_ITEMS, arrangeItems, standardItem, zoomItems } from "../../source/app/standard-items";
import { SHARED_COMMANDS, STANDARD_ACTIONS } from "../../source/app/shared-commands";
import { checkShortcuts } from "../../source/app/shortcuts";

test("every standard action has one label, one key and one Terminal command, the same in every application", () => {
  assert.deepEqual(Object.keys(STANDARD_ITEMS).sort(), [...STANDARD_ACTIONS].sort());
  assert.deepEqual(standardItem("view.fit"), { id: "view.fit", label: "Fit", key: "CmdOrCtrl+0" });
  assert.deepEqual(standardItem("view.actualSize"), { id: "view.actualSize", label: "Actual size", key: "CmdOrCtrl+1" });
  assert.deepEqual(standardItem("file.new", { noun: "circuit" }), { id: "file.new", label: "New circuit", key: "CmdOrCtrl+N" });
  assert.equal(standardItem("about", { product: "Example" }).label, "About Example");
  assert.deepEqual(standardItem("file.save", {}, { enabled: false }).enabled, false);
  assert.deepEqual(zoomItems().map((item) => item.label), ["Zoom in", "Zoom out", "Fit", "Actual size"]);
  // Each item's Terminal command exists, and the keys of all items pass the shortcut check.
  const verbs = new Set(SHARED_COMMANDS.map((entry) => entry.spec.name));
  for (const [action, item] of Object.entries(STANDARD_ITEMS)) if (item.command) assert.ok(verbs.has(item.command.split(" ")[0]), `${action}: ${item.command}`);
  for (const mac of [true, false]) {
    const registry = Object.keys(STANDARD_ITEMS).map((action) => standardItem(action as keyof typeof STANDARD_ITEMS, {}, {}, mac)).filter((item) => item.key).map((item) => ({ id: item.id!, key: item.key! }));
    assert.deepEqual(checkShortcuts(registry, mac), [], mac ? "macOS" : "Windows");
  }
});

test("the standard items cover the keys every application shares, each on the platform's key", () => {
  const key = (action: keyof typeof STANDARD_ITEMS, mac: boolean) => standardItem(action, {}, {}, mac).key ?? standardItem(action, {}, {}, mac).hint;
  const expected: [keyof typeof STANDARD_ITEMS, string, string][] = [
    ["file.newWindow", "CmdOrCtrl+Shift+N", "CmdOrCtrl+Shift+N"], ["file.print", "CmdOrCtrl+P", "CmdOrCtrl+P"], ["app.settings", "CmdOrCtrl+,", "CmdOrCtrl+,"],
    ["edit.duplicate", "CmdOrCtrl+D", "CmdOrCtrl+D"], ["edit.delete", "Backspace", "Delete"], ["edit.find", "CmdOrCtrl+F", "CmdOrCtrl+F"],
    ["edit.replace", "Alt+CmdOrCtrl+F", "CmdOrCtrl+H"], ["edit.goToLine", "CmdOrCtrl+L", "CmdOrCtrl+L"], ["edit.toggleComment", "CmdOrCtrl+/", "CmdOrCtrl+/"],
    ["arrange.bringForward", "CmdOrCtrl+]", "CmdOrCtrl+]"], ["arrange.sendToBack", "CmdOrCtrl+Shift+[", "CmdOrCtrl+Shift+["],
    ["view.inspector", "CmdOrCtrl+I", "CmdOrCtrl+I"], ["view.bottomPanel", "CmdOrCtrl+J", "CmdOrCtrl+J"], ["tab.next", "Ctrl+Tab", "Ctrl+Tab"], ["tab.prev", "Ctrl+Shift+Tab", "Ctrl+Shift+Tab"],
  ];
  for (const [action, mac, windows] of expected) { assert.equal(key(action, true), mac, action); assert.equal(key(action, false), windows, action); }
  assert.equal(standardItem("edit.copy").role, "copy");
  assert.equal("role" in standardItem("edit.copy", {}, { role: undefined }), false, "an app handling Copy itself drops the role");
  assert.equal(standardItem("view.fullScreen").role, "togglefullscreen");
  assert.deepEqual(arrangeItems().map((item) => item.label), ["Bring forward", "Send backward", "Bring to front", "Send to back"]);
});
