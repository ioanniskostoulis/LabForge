import assert from "node:assert/strict";
import { test } from "node:test";
import { DRAG_THRESHOLD, SELECTION_BOX, boxHits, boxRect, dragStarted, dropEdge, dropIndex, moveItem, nextSelection, selectionMode } from "../../source/app/content-selection";
import { Viewport } from "../../source/app/viewport";

const box = (x: number, y: number, width: number, height: number) => ({ x, y, width, height });

test("a selection box takes the items wholly inside it, or those it touches, whichever way it was dragged", () => {
  assert.deepEqual(boxRect(10, 10, 0, 4), box(0, 4, 10, 6));
  const items = [{ id: "a", b: box(1, 1, 2, 2) }, { id: "b", b: box(8, 8, 4, 4) }, { id: "c", b: box(20, 20, 1, 1) }];
  const ids = (hits: typeof items) => hits.map((item) => item.id);
  assert.deepEqual(ids(boxHits(items, (item) => item.b, box(0, 0, 10, 10))), ["a"], "b sticks out of the box");
  assert.deepEqual(ids(boxHits(items, (item) => item.b, box(0, 0, 10, 10), "touch")), ["a", "b"]);
  assert.deepEqual(SELECTION_BOX, { fillAlpha: 0.12, lineWidth: 1, dash: [4, 3] });
});

test("Shift adds to the selection, Cmd or Ctrl toggles, and a plain click or box replaces it", () => {
  const base = new Set(["a", "b"]);
  assert.deepEqual([...nextSelection(base, ["c"], "replace")], ["c"]);
  assert.deepEqual([...nextSelection(base, ["b", "c"], "add")], ["a", "b", "c"]);
  assert.deepEqual([...nextSelection(base, ["b", "c"], "toggle")], ["a", "c"]);
  assert.equal(selectionMode({ shiftKey: true, metaKey: false, ctrlKey: false }, true), "add");
  assert.equal(selectionMode({ shiftKey: false, metaKey: true, ctrlKey: false }, true), "toggle");
  assert.equal(selectionMode({ shiftKey: false, metaKey: true, ctrlKey: false }, false), "replace", "Cmd means nothing on Windows");
  assert.equal(selectionMode({ shiftKey: false, metaKey: false, ctrlKey: true }, false), "toggle");
});

test("a drag starts after 5 px, and a drop lands on the side within 20 % (at most 40 px) or above and below the middle", () => {
  assert.equal(DRAG_THRESHOLD, 5);
  assert.equal(dragStarted(0, 0, 3, 3), false, "4.2 px is still a click");
  assert.equal(dragStarted(0, 0, 3, 4), true, "5 px starts the drag");
  const target = box(0, 0, 100, 60);
  assert.equal(dropEdge({ x: 19, y: 10 }, target), "left");
  assert.equal(dropEdge({ x: 21, y: 10 }, target), "above");
  assert.equal(dropEdge({ x: 50, y: 31 }, target), "below");
  assert.equal(dropEdge({ x: 81, y: 50 }, target), "right");
  // a wide target keeps the side band at 40 px
  assert.equal(dropEdge({ x: 41, y: 1 }, box(0, 0, 400, 60)), "above");
  assert.equal(dropEdge({ x: 90, y: 1 }, target, "vertical"), "above");
  assert.equal(dropEdge({ x: 90, y: 1 }, target, "horizontal"), "right");
});

test("a dragged item lands before the item whose middle it has not passed, and moving keeps the others in order", () => {
  const tabs = [{ start: 0, end: 100 }, { start: 100, end: 200 }, { start: 200, end: 300 }];
  assert.equal(dropIndex(tabs, 40), 0);
  assert.equal(dropIndex(tabs, 160), 2);
  assert.equal(dropIndex(tabs, 290), 3);
  assert.deepEqual(moveItem(["a", "b", "c", "d"], 0, 3), ["b", "c", "a", "d"]);
  assert.deepEqual(moveItem(["a", "b", "c", "d"], 3, 1), ["a", "d", "b", "c"]);
  assert.deepEqual(moveItem(["a", "b", "c"], 1, 3), ["a", "c", "b"]);
});

test("the viewport zooms about the pointer within its limits and fits a rectangle without over-magnifying", () => {
  const view = new Viewport();
  view.zoom(2, 100, 50);
  assert.deepEqual(view.toWorld(100, 50), [100, 50], "the point under the pointer stays put");
  assert.deepEqual(view.toView(...view.toWorld(30, 70)), [30, 70]);
  view.zoom(1000, 0, 0);
  assert.equal(view.scale, Viewport.maxScale);
  const fit = Viewport.fit({ x: 0, y: 0, width: 10, height: 10 }, 1000, 1000);
  assert.equal(fit.scale, 2.5, "a small drawing is not blown up beyond 2.5×");
  assert.deepEqual([fit.ox, fit.oy], [487.5, 487.5]);
});
