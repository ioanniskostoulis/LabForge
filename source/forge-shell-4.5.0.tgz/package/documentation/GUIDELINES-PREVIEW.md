# Forge application guidelines: preview and surfaces

Part of [GUIDELINES.md](GUIDELINES.md), sections 11 to 13.

## 11. Localhost preview

When a Forge application is created, migrated or changed, its author runs the browser preview of the application on the local machine and opens the printed `http://127.0.0.1:<port>/` URL to inspect the actual interface. This is a rule of development and verification and not a requirement to run production data or a model on a local server. A source HTML file, a screenshot, a successful TypeScript check or an Electron build alone does not count as a running preview.

| Subject | Specification |
|---|---|
| Entry point | Every Forge repository supplies `npm run web`. It builds the renderer into `build/app`, starts an HTTP server bound to `127.0.0.1` only (never `0.0.0.0`, and never published as a remote site) and prints the complete local URL once the server is listening. |
| Port | The default port is recorded in `documentation/DEVELOPMENT.md` of the application; `PORT=<port>` overrides it locally so that several applications can run simultaneously. An existing preview script may remain as an alias of `npm run web`. |
| Served content | The built `build/app/index.html`, with its CSS, JavaScript and static assets, over HTTP. The server process stays alive while the interface is inspected or changed. After an edit the build is rebuilt and the browser reloaded (automatically or explicitly), and the response is checked to be the new build and not a stale page. |
| Port conflicts | An occupied default port leads to inspecting the existing process or choosing another `PORT`; the server of another application is not silently replaced. A server that was started for the work is stopped afterwards unless the user is using it. |
| Shared code | The preview uses the same renderer, shared shell, styles, fonts, icons, tab, inspector, menu and Terminal components and appearance tokens as Electron. Browser-only file-system and operating-system behaviour sits behind a typed local adapter, and fixture data and unavailable desktop operations are labelled honestly. File pickers and downloads may replace native dialogs, but `Saved`, `Built` or `Verified` is not reported for a simulated desktop operation. |
| Electron | Native menus, file associations, operating-system dialogs, packaging and platform behaviour are checked in the actual Electron application; a localhost screenshot cannot establish them. |

For a visual change, the local URL is opened and the affected state is checked at the default desktop window size and in a narrower view: the welcome state and Terminal help without a document, an open document, Dark and Light, the relevant tabs, menus and inspector, and the result of the changed action. The rendered page is captured or inspected after the build, and CSS is not judged from source alone. The work report records the URL, the build and check result, the views actually inspected and any difference between browser and Electron. When the preview cannot be run or opened, this is stated plainly and no visual verification is claimed.

### Identical npm entry points and build locations

Every Forge application exposes the same script names with the same meanings, and the engine of an application supplies its own tests and bundled code behind them. The `web` and `dev` scripts run until stopped. `build` produces the renderer, the Electron main and preload bundles and the engine entry; `start` runs a built desktop application; `dist` packages it; and `checks` runs the complete automated gate, including `check`, `test` and `test:app` and any accuracy or compatibility checks of the engine. No application renames a command to `web:preview`, `typecheck`, `package` or another private spelling as its only entry point.

```json
{
  "scripts": {
    "build": "node scripts/build.mjs",
    "check": "tsc --noEmit -p .",
    "test": "<application engine tests>",
    "test:app": "<application interface tests>",
    "checks": "<complete application gate>",
    "web": "node scripts/web.mjs",
    "dev": "node scripts/web.mjs --desktop",
    "start": "npm run build && electron .",
    "dist": "npm run build && electron-builder --publish never --config.electronDist=./node_modules/electron/dist"
  }
}
```

The script names and shared command bodies are copyable, and the three angle-bracket values are the only engine and test adapters in the block, replaced in each application. The output paths are identical in all applications.

```text
build/
├── app/
│   ├── index.html
│   ├── app.js
│   ├── app.css
│   └── ...                 # assets and optional workers or preview adapter
├── desktop/
│   ├── main.cjs
│   └── preload.cjs
└── engine/
    └── index.cjs
```

The browser preview and the packaged Electron application load the same `build/app/index.html` with its `app.js` and `app.css`. The generated `build/` content is ignored by Git. An application-specific command-line tool may add another output under `build/` but does not rename the shared files. The profile records extra workers and assets and the test commands of the engine, and every application emits these shared paths, while the engine bundles differ in their computation.

## 12. Implementation and review gate

| Subject | Requirement |
|---|---|
| One operation | Menus, toolbar, keyboard and Terminal invoke one underlying action for the same behaviour, and the registry and the interface labels stay in step. |
| Separation | File-system and operating-system calls are behind a typed Electron preload API, and domain computation is separate from the renderer and the main process where practical. |
| Controls of an application | For every application-specific control the profile gives its identifier, location, label and case, dimensions, colours in all themes, enabled, selected and focus states, tooltip, keyboard action, motion, result and error text, and persistence. |
| Commands of an application | For every application-specific command the profile gives its syntax, examples, validation, completion, output layout, cancellation and behaviour without a document. |
| Verification | Dark and Light, the initial and reduced-motion states, all tab, inspector and panel transitions, list spacing, colour and case, the Terminal banner, help and completion of the welcome state, message routing, keyboard focus, the unsaved-close flow and the packaged Windows launch are verified. The built Electron application or the served `build/app` bundle is run for interface checks, since opening `source/app/index.html` directly does not load its generated `main.js`. Actual checks are recorded and results are not inferred. |

The shared guide is complete only together with an application profile and the source-backed domain documentation of that application. The interface reference of an application demonstrates how one implementation is pinned to exact source files. Before the guide is used for a migration, the profile of the target application is written and verified against its current behaviour and the desired changes.

## 13. Context menus, tooltips and unit fields

The behaviours of this section were added after the first applications shipped, and every Forge application uses them as written.

### Context menu

One implementation (`showContextMenu` in `source/app/context-menu.ts`, with `showFieldPopover` for panels of typed values) uses the popup surface and item styling of the browser menu bar (section 6) and is mounted in the overlay root.

| Part | Specification |
|---|---|
| Entries | A label; an optional check column (12 px, present only when some entry of the popup has a `checked` value); an optional shortcut at the right; an optional submenu marker `›`; a non-interactive header row; a separator |
| Separator | 1 px `--hairline`, margin 4 px 6 px |
| Disabled | An entry without action and submenu: `--text3`, no hover fill, no action |
| Hover | `--accent-fill` with `--accent-foreground`, including the shortcut and the submenu marker |
| Submenu | Opens to the right of its row on hover or click, offset 2 px left and 4 px up; moving to a sibling row closes it |
| Dismissal | Esc, a press outside every open popup, or the choice of an entry; opening another context menu dismisses the open one |
| Contents | The caller passes a list or a function; a function is evaluated when the menu opens, so that the state is current |
| Explanation | The tooltip of an entry is its native `title` |

The implementation was reviewed on 2026-10-15, with the following results.

| Behaviour | Result |
|---|---|
| Clamping | A popup and its submenus remain inside the viewport at the right and bottom edges (4 px margin). |
| Keyboard | The arrow keys, Home and End move focus through the enabled entries; Right opens a submenu and Left returns to its parent; Enter and Space choose an entry. Escape returns focus to the opener, and an outside click leaves focus with the control clicked. |
| Field popover | An invalid value is shown beside the field and the field is focused; the red border and the tooltip remain as additional cues. |

### Tooltips

Tooltips are the native `title` attribute. No custom tooltip component exists, so delay and placement follow the operating system. The wording rules of section 9 apply: one short sentence, and a second only for an essential condition. The tooltip of an icon button names the action and its shortcut. A custom tooltip, if introduced, replaces this rule for every application in one change.

### Unit fields

`createUnitField` supplies the shared field layout and commit behaviour, and the application supplies its formatter and parser, such as `si(value, unit)` and `parseSI(text, unit)` in an editor application. The unit stands inside the value of the field (`5 µs`, `4.7 kΩ`) and never in a second label. A bare number typed in the field takes the unit of the field. A value that does not parse is an error under the inspector rule of section 9: it is reported in the status bar and in Messages, the field returns to its last valid value, and the inspector does not change size.

