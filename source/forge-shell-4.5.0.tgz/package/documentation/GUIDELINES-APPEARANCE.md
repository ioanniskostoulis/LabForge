# Forge application guidelines: appearance

Part of [GUIDELINES.md](GUIDELINES.md), sections 2 and 3.

## 2. Colours and logo

### Shared neutral tokens

This section is the source of the Forge palette. The CSS variable names and values below are used unchanged in every application. Dark and Light are the shared appearances. Light is selected by `data-theme="light"`, and Dark is the default. The Dark and Light accent hues follow the identity of the application. Warning, error, text, window, panel, button and separator colours are identical in every application. A domain visualisation may define semantic data colours, which do not replace the shared chrome tokens.

| Token | Dark | Light | Use |
|---|---|---|---|
| `--window` | `#1e1e1e` | `#e2e2e2` | Outer window and tab-row background. |
| `--panel` | `#282828` | `#e8e8e8` | Inspector and dialogs. |
| `--raised` | `#303030` | `#dedede` | Tool strip, tab bar and status bar. |
| `--control` | `#3a3a3a` | `#d2d2d2` | Ordinary buttons and hovered menu title. |
| `--control-hover` | `#464646` | `#c6c6c6` | Hovered ordinary control. |
| `--well` | `#1b1b1b` | `#f8f8f7` | Input, Terminal and Messages surface. |
| `--separator` | `#111111` | `#c2c2c2` | One-pixel structural borders. |
| `--hairline` | `rgba(255,255,255,0.06)` | `rgba(0,0,0,0.1)` | Quiet separators. |
| `--empty-sheet` | `#131313` | `#f8f8f7` | Welcome surface, and any canvas that draws the same sheet. |
| `--empty-grid-dot` | `rgba(255,255,255,0.08)` | `rgba(0,0,0,0.10)` | Dots of the welcome grid, 16 px apart. |
| `--empty-grid-line` | `rgba(255,255,255,0.04)` | `rgba(0,0,0,0.05)` | Lines of the welcome grid, 128 px apart. |
| `--text` | `#dadada` | `#222222` | Main text and values. |
| `--text-strong` | `#ffffff` | `#000000` | Emphasis and section-heading hover. |
| `--text2` | `#9c9c9c` | `#555555` | Labels and explanations. |
| `--text3` | `#666666` | `#6a6a6a` | Disabled or quiet text. |
| `--warning` | `#e0a040` | `#9a6000` | Warning word and unseen-problem count. |
| `--pick` | `#2fd3e6` | `#007a99` | Content selection: selected and hovered parts, points and handles on a canvas, selection boxes. Never the interface's own selection, which is the accent. |
| `--error` | `#e5534b` | `#ae3540` | Error word, invalid-input border and field errors; accompanied by an explicit `Error` label. |

### Type, shape and motion tokens

These tokens are identical in every theme and every application. Components use them in place of literals, and the derived sizes follow `--size`.

| Token | Value | Use |
|---|---|---|
| `--size` | `12px` | Base chrome text. |
| `--size-sm` | `calc(var(--size) - 1px)` | Status text, hints and small readouts. |
| `--size-xs` | `calc(var(--size) - 2px)` | Tab and section titles. |
| `--size-lg` | `calc(var(--size) + 1px)` | Popup and dialog titles. |
| `--size-xl` | `calc(var(--size) + 3px)` | Empty-state title. |
| `--weight-strong` | `600` | Names, titles and section headings. |
| `--weight-bold` | `700` | Terminal banner, bold mono text. |
| `--radius-xs` | `2px` | Slider tracks and thumbs. |
| `--radius-sm` | `3px` | Small markers and inline editors. |
| `--radius` | `4px` | Buttons, inputs and rows. |
| `--control-height` | `26px` | Standard control; the small control is this value minus 2 px. |
| `--gap` | `6px` | Space between related controls. |
| `--pad` | `8px` | Standard inner padding. |
| `--duration` | `0.15s` | Standard transition time. |
| `--ease` | `cubic-bezier(0.2, 0, 0, 1)` | Standard transition curve. |
| `--empty-grid-origin` | `40px` | Where a dot and a major line of the welcome grid meet, from the sheet's top left corner. |
| `--empty-grid-dot-step` | `16px` | Distance between the dots of the welcome grid. |
| `--empty-grid-line-step` | `128px` | Distance between the major lines of the welcome grid. |
| `--empty-grid-dot-radius` | `1.1px` | Radius of a dot of the welcome grid. |
| `--empty-grid-line-width` | `1px` | Width of a major line of the welcome grid. |

### Accent substitution only

The blue palette below is the mother palette. Each application substitutes its own hue for the five accent tokens only, and keeps their meanings and the contrast relationship between Dark and Light. `--accent-foreground` is white in every application. No application defines a second neutral palette, and a brand hue does not recolour `--window`, `--panel`, `--raised`, `--control`, `--control-hover`, `--well`, `--separator`, `--hairline`, `--text*`, `--warning` or the error red.

| Accent token | Example Dark baseline | Example Light baseline | Shared role |
|---|---|---|---|
| `--accent` | `#7b90df` | `#3c56aa` | Terminal prompt, list numbers and active state. |
| `--accent-light` | `#7b90df` | `#3c56aa` | Active lines, focus, links and transient status. |
| `--accent-about` | `#899de6` | `#3c56aa` | About wordmark and links. |
| `--accent-fill` | `#3c56aa` | `#3c56aa` | Primary buttons and selected tools. |
| `--accent-hover` | `#344c98` | `#344c98` | Hovered primary buttons and selected tools. |
| `--accent-foreground` | `#ffffff` | `#ffffff` | Text and icons on an accent fill; fixed family colour. |

**Calmer Light accents.** Light is the quiet appearance, so its accents default to the deeper fill colour instead of the bright Dark accent. An application specifies only its Dark `accent`, `accentFill` and `accentHover` in `forge.config.json`, and `forge-shell` supplies the remaining values.

| Omitted value | Default |
|---|---|
| Dark `accentLight`, `accentAbout` | The Dark `accent` |
| Light `accent`, `accentLight`, `accentAbout`, `accentFill` | The Dark `accentFill` |
| Light `accentHover` | The Dark `accentHover` |

Any Light value may still be specified to override its default, and the others remain derived. The contrast checks of 4.5:1 apply to the final values, so a fill that is too light for Light is rejected with the value named.

The application records its Dark accents and any Light overrides in `documentation/INTERFACE.md` and tests their legibility against the shared white foreground and the neutral backgrounds. The initial of the application and the initial and extension of the document icon use the approved brand ink recorded there. Warning amber and error red keep their shared values and meanings in every application. Any further appearance requires its own profile contract.

### Application and document icons

The Forge icon family has a single design, with the initial, extension and accent of each application. Approved source artwork that already follows the design is preserved exactly and is not redrawn.

| Asset | Family construction | Per-application substitution |
|---|---|---|
| Application icon | `assets/icon.png`, 1024 × 1024 RGBA, transparent outside one large serif capital taken from the GFS Artemisia letterform of the application. It has no tile, circle, paper background, shadow, word or border. The visible capital is 700 px high (y = 162 to y = 862), centred optically on x = 512, with a width that follows the approved glyph and the proportions and optical alignment of the original letter. | The first capital of the product name, in the approved icon colour. Example: `N` in `#7188e9`. The glyph outline comes from the approved master asset and not from a CSS approximation. |
| Native document icon | A separate 1024 × 1024 transparent artwork: a white portrait page with a folded upper-right corner, a thin cool-grey outline and a soft shadow. The capital of the application is placed prominently on the page, with the uppercase extension without the dot below it, both in the document-icon colour. The bare application icon is not reused for a document association. | Initial, extension text and document-icon colour. Example: `N`, `NFG`, `#7288e8`. An extension longer than three letters requires a fit rule in the profile that keeps the label within the page. |

The canonical geometry of the document icon, at 1024 px, is given below.

| Element | Value |
|---|---|
| Page vertices | `(170,70)`, `(644,70)`, `(854,280)`, `(854,954)`, `(170,954)` |
| Fold | 210 px; fill `#e4e8f4` |
| Page and outline | White `#ffffff` page; 4 px `#cdd2de` outline |
| Shadow | Black at y + 14, alpha 90/255, Gaussian blur radius 18 px |
| Initial | Cropped to its non-transparent bounds, resized to 380 px high with unchanged aspect ratio, centred on x = 512 at y = 330, tinted with the document-icon colour |
| Extension label | Centred at y = 760, bold Arial (Helvetica as fallback), 118 px for three characters |
| Canvas | Transparent outside the page and shadow |

The generator of an application may reside in its `scripts/` folder, and a future application may implement the same geometry in another build tool while retaining the output contract.

The source artwork and the generated `.png`, `.icns` and `.ico` document versions are kept in `assets/icon/`, named for the lowercase extension (`nfg.png`, `nfg.icns`, `nfg.ico`). The application icon master remains at `assets/icon.png` and serves as the application and installer icon and as the browser favicon. The document-icon stem is registered in Electron `fileAssociations` with the extension, a human-readable name and description, and the editor or viewer role; the MIME type is recorded where applicable. The packaged application icon and the icon of a saved file are verified at 16, 32 and 256 px in Finder and Explorer, since a generated source PNG does not prove registration. An application without a native document format records `none` and has no document icon.

The profile records the path and checksum of the approved capital asset, the accent and document-icon ink colours, the extension label, the generated paths and the build command. The provenance of fonts and artwork and the licence wording are kept in `NOTICE.md`. GFS Artemisia is not bundled merely to render an exported PNG. The folded-page document icon remains the family standard even when an application icon is supplied.

### ASCII wordmark

Each application provides a plain-text wordmark at `assets/logo.txt`, written by `forge-shell wordmark <Name> --out assets/logo.txt` (`renderWordmark`). The wordmark spells the product name in its exact brand case in the family's lettering, so that the wordmarks of all applications match:

| Part | Rule |
|---|---|
| Lettering | The Roman FIGlet font by Nick Miners (`scripts/fonts/roman.flf`), as patorjk.com's Text to ASCII Art Generator sets it with the Roman font |
| The family's g | The font's g without the row `` `8oooooo. `` between the bowl and the tail, so its tail sits one line higher |
| Spacing | Neighbouring letters sit exactly one blank column apart where they come closest (`LETTER_GAP`); no line ends in blanks, and there are no blank rows above or below |

The tests `a wordmark is the name in the Roman lettering, with no trailing blanks and no blank rows above or below`, `the family's g is the font's g one line shorter: no row between the bowl and the tail` and `neighbouring letters sit exactly one blank column apart where they come closest` enforce the rules. The glyphs, line count and width therefore depend only on the name. The asset stores literal printable characters and spaces with line breaks and is not a runtime-generated font. Leading spaces and interior alignment are preserved, and only trailing whitespace at the end of the complete asset is trimmed on rendering. The case is not transformed, spaces are not collapsed, lines are not wrapped and no theme substitutes another font. When the asset cannot be loaded, the product name is shown as plain text. The profile records the asset path, the source font or generator, the edits, the author and licence, and a checksum, so that a later rebuild reproduces the same art.

The same wordmark appears in the Terminal banner and in all four information-dialog headers.

| Property | Terminal banner | Information dialog |
|---|---|---|
| Element | Preformatted `<pre>` with zero margin and letter spacing | The same |
| Weight and size | 700, at the saved Terminal size (default 12 px, range 10 to 24 px), line height 1.15 | Fixed 700 12 px/1.15, mono |
| Colour | `--accent` | `--accent-about` |
| Overflow | Horizontally scrollable, never wrapped | The same |

Immediately below the wordmark, the one-line purpose is followed by exactly three spaces and `v<VERSION>` in bold mono; the purpose uses `--text` and the version `--text2`. The information dialog adds a lowercase subtitle such as `about` or `licenses` in bold 12 px/1.4 mono `--text2`. The decorative ASCII art is `aria-hidden="true"`, with a separate accessible product name. The large wordmark does not appear in ordinary editing views. The provenance and licence wording of the asset are kept in `NOTICE.md`.

## 3. Typeface, case and text colour

The interface uses the system UI stack `-apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif` and the mono stack `ui-monospace, "SF Mono", SFMono-Regular, Menlo, "Cascadia Mono", Consolas, monospace`. The base chrome is set in the 12 px UI font. Terminal, Messages and technical readouts use the mono stack; labels, prose and menu text use the UI stack.

| Text role | Case rule | Size and weight | Colour |
|---|---|---|---|
| Product name | Brand case from the profile: `ExampleForge` | Context dependent | `--text` in prose; accent for the wordmark |
| Package, storage and command identifier | Lowercase: `exampleforge` | Mono when shown | `--text` |
| Menu heading and Terminal help category | Initial capital, then lowercase where appropriate: `File`, `Edit`, `Project`, `Document`, `Analysis`; never `FILE` or `PROJECT` | Menu base 12 px UI; help category bold 12 px mono | `--text` |
| Menu action, dialog title, inspector property | Sentence case: `Save as…`, `Build PDF`, `Maximum time step`; proper names and technical abbreviations preserved | Popup 13 px UI; field label 12 px UI | `--text` for an action, `--text2` for a property label |
| Bottom-panel tab and inspector section | Displayed in uppercase by CSS (`TERMINAL`, `MESSAGES`, `BUILD`, `PROPERTIES`); labels are stored in normal case | 10 px, weight 600, `0.6px` letter spacing | Active tab `--text`, inactive `--text3`; section title `--text2` |
| Terminal command verb and state | Lowercase: `save`, `help`, `[on]`, `[off]`; literal file names and identifiers keep their case | 12 px mono; the active word is bold | Help verb, prompt, numbered marker and `[on]` use `--accent`; `[off]` uses `--text2` |
| Terminal entered command | As typed by the user; the documented spelling is lowercase | Bold 12 px mono | `--text`; the prompt remains in the accent |
| Terminal explanation, ordinary list detail, table heading | Sentence case; units and identifiers preserved | Normal 12 px mono | `--text2` |
| Numbered item name | The name of the document or object | Bold 12 px mono | `--text`; the number marker in the accent |
| Document-tab title | The case of the file or project name | Normal 12 px UI | Active `--text`, inactive `--text2`, dirty dot in the accent |
| Status state and message | Initial capital for a state (`Running`, `Paused`, `Ready`); sentence case for a result | 11 px mono | Ordinary `--text2`; transient result `--accent-light` |
| Message kind | `Info`, `Warning`, `Error` | 12 px mono | Info `--text2`, Warning `--warning`, Error semantic red |
| Message body | Sentence case with a final period; filenames, commands and technical symbols preserved | 12 px mono | Info and Warning `--text2`, Error `--text`; object link in the accent |
| About heading, prose and link | Sentence-case headings; prose with proper names | Heading bold 12 px UI; prose 12 px/1.45 UI | Heading `--text`, prose `--text2`, link `--accent-about` |

**Text role classes.** `shell.css` implements the table as classes that carry family, size, weight, colour and alignment. Applications use these classes and write no sizes or colours of their own. Canvas and script code imports `FONT_UI`, `FONT_MONO` and `roleFont(family, size, weight)` from the shell and does not copy the stacks.

| Class | Role and alignment |
|---|---|
| `t-label` | Label (left) |
| `t-value` | Value (right, tabular numerals) |
| `t-mono`, `t-quiet`, `t-link`, `t-heading` | Mono text, quiet text, link, heading |
| `t-tab` | Tab (centred, uppercase) |
| `t-section` | Section title (left, uppercase) |
| `t-kind`, `t-kind-info`, `t-kind-warning`, `t-kind-error` | Message kind |
| `t-marker` | List marker (right, tabular numerals) |

**Builders.** `createButton`, `createField`, `createRow`, `createListLine` and `listMarker` build the standard button, labelled field, property row and list line from these classes, so that the markup is not written by hand in applications.

| Control | Text |
|---|---|
| Property text input and textarea | 11.5 px mono |
| Select | 12 px UI |
| Empty Terminal and Messages notes | 12 px/1.4 mono, `--text2` |
| About wordmark | Bold 12 px/1.15 mono, `--accent-about` |
| About numbered list | 12 px/1.45 mono |

Ordinary document text remains selectable where editing or copying is useful, and the selection of chrome text does not interfere with drag actions.

Only the CSS of the pane tabs and of the inspector sections uses `text-transform: uppercase`; Terminal help categories are written as `File`, `Project` and so on, without an uppercase transform, and commands are lowercase. One name designates each concept across menu, toolbar, inspector, Terminal, tooltip and documentation. Units are placed in a separate property unit column and displayed as `4.7 kΩ`, `27 °C`, `300.15 K`, `20%` and `45°`: a space separates number and unit except for the percent sign and the plane angle, and an SI prefix stays attached to the unit. Interface messages use no decorative middle dots, arrows or dashes as separators.

### Text selection

Selected text is highlighted with `--selection`, the accent at 30% opacity, which follows the active appearance; the text colour does not change.

| Case | Rendering |
|---|---|
| Shell-drawn selection | One rounded shape: lines are joined without gaps, every corner (including the inner corners between lines of different length) is rounded with the `--radius` size (4 px), separate blocks form separate shapes, and the shape lies behind the text. `attachSelectionShape(element)` produces it for any selectable text region, and the shell attaches it to Terminal and Messages, so every application receives it by default. |
| Editors | The editor of an application draws its selection identically (same colour, shape and radius), using the shell geometry (`bandsFromRects`, `joinBands`, `roundedPath`) in its own selection layer. |
| Other text (inputs, textareas) | The native highlight in the `--selection` colour, since a form control cannot draw a custom shape. |
| Select all in Terminal | Cmd or Ctrl+A, and Edit › Select all through `TerminalPanel.selectAll()`, select the text after the `>` while the prompt has the focus (nothing when it is empty), and otherwise the whole transcript, also while a command runs; the transcript is drawn as the shell-drawn selection. The `>` before a command is never selected or highlighted. |

