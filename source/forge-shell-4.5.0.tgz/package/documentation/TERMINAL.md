# Terminal commands

Every command of every Forge application is written, validated and explained by the rules below, so that the same kind of command reads the same in each. The shared commands come from the shell (`SHARED_COMMANDS`, with their help in `sharedHelpDetails()`); an application adds its own commands by the same rules. Section 7 of [GUIDELINES.md](GUIDELINES.md) gives the layout and colours of the output.

## Registry entry

Each command is one entry (`CommandSpec`) and one entry of help details (`HelpDetails`). Nothing about a command is written anywhere else: validation, help, completion and the overview all read these two.

| Field | Rule | Example |
|---|---|---|
| `name` | One lowercase word | `zoom` |
| `syntax` | The verb and its parts: `<value>` required, `[value]` optional, words of a choice not listed in the syntax | `zoom <choice>`, `terminal [setting] [choice]` |
| `description` | A fragment of one line, beginning with a verb in the imperative, initial capital, no final period, at most about 70 characters | `Show or set the appearance` |
| `args` | The regular expression of every accepted argument, the empty one included where the value is optional | `/^(\|dark\|light)$/` |
| `choices` | The documented choices, in the order of the help | `["dark", "light"]` |
| `choices` in the details | Every choice with its description, a fragment like the command's own; a choice is never listed without one | `["dark", "Dark appearance"]` |
| `notes` | Complete sentences, each ending with a period, for what the syntax and choices do not say | `With no value, the current appearance is shown.` |
| `example` | One realistic command, at most | `theme light` |

A choice that is accepted but not documented, such as a hidden appearance, is in `args` only: it is never in `choices`, never completed and never mentioned in help or in a document.

## Forms

| Form | Rule |
|---|---|
| Query | A command whose value is optional reports the state when it is given none, without changing it, in one sentence: `The appearance is dark.`, `The bottom panel is on.`, `The Terminal text size is 12 px.` |
| Change | A command that changes a state reports the resulting state: `Light mode enabled.`, `Autosave set to after 1 minute.` |
| Already | A change to the current state says so: `Dark mode is already on.` |
| Action | A command that runs a menu action (`zoom fit`, `save`) prints nothing when the action shows its own result. |
| Document | A command that needs an open document answers `Open a <noun> first.` without one, and is not listed or completed on the welcome screen. |

On and off states use `on` and `off`; units follow a space (`12 px`).

## Help

`help <command>`, `<command> -h`, `<command> --help` and `<command> ?` print exactly the same detail view (`helpAlias()` maps the last three to the first before anything else is checked); `-h` and `--help` alone mean `help`.

| Line | Content |
|---|---|
| Syntax | Each form from column 0 with ` - ` and its description |
| Choices | Each choice indented 3 characters, ` - ` and its description, padded to the longest choice; the default ends with `(default)` |
| Notes | Each sentence on its own line from column 0, without a dash |
| Example | `Example - ` and the command, last |

Bad arguments print `Invalid arguments. Usage:`, each form indented 3 characters with its description, and `Type help <command> for details.` The overview lists the bare verbs by group (`File`, `Edit`, `View`, the application's groups, `Help`, `Console`) with their descriptions only.

## Shared commands

| Command | Syntax | Choices | Notes |
|---|---|---|---|
| `new`, `open`, `close`, `undo`, `redo`, `print` | the verb alone | | |
| `recent` | `recent [number]` | | With no value, the recent files are listed. |
| `settings` | `settings [page]` | | A page's name opens Settings on that page. With no value, Settings opens on the page shown last. |
| `save` | `save [as]` | `as` Save the document under a new name | With no value, the document is saved. |
| `autosave` | `autosave [choice]` | `off`, `1m`, `5m`, `focus` | With no value, the current choice is shown. |
| `zoom` | `zoom <choice>` | `in`, `out`, `fit`, `actual` | |
| `panel` | `panel [choice]` | `on`, `off` | A pane's name shows that pane. With no value, the panel's state is shown. |
| `inspector` | `inspector [choice]` | `on`, `off`, `left`, `right` | With no value, the inspector's state is shown. |
| `theme` | `theme [choice]` | `dark`, `light` | With no value, the current appearance is shown. |
| `about`, `version`, `changes`, `shortcuts`, `licenses` | the verb alone | | |
| `help` | `help [command]` | | `<command> -h`, `<command> --help` and `<command> ?` also show a command's help. |
| `terminal` | `terminal [setting] [choice]` | `font bigger`, `font smaller`, `banner on`, `banner off`, `caret blink`, `caret steady`, `spacing comfortable`, `spacing compact`, `wrap on`, `wrap off` | Shows or sets a Terminal preference: the text size (`terminal font <number>`, 10 to 24 px, or one pixel `bigger` or `smaller`), the banner at the top, whether the caret blinks, the spacing of the lines (1.4 or 1.2 times the text size) and whether a long line wraps or the Terminal scrolls sideways. With no setting, every preference is shown. The verbs sit under `terminal` so that they never meet a command of an application. |
| `history` | `history [number]` | `clear` Clear the command history; `limit` Show or set how many commands are kept | A number lists that many of the last commands. `history limit 25`, `50` or `100` sets the most kept; with no number the current limit is shown. |
| `clear` | `clear` | | |

An application registers these with `sharedCommands(actions)`, their help with `sharedHelpDetails()` and their groups with `sharedHelpGroups()`, and adds its own commands after them in its own groups. It never redefines a shared command.
