# Forge application guidelines

## Scope

Sections 1 to 12 form the interface contract that every Forge application follows. Sections 13 and 14 specify behaviour that the first applications had but the contract did not cover, and define the shared `forge-shell` package, which implements the contract once for all applications. Section 15 lists what is removed from code copied from an existing application, section 16 describes how the package is created, section 17 records the notes on this guide, and section 18 gives the checklist for migrating one application.

The contract defines the shell, the visual tokens, motion, writing, commands, lists and feedback. It assigns no application a domain, file format, domain-menu catalogue, tool palette or domain-command catalogue; these belong in a short application profile and in the user and format guides of the application. The measured interface reference of an application is a source-backed example, and [PROJECT-STRUCTURE.md](PROJECT-STRUCTURE.md) covers the repository layout.

**Rule strength.** Every shell, appearance, motion, typography, menu, Terminal, listing and message rule applies to every Forge application. A conditional rule applies only to a domain feature that is genuinely absent, such as a file format or a graph. It does not permit omitting the shared inspector, Terminal, Messages, panel controls, Help destinations. A profile supplies product identity and domain behaviour only and cannot waive a shared rule. An exact replica of an existing application additionally requires the source and visual assets of that application.

**The shell is binding.** `forge-shell` is the concrete implementation of this contract, and its guidelines are strict. Wherever a shell part does what an application needs, the application uses that part, as it is: its dialogs (`askToSave`, `askToSaveAll`, `askToApply`, `askToPick`, `askToChoose`), saving and export (`saveDocument`, `exportFiles`, `registerExportIpc`), renaming (`attachRename`, `startRename`), the inspector's rows and widgets, the file tree, the Terminal, Messages, the status bar, the tool strip and flyouts, the generator pane and its preview, the code editor and find bar, the viewport, wheel and selection rules, and the shared styles. An application does not write its own version of a part, wrap it to look or behave differently, restyle it from its own CSS, or reach past it to the platform (a native message box, `window.confirm`, its own export dialog or binary writes). When a part does not fit, the part is changed in `forge-shell`, for every application, and the application waits for that release; it never strays on its own. A new part joins the shell when a second application needs it, and from then on every application that needs it uses it. `check-app` refuses an application that uses a known substitute (`SHELL_SUBSTITUTES`: native message boxes, browser prompts, an export dialog of its own), a project file that is not `.<letter>fg`, and one without the shell's Settings: every application has Settings… (`app.settings`), opens it with `showSettings`, includes the General and Terminal pages, and Updates when its profile names a repository, and draws no settings dialog of its own (`settingsProblems`).

**Project files and exports.** A project file is always `.<letter>fg`: the application's initial and `fg` (`.nfg`, `.lfg`, `.pfg`), and only Save writes it. An export may be any of the application's formats, is written only where the person chose in the export dialog or folder dialog, never replaces a file by surprise, and never writes a project file or an original the document reads (`exportProblem`).

## 1. Required application profile

Each Forge application keeps an `INTERFACE.md` in its `documentation/` folder. The fields below are recorded explicitly; `none` is a valid value for an inapplicable feature.

| Field | Required content |
|---|---|
| Identity | Product name and capitalisation, lowercase package and command identifier, one-line purpose, version source, author and credits, application-icon source and packaging paths, ASCII wordmark path and exact text, artwork provenance and asset checksum |
| Documents | Primary noun, file extension and MIME type, document-icon files and file-association metadata, new, open, save, import and export behaviour, existence of document tabs, dirty-state rule, close prompt, and whether a project contains several files |
| Theme | The Dark and Light accent substitutions of the application, semantic domain-data colours, and the ink colours of the application and document icons; all other chrome colours are inherited from section 2 |
| Workspace | Centre views, the name of the first inspector section (`General` by default), inspector sections and default folds, bottom tabs and their order, default panel sizes and justified deviations from section 4 |
| Navigation | Pointer, wheel, pinch, pan, zoom, keyboard and drag behaviour of each centre view; `none` for an action without a meaningful equivalent |
| Actions | Ordered menus; the identifier, label, shortcut, enabled and checked condition of every action; toolbar groups, tooltips and command aliases |
| Terminal | The command registry with syntax, examples, completions, application-level and document-level scope, cancellation and output type |
| Messages | Application-specific success, warning and error examples, object links, standing-condition keys and persistence |
| Persistence | The values held in application preferences, in the document, or only in the current session |
| Verification | The screens and views to inspect, keyboard paths, document round trips, and platform build and launch checks |
| Build and runtime profiles | `forge.config.json` (identity, document or `null`, theme, HTML slots, desktop metadata) and the runtime menu, command, inspector and pane catalogues |

The profile is the exact application-specific contract. Scopes, document archives, circuit palettes, graph views and other domain features belong in the profile of the application and not in this family-wide document.

## Where each section is

Each part of the contract is in one file. Read the index and the file of the area you change; the section numbers are the same in every file and in every reference.

| Sections | File | Content |
|---|---|---|
| 1 | This file | The required application profile |
| 2 and 3 | [GUIDELINES-APPEARANCE.md](GUIDELINES-APPEARANCE.md) | Colour tokens, logo and icons, wordmark, typeface, case and text colour |
| 4 and 5 | [GUIDELINES-SHELL.md](GUIDELINES-SHELL.md) | Window geometry, inspector, code editor, selection, panes, saving, motion |
| 6 | [GUIDELINES-TABS-MENUS.md](GUIDELINES-TABS-MENUS.md) | Document tabs, renaming, file tree, dropped files, shortcuts, menus, toolbar, status bar, tiles |
| 7 to 10 | [GUIDELINES-TERMINAL.md](GUIDELINES-TERMINAL.md) | Terminal and commands, listings, status and messages, dialogs and remembered settings |
| 11 to 13 | [GUIDELINES-PREVIEW.md](GUIDELINES-PREVIEW.md) | Localhost preview, implementation gate, context menus, tooltips and unit fields |
| 14 to 18 | [GUIDELINES-CONTRACT.md](GUIDELINES-CONTRACT.md) | Shell architecture, boundary checklist, package, new application, release decisions, migration |

Tests read all of these files together. A table that is checked against the CSS keeps its heading exactly as written.
