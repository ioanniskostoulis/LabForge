# Forge application guidelines: shell contract

Part of [GUIDELINES.md](GUIDELINES.md), sections 14 to 18.

## 14. Shell architecture

Every rule above is implemented once, in the shared package `forge-shell`, and applications consume it at a pinned version. This section is the standing contract.

| Belongs to the shell | Belongs to the application |
|---|---|
| Tokens and the three themes; the frame (tool strip, tabs, panels, splitters, status bar, welcome state) | Product identity, icon capital, wordmark, brand accents |
| Menu renderer, shortcut display and matching, context menu, native menu construction | Domain menus and their actions |
| Terminal, Messages, help rendering, shell verbs, completion | Domain command registry |
| Dialog base, save prompts, About, What's new, Shortcuts and Licenses frames | Credits, licence text, introductory prose |
| Inspector sections and widget kit | Inspector contents |
| Preferences mechanism and shell keys | Preference keys of the application |
| Document lifecycle (new, open, save, `Untitled n`, dirty state, close) | Document model, format, export formats |
| Electron main helpers, packaging configuration, reusable workflow, icon generator, version tooling | IPC handlers and domain scripts of the application |
| Conformance tests | Domain tests |

An application describes itself to the shell in two places.

| Place | Content |
|---|---|
| `forge.config.json` (read at build time by the scripts of the shell) | `identity` (name, id, purpose, wordmark path, version source, port); `document` (nouns, extension, welcome labels, tab nouns, `containsMultipleFiles`; `null` for none); `theme` (the Dark accents and any Light overrides); `html` (the markup files of the centre and the domain panes); `prePaintScript` (optional script run before the first paint); `desktop` (application identifier, copyright, icons, file association, extra resources, installer artwork and family name); `dataColors` (colours that carry data, exempt from the colour lint) |
| A runtime profile object (`ForgeRuntimeProfile` in `source/app/profile.ts`) | The menu builder and menu commands, the console command catalogue, the inspector sections and the order of the bottom panes, handed to the shared renderers |

For an application without saved documents, `document` is `null`, `desktop.document` is omitted, and its permanent centre view is placed in `html.center`. A minimal monitor profile is given below; the accent values are examples that pass the shared contrast gate.

```json
{
  "identity": { "name": "MonitorForge", "id": "monitorforge", "purpose": "system monitor", "wordmarkPath": "logo.txt", "versionSource": "VERSION", "port": 5175 },
  "document": null,
  "theme": {
    "dark": { "accent": "#7b90df", "accentFill": "#3c56aa", "accentHover": "#344c98" }
  },
  "html": { "center": "public/center.html", "panes": "public/panes.html" },
  "desktop": { "appId": "com.monitorforge.app", "copyright": "Copyright 2026 MonitorForge" }
}
```

Its runtime profile can provide `panes: ["terminal", "metrics", "messages"]` and no document actions. The page keeps the shared tab slot empty and renders the centre view immediately.

| Rule of the boundary | Content |
|---|---|
| Imports | The shell never imports application code. An application imports only `forge-shell/app`, `forge-shell/desktop/*`, `forge-shell/styles/*` and the listed `forge-shell/scripts/*` exports. |
| New needs | A need that the profile cannot express becomes a new shell option for every application, and not an override of shell internals in an application. |
| Versions | A shell change that alters behaviour is a minor or major version and appears in the changelog of the shell. |
| Tests | The shell carries its own tests (`tests/conformance`): the `.ts` tests are portable and read no files, so that an application can bundle and run them; a test that reads the shell's own files (its stylesheet, its scripts) is an `.mjs` test and runs in the shell only (`the portable conformance tests read no files, so that an application can run them bundled`). An application demonstrates correct use with `forge-shell check-app` (script `test:shell`) and by bundling the tests of the shell from `node_modules/forge-shell/tests/conformance` in its own `test:app`. |
| Style lint | `forge-shell check-app` lints `public/app.css` and `source/` of the application for raw colours, font sizes outside 10, 11, 12, 13 and 15 px, font weights outside 400, 600 and 700, `text-transform: uppercase`, inline font or colour styles, `!important`, unnamed icon-only buttons, icon strokes other than 1.25 px and direct `.title` assignments. Colours that carry data (scope traces, editor syntax) are listed under `dataColors`. Problems are warnings; `FORGE_STYLE_LINT=error` makes them errors. |

### Generic boundaries

These were application-specific assumptions inside shell code, and each now takes its content from the application.

| Where | Before | Now |
|---|---|---|
| `status-bar.ts` | `Running` and `Paused`, `time`, `grid`, `cursor`, `zoomPercent` and fixed colours | The shell renders the bar and the problem count; the application supplies `stateLabel`, `stateColor`, `summary`, `detail`, `hint` and a list of `readouts` |
| `workspace-keys.ts` | `partKey`, `spaceDown`, `spaceUp`, `nudge`, a fixed `edit.delete` | The shell handles text fields, Esc and menu shortcuts; the application handles its own keys through `domainKeyDown` and `domainKeyUp` |
| `templates/app/index.html` | `whiteBackground` and the `paper` class in the pre-paint script | The shell restores the appearance, and the script of the application (`prePaintScript` in `forge.config.json`, `public/prepaint.js`) applies its settings |

### Remaining integration requirement

| Where | Requirement | Direction |
|---|---|---|
| Generated workflows | The `test:shell`, `check-release.mjs --mac` and `--win` scripts of the application must exist | Documented as required application scripts in UPDATING.md |

## 15. Boundary checklist

The following must not appear in shell code. The first extraction removed all of them from the shell modules, and each new module is checked against the list before it is added.

| Category | Must not appear in shell code | Belongs to |
|---|---|---|
| Identifiers | A product name or id (`exampleforge`), storage keys, environment-variable prefixes, temporary prefixes, `appId`, ports | `forge.config.json`; storage keys come from `settingsStorageKey` and `terminalHistoryStorageKey` |
| Strings | Domain nouns (`circuit`), taglines, About credits, window titles | `forge.config.json` and the About data of the application |
| Document behaviour | A file extension, native format, export list, save filter | `document` and `desktop.document` of `forge.config.json` |
| IPC | Domain channels (`models:*`, `console:*`) | The `main.ts` of the application, registered beside `registerShellMainIpc` |
| Imports | Anything from the engine, library, palette, settings or domain modules of an application | Data and callbacks are passed instead |
| Theme | Brand hex values of an application in shell CSS; schematic or data palettes | `theme` of `forge.config.json`; the renderer of the application |
| CSS and HTML | Element identifiers and classes of an application (`schematic`, `scopes`, `paper`) | `public/center.html`, `public/panes.html` and `public/app.css` of the application |
| Scripts | A hard-coded name, port or list of entry points | Read from `forge.config.json`; the application lists its own build targets |
| Headers | A source file without the licence header | The GPL v2 or later header of the shell is added |

`forge-shell check-app` verifies the built page, the brand CSS and the shared stylesheets, and it scans the source of the shell for product identifiers and formats. Broader domain nouns and behaviour are reviewed by hand.

## 16. Package

| Subject | Specification |
|---|---|
| Repository | `forge-shell`, GPL-2.0-or-later, with tags `vX.Y.Z`. The package is source-only: applications bundle its TypeScript with esbuild and `moduleResolution: Bundler`, and there is no `dist` and no `prepare` step. |
| Installation | `github:<owner>/forge-shell#vX.Y.Z` when the CI of the application can read the repository. For a private repository without cross-repository credentials, `npm pack` is run on a clean checkout of the tag, `forge-shell-X.Y.Z.tgz` is kept in the application, and the dependency is `file:source/forge-shell-X.Y.Z.tgz`; the integrity field of the lockfile pins the archive. |
| Exports | `./app` and `./app/*`; `./desktop/main`, `./desktop/preload` and `./desktop/*`; `./styles/tokens.css` and `./styles/shell.css`; `./templates/*`; and `./scripts/*` for `build`, `build-installer`, `cache-key`, `check-app`, `check-release`, `theme`, `package-config`, `dmg-background`, `file-icon`, `version-hook`, `release-notes`, `web` and `serve` |
| Command | `forge-shell check-app`, `package-config` (writes `build/electron-builder.json`), `dmg-background` (draws the macOS disk image window into `build/dmg`), `brand-css` (writes `build/app/forge-brand.css`), `installer`, `licenses` and `release-notes` |
| Version | `VERSION`, `package.json` and the lockfile agree, and `CHANGELOG.md` has a section per version, with migration notes for breaking releases. A published tag is never moved. |
| Workflows | `forge-shell workflows` writes the four build workflows of an application (Build desktop apps, Build for mac, Build for windows, Clear all), which run the checks, the macOS and Windows builds, the Windows launch and installer checks and the gated release. The application supplies the scripts `check`, `test`, `test:app` and `test:shell`, `scripts/check-release.mjs --mac\|--win` and its two Windows PowerShell scripts. |
| Local work | While the shell and an application are edited together, the application points to a local `file:` copy, which is replaced by the pinned tag or archive before committing. |

```text
forge-shell/
├── source/
│   ├── app/                    # frame, tabs, menus, terminal, messages, dialogs, inspector, settings, profile
│   ├── desktop/                # bridge, native menu, window state, file helpers, main IPC
│   └── styles/                 # tokens.css, shell.css
├── scripts/                    # build, serve, web, theme, package-config, check-app, check-release, cache-key, release-notes, version-hook, file-icon, forge-shell (command)
├── templates/
│   ├── app/                    # index.html page template
│   └── new-app/                # the files of a new application (forge-shell new-app)
├── tests/conformance/
├── .github/workflows/          # check-shell, build-package, publish-release, clear-all
├── documentation/              # GUIDELINES, PROJECT-STRUCTURE, UPDATING, DEVELOPMENT, COMPATIBILITY, INSTALLER
└── VERSION  CHANGELOG.md  NOTICE.md  LICENSE  README.md  package.json  tsconfig.json
```

### Disk image window

The macOS disk image opens a 600 × 400 pt window drawn by `forge-shell dmg-background` before packaging (`scripts/dmg-background.mjs`). Everything drawn stays within the top 316 pt of the background, since the window height includes the 32 pt title bar and Finder may add its path and status bars. It shows the wordmark of the application in its Light accent, a 2 pt accent line along the top edge, a hairline under the wordmark, the application and the Applications link at 96 pt on one row at 184 pt, 150 pt either side of the centre, an accent arrow between them, and two lines of install text in `--text2` and `--text3`. The background is the Light `--panel` colour, so that the labels Finder draws in black remain readable. `.background.tiff` and `.VolumeIcon.icns` are listed again under their own names and placed 200 pt below the window, so that they stay out of view when Finder shows hidden files; Finder then shows a scroll bar. The tests `the disk image window centres the app and Applications and moves its hidden files out of view` and `the disk image background carries the wordmark and arrow in the light accent and the install note` enforce the layout.

### Setup rights

The Windows setup executable is marked `asInvoker` and starts an elevated copy of itself when it lacks administrator rights; it is never marked `requireAdministrator`, which stops the sandboxed helper processes of Chromium. The generated Windows job opens the interactive setup window and fails on a missing or blank screenshot. The details are in [INSTALLER.md](INSTALLER.md#installation). The tests `the setup build pins the installed Electron version and stages the payload manifest`, `the elevation script waits for the elevated copy, passes its exit code and reports a declined prompt as Cancelled` and `the Windows job opens the interactive setup window and checks its screenshot before the silent installation` enforce the rule.

### Silent setup log

A silent run of the Windows setup (`/S`, `/uninstall`) writes its stages to `<id>-setup.log` and keeps the local crash dumps of Electron in the same folder, so that a run ending without one of its own exit codes shows the last stage it reached. The folder, the entries and the CI handling are described in [INSTALLER.md](INSTALLER.md#setup-log-and-crash-dumps). The tests `a silent setup records its stages and keeps crash dumps locally, beside the log` and `a failed Windows installer check shows the setup log and keeps it with the crash dumps` enforce the rule.

### Starting a new application

`forge-shell new-app Name --ext ext --accent #rrggbb --purpose text --author name` writes a new application into a new or empty folder (`--out`, by default `./Name`). The name is one word with a capital first letter; the extension defaults to the first letter of the name followed by `fg`, as in `.nfg` and `.lfg`. From the one accent colour, `deriveAccents()` makes the five Dark accents: the accent and its light variant lightened until they have 4.6:1 on the input surface (`#1b1b1b`), the About accent 6 % lighter, the fill darkened until white labels on it and it on the Light input surface (`#f8f8f7`) have 4.6:1, and the hover 6 % darker than the fill. Light takes the fill and hover, as `resolveTheme()` defines, and both appearances are written into `forge.config.json`.

The new application has the frame of the shell and no domain: the menus (File with New, Open and Autosave; Edit; View with the inspector, the bottom panel and the appearance; Help), the tool strip with Undo and Redo, the inspector, Terminal with the shared verbs, Messages, the status bar and the welcome screen. It has the desktop main process and preload with the shared bridge, file dialogs for its extension, recent documents, the single-instance rule and the launch capture; its wordmark in `assets/logo.txt`; a placeholder icon, a square in the accent, to be replaced before a release, and its document icons, made by `file-icon.py` when Python 3 with Pillow is installed; the build, preview, check, packaging and release scripts; and the four workflows. As generated, it type-checks, builds, passes its tests, the shared conformance tests (`npm run test:app`) and `forge-shell check-app` with no style warning, runs in the browser preview and on the desktop, and packages with `npm run dist`, after which `scripts/check-release.mjs --mac` passes. The next steps are listed in its `documentation/DEVELOPMENT.md`.

## 17. Release decisions

The shared code and its consumer are reviewed and committed separately. The reusable workflow of the shell requires the application scripts listed in section 14. The archive pin of each application stays at a published tag, and uncommitted shell changes are not packaged as that tag.

## 18. Migration checklist for an application

| Step | Content |
|---|---|
| 1 | `documentation/INTERFACE.md` records the profile of the application, including the Dark accents and any Light overrides; `brandCss` rejects an accent below a contrast ratio of 4.5:1. |
| 2 | `forge.config.json`, `public/center.html` and `public/panes.html` are added, and the shell is pinned (tag or `file:` archive). |
| 3 | The copies of the application of tokens, build, serve, web, version and release scripts are replaced by the exports of the shell. |
| 4 | The frame, menus, Terminal, Messages, dialogs and inspector widgets are replaced by those of the shell, one module at a time, with the checks of the application run after each. |
| 5 | Domain menus, commands, inspector sections and About content move into the runtime profile. |
| 6 | `test:shell` (`forge-shell check-app` after a build) is added, and `node_modules/forge-shell/tests/conformance` is bundled into `test:app`. |
| 7 | The browser preview is checked at the default window size and a narrow one, then the packaged macOS application, then the automated Windows build and launch check. |
| 8 | The leftover shell code of the application is deleted in the same change. |
| 9 | Later shell updates follow `UPDATING.md`: the pin is raised, the checks of the application run and the changelog of the shell is read. |
