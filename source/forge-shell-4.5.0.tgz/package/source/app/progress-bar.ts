// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The family's progress bar, as the Forge setup draws it when an application is first installed: a monospace line
// `[=========|          ]  42%  Downloading`, the filled part in the accent, its end turning (| / - \) while work
// goes on, a `>` instead under reduced motion. The setup's renderer draws the same line (installer/renderer).

/** Characters of the bar between its brackets. */
export const PROGRESS_WIDTH = 30;
const SPIN = ["|", "/", "-", "\\"];
/** How often the end of the bar turns, in ms. */
export const PROGRESS_TICK_MS = 110;

/** The parts of the bar for a fraction `p` (0 to 1) at turn `tick`: the filled part, then the blank rest. */
export function progressBarParts(p: number, tick: number, reduce = false, width = PROGRESS_WIDTH): { filled: string; rest: string } {
  const fraction = Math.min(1, Math.max(0, Number.isFinite(p) ? p : 0));
  const count = Math.min(width, Math.floor(fraction * width));
  const head = fraction >= 1 ? "" : reduce ? ">" : SPIN[tick % SPIN.length];
  return { filled: "=".repeat(count) + head, rest: " ".repeat(Math.max(0, width - count - head.length)) };
}

/** The whole line as text: `[====|     ]  42%  Downloading`. */
export function progressLine(p: number, tick: number, label: string, reduce = false, width = PROGRESS_WIDTH): string {
  const { filled, rest } = progressBarParts(p, tick, reduce, width);
  const percent = String(Math.round(Math.min(1, Math.max(0, p || 0)) * 100)).padStart(3, " ");
  return `[${filled}${rest}] ${percent}%  ${label}`;
}

export interface ProgressBar {
  readonly element: HTMLElement;
  /** Move to `p` (0 to 1), with what is happening. */
  set(p: number, label: string): void;
  /** Stop turning; with a label, show the bar full with it. */
  finish(label?: string): void;
}

/** A progress bar that turns until `finish`; `role="progressbar"` with its value for assistive technology. */
export function createProgressBar(label = "", doc: Document = document): ProgressBar {
  const reduce = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const element = doc.createElement("div");
  element.className = "progress-bar";
  element.setAttribute("role", "progressbar");
  element.setAttribute("aria-valuemin", "0");
  element.setAttribute("aria-valuemax", "100");
  const state = { p: 0, tick: 0, label };
  const paint = () => {
    const { filled, rest } = progressBarParts(state.p, state.tick, reduce);
    const on = Object.assign(doc.createElement("span"), { className: "on", textContent: filled });
    const percent = String(Math.round(state.p * 100)).padStart(3, " ");
    const line = Object.assign(doc.createElement("span"), { className: "progress-line" });
    line.append("[", on, `${rest}] ${percent}%`);
    element.replaceChildren(line, Object.assign(doc.createElement("span"), { className: "progress-label", textContent: state.label }));
    element.setAttribute("aria-valuenow", String(Math.round(state.p * 100)));
    element.setAttribute("aria-valuetext", `${Math.round(state.p * 100)} %, ${state.label}`);
  };
  let timer: ReturnType<typeof setInterval> | null = setInterval(() => { state.tick++; paint(); }, PROGRESS_TICK_MS);
  paint();
  return {
    element,
    set(p, text) { state.p = Math.min(1, Math.max(0, p || 0)); state.label = text; paint(); },
    finish(text) {
      if (timer) { clearInterval(timer); timer = null; }
      if (text !== undefined) { state.p = 1; state.label = text; }
      paint();
    },
  };
}
