// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The Terminal's own preferences: how many commands the history keeps, whether the banner is drawn, whether the caret
// blinks, how closely the lines are spaced and whether long lines wrap. They are kept apart from the application's settings, so an application gains them without a new field;
// the Settings page and the Terminal commands read and write the same store.
import type { ConsoleResult } from "./terminal";

/** The numbers of commands the history can keep; the contract's 100 is the most. */
export const HISTORY_LIMITS = [25, 50, 100] as const;
export type HistoryLimit = (typeof HISTORY_LIMITS)[number];

/** The spacing of the transcript's lines: 1.4 times the text size, or 1.2 when compact. */
export const LINE_SPACINGS = ["comfortable", "compact"] as const;
export type LineSpacing = (typeof LINE_SPACINGS)[number];

export interface TerminalPreferenceValues {
  /** The most commands the history keeps. */
  historyLimit: HistoryLimit;
  /** Whether the wordmark, purpose and version are drawn above the transcript. */
  banner: boolean;
  /** Whether the drawn caret fades in and out; a steady caret stays solid. */
  caretBlink: boolean;
  /** The spacing of the lines of the transcript. */
  lineSpacing: LineSpacing;
  /** Whether a line longer than the Terminal wraps; otherwise the Terminal scrolls sideways. */
  wrap: boolean;
}

export const TERMINAL_PREFERENCE_DEFAULTS: Readonly<TerminalPreferenceValues> = { historyLimit: 100, banner: true, caretBlink: true, lineSpacing: "comfortable", wrap: true };

export interface TerminalPreferences {
  get(): Readonly<TerminalPreferenceValues>;
  update(change: Partial<TerminalPreferenceValues>): void;
  /** Call `listener` after every change; returns the function that stops it. */
  subscribe(listener: () => void): () => void;
}

/** The stored value, with anything unknown or out of range replaced by its default. */
export function parseTerminalPreferences(stored: unknown): TerminalPreferenceValues {
  const saved = (stored && typeof stored === "object" ? stored : {}) as Record<string, unknown>;
  const limit = HISTORY_LIMITS.find((choice) => choice === saved.historyLimit);
  return {
    historyLimit: limit ?? TERMINAL_PREFERENCE_DEFAULTS.historyLimit,
    banner: saved.banner !== false,
    caretBlink: saved.caretBlink !== false,
    lineSpacing: LINE_SPACINGS.find((choice) => choice === saved.lineSpacing) ?? TERMINAL_PREFERENCE_DEFAULTS.lineSpacing,
    wrap: saved.wrap !== false,
  };
}

/** A store of the preferences, kept under `storageKey` when one is given and otherwise for the session only. */
export function createTerminalPreferences(storageKey?: string, storage?: Pick<Storage, "getItem" | "setItem">): TerminalPreferences {
  const disk = storage ?? (typeof localStorage === "undefined" ? undefined : localStorage);
  let values: TerminalPreferenceValues = { ...TERMINAL_PREFERENCE_DEFAULTS };
  if (storageKey && disk) {
    try { values = parseTerminalPreferences(JSON.parse(disk.getItem(storageKey) ?? "null")); } catch { /* A damaged value gives the defaults. */ }
  }
  const listeners = new Set<() => void>();
  return {
    get: () => values,
    update(change) {
      values = parseTerminalPreferences({ ...values, ...change });
      if (storageKey && disk) {
        try { disk.setItem(storageKey, JSON.stringify(values)); } catch { /* Storage can be unavailable in private or embedded contexts. */ }
      }
      listeners.forEach((listener) => listener());
    },
    subscribe(listener) { listeners.add(listener); return () => { listeners.delete(listener); }; },
  };
}

const sentence = (text: string): string => `${text[0].toUpperCase()}${text.slice(1)}`;

/** The reply to a switch: the new state, or that it already was in it. */
const switched = (label: string, before: boolean, after: boolean): string =>
  before === after ? `${sentence(label)} is already ${after ? "on" : "off"}.` : `${sentence(label)} ${after ? "enabled" : "disabled"}.`;

/** The Terminal text size and setting it, which the application stores with its own settings. */
export interface TerminalFontSize {
  fontSize(): number;
  setFontSize(size: number): void;
}

/** The smallest and largest Terminal text sizes, in pixels. */
export const TERMINAL_FONT_SIZES = { min: 10, max: 24 } as const;

/** Every preference and its state, one per line, for `terminal` with no setting. */
function terminalSummary(preferences: TerminalPreferences, font?: TerminalFontSize): ConsoleResult {
  const now = preferences.get();
  return { lines: [
    ...(font ? [`The text size is ${font.fontSize()} px.`] : []),
    `The history keeps the last ${now.historyLimit} commands.`, `The banner is ${now.banner ? "on" : "off"}.`, `The caret is ${now.caretBlink ? "blinking" : "steady"}.`,
    `The line spacing is ${now.lineSpacing}.`, `Wrapping is ${now.wrap ? "on" : "off"}.`,
  ] };
}

/** `terminal font [size|bigger|smaller]`: show or set the text size, clamped to 10 to 24 px. */
function fontCommand(arg: string, font: TerminalFontSize): ConsoleResult | null {
  const size = font.fontSize();
  if (!arg) return { lines: [`The text size is ${size} px.`] };
  if (!/^(\d+|bigger|smaller)$/.test(arg)) return null;
  const wanted = arg === "bigger" ? size + 1 : arg === "smaller" ? size - 1 : Number(arg);
  const next = Math.min(TERMINAL_FONT_SIZES.max, Math.max(TERMINAL_FONT_SIZES.min, wanted));
  font.setFontSize(next);
  return { lines: [next === size ? `The text size is already ${size} px.` : `Text size set to ${next} px.`] };
}

/**
 * Run `history limit [number]` or `terminal font|banner|caret|spacing|wrap [choice]` against the preferences and, for
 * `font`, the text size. Returns null for any other line, or a form these verbs do not take, so the registry's own usage
 * message answers it.
 */
export function terminalPreferenceCommand(line: string, preferences: TerminalPreferences, font?: TerminalFontSize): ConsoleResult | null {
  let [verb, ...rest] = line.trim().split(/\s+/);
  // `terminal banner off` is `banner off`: the Terminal's own verbs sit under `terminal`, so that they cannot meet a command of an application.
  if (verb === "terminal") {
    if (!rest.length) return terminalSummary(preferences, font);
    [verb, ...rest] = rest;
    if (verb === "history") return null;
  } else if (verb !== "history") return null;
  const arg = rest.join(" ");
  const now = preferences.get();
  if (verb === "font") return font ? fontCommand(arg, font) : null;
  if (verb === "history") {
    const asked = /^limit(?:\s+(\d+))?$/.exec(arg);
    if (!asked) return null;
    if (!asked[1]) return { lines: [`The history keeps the last ${now.historyLimit} commands.`] };
    const limit = HISTORY_LIMITS.find((choice) => choice === Number(asked[1]));
    if (!limit) return { lines: [`The history limit takes ${HISTORY_LIMITS.join(", ").replace(/, (?=[^,]*$)/, " or ")}.`] };
    preferences.update({ historyLimit: limit });
    return { lines: [limit === now.historyLimit ? `The history already keeps the last ${limit} commands.` : `The history keeps the last ${limit} commands.`] };
  }
  if (verb === "banner") {
    if (!arg) return { lines: [`The banner is ${now.banner ? "on" : "off"}.`] };
    if (arg !== "on" && arg !== "off") return null;
    preferences.update({ banner: arg === "on" });
    return { lines: [switched("banner", now.banner, arg === "on")] };
  }
  if (verb === "caret") {
    if (!arg) return { lines: [`The caret is ${now.caretBlink ? "blinking" : "steady"}.`] };
    if (arg !== "blink" && arg !== "steady") return null;
    preferences.update({ caretBlink: arg === "blink" });
    return { lines: [now.caretBlink === (arg === "blink") ? `The caret is already ${arg === "blink" ? "blinking" : "steady"}.` : `The caret ${arg === "blink" ? "blinks" : "stays steady"}.`] };
  }
  if (verb === "spacing") {
    if (!arg) return { lines: [`The line spacing is ${now.lineSpacing}.`] };
    const choice = LINE_SPACINGS.find((item) => item === arg);
    if (!choice) return null;
    preferences.update({ lineSpacing: choice });
    return { lines: [choice === now.lineSpacing ? `The line spacing is already ${choice}.` : `The line spacing is ${choice}.`] };
  }
  if (verb === "wrap") {
    if (!arg) return { lines: [`Wrapping is ${now.wrap ? "on" : "off"}.`] };
    if (arg !== "on" && arg !== "off") return null;
    preferences.update({ wrap: arg === "on" });
    return { lines: [switched("wrapping", now.wrap, arg === "on")] };
  }
  return null;
}
