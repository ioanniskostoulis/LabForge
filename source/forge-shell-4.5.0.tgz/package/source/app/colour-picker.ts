// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The colour picker: a hue ring around a triangle whose corners are the hue, white and black. A point in the
// triangle sets saturation and brightness. An optional target dot with a tolerance ring, and sample dots with a shaded
// area around them, are drawn over it. Below it the colour is shown, and can be typed, as hex, RGB, HSB and CIELAB.
import { COLOUR_MODELS, COLOUR_MODEL_LABELS, COLOUR_MODEL_TIPS, formatColour, hexToRgb, hsbToRgb, keepHue, parseColour, rgbToHex, rgbToHsb, rgbToLab,
  type ColourModel, type Hsb, type Lab, type Rgb } from "./colour-models";
import type { Point } from "./content-selection";
import { editableValue } from "./inspector-widgets";
import { followPointer } from "./pointer-drag";
import { setTip } from "./tips";

// MARK: given values

/** Side of the square picker, in px: the inspector's 222 px content width, less 1 px each side. */
export const PICKER_SIZE_PX = 220;
/** Width of the hue ring, in px. */
export const RING_WIDTH_PX = 18;
/** Gap between the ring and the triangle's corners, in px. */
export const TRIANGLE_GAP_PX = 5;
/** Radius of the mark of the chosen colour, in px. */
export const MARK_RADIUS_PX = 5;
/** Radius of a target or sample dot, in px. */
export const DOT_RADIUS_PX = 3;
/** The shaded area reaches at least this far around the samples, in px. */
export const SAMPLE_AREA_MIN_PX = 6;
/** Saturation or brightness moved by an arrow key (1 %). */
export const KEY_STEP = 0.01;
/** Hue moved by Page Up or Page Down, in degrees. */
export const HUE_KEY_STEP_DEG = 5;
/** The mark colours, read from the picker's element (`shell.css`, `.colour-picker`). */
export const PICKER_TOKENS = { mark: "--picker-mark", edge: "--picker-mark-edge", area: "--accent" } as const;

// MARK: geometry

export interface PickerGeometry {
  /** Centre of the picker, in px. */
  cx: number;
  cy: number;
  /** Outer and inner radius of the ring, in px. */
  outer: number;
  inner: number;
  /** Radius of the circle through the triangle's corners, in px. */
  corner: number;
}

/** The ring and the triangle of a picker `size` px square. */
export function pickerGeometry(size: number): PickerGeometry {
  const outer = size / 2 - 1, inner = outer - RING_WIDTH_PX;
  return { cx: size / 2, cy: size / 2, outer, inner, corner: inner - TRIANGLE_GAP_PX };
}

/** Length of a side of the triangle: √3 times the corner radius. */
export const triangleSide = (g: PickerGeometry): number => Math.sqrt(3) * g.corner;

/** A point at `deg` degrees (counter-clockwise from the right, as on a colour wheel) and `r` px from the centre. */
const polar = (g: PickerGeometry, deg: number, r: number): Point => {
  const a = (deg * Math.PI) / 180;
  return { x: g.cx + r * Math.cos(a), y: g.cy - r * Math.sin(a) };
};

/** The triangle's corners for a hue: the hue corner points at the hue on the ring, white and black follow at 120° and 240°. */
export function triangleCorners(hue: number, g: PickerGeometry): [hueCorner: Point, white: Point, black: Point] {
  return [polar(g, hue, g.corner), polar(g, hue + 120, g.corner), polar(g, hue + 240, g.corner)];
}

/** The hue of a point on the ring: its angle about the centre, from 0 to below 360°. */
export function ringHue(p: Point, g: PickerGeometry): number {
  const deg = (Math.atan2(-(p.y - g.cy), p.x - g.cx) * 180) / Math.PI;
  return (deg + 360) % 360;
}

/** What a press at `p` takes: the ring (and anything outside it), the triangle (inside it), or nothing past the circle. */
export function pickerRegion(p: Point, g: PickerGeometry): "ring" | "triangle" | null {
  const d = Math.hypot(p.x - g.cx, p.y - g.cy);
  if (d > g.outer + 2) return null;
  return d >= g.inner - TRIANGLE_GAP_PX / 2 ? "ring" : "triangle";
}

/** Barycentric weights of `p` in the triangle a, b, c. */
export function barycentric(p: Point, a: Point, b: Point, c: Point): [number, number, number] {
  const det = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
  const wa = ((b.y - c.y) * (p.x - c.x) + (c.x - b.x) * (p.y - c.y)) / det;
  const wb = ((c.y - a.y) * (p.x - c.x) + (a.x - c.x) * (p.y - c.y)) / det;
  return [wa, wb, 1 - wa - wb];
}

/** The point of the segment a–b nearest to `p`. */
function nearestOnSegment(p: Point, a: Point, b: Point): Point {
  const dx = b.x - a.x, dy = b.y - a.y;
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy)));
  return { x: a.x + t * dx, y: a.y + t * dy };
}

/** The point of the triangle nearest to `p`: `p` itself inside, otherwise the nearest point of an edge. */
export function nearestInTriangle(p: Point, a: Point, b: Point, c: Point): Point {
  if (barycentric(p, a, b, c).every((w) => w >= 0)) return p;
  const candidates = [nearestOnSegment(p, a, b), nearestOnSegment(p, b, c), nearestOnSegment(p, c, a)];
  return candidates.reduce((best, q) => (Math.hypot(q.x - p.x, q.y - p.y) < Math.hypot(best.x - p.x, best.y - p.y) ? q : best));
}

/**
 * The point of a saturation and brightness in the triangle. The colour is the hue, white and black mixed by the
 * weights s·b, (1 − s)·b and 1 − b, and the point is the corners mixed by the same weights.
 */
export function trianglePoint({ h, s, b }: Hsb, g: PickerGeometry): Point {
  const [hc, white, black] = triangleCorners(h, g);
  const w = [s * b, (1 - s) * b, 1 - b];
  return { x: w[0] * hc.x + w[1] * white.x + w[2] * black.x, y: w[0] * hc.y + w[1] * white.y + w[2] * black.y };
}

/** The saturation and brightness of a point, taken at the nearest point of the triangle: b = w_hue + w_white, s = w_hue / b. */
export function triangleColour(p: Point, hue: number, g: PickerGeometry): { s: number; b: number } {
  const [hc, white, black] = triangleCorners(hue, g);
  const [wHue, wWhite] = barycentric(nearestInTriangle(p, hc, white, black), hc, white, black).map((w) => Math.max(0, w));
  const b = Math.min(1, wHue + wWhite);
  return { s: b > 0 ? Math.min(1, wHue / b) : 0, b };
}

/** The convex hull of points, counter-clockwise on screen, by the monotone chain. */
export function convexHull(points: readonly Point[]): Point[] {
  const sorted = [...points].sort((p, q) => p.x - q.x || p.y - q.y);
  if (sorted.length < 3) return sorted;
  const cross = (o: Point, a: Point, b: Point) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
  const half = (list: Point[]) => {
    const out: Point[] = [];
    for (const p of list) {
      while (out.length >= 2 && cross(out[out.length - 2], out[out.length - 1], p) <= 0) out.pop();
      out.push(p);
    }
    out.pop();
    return out;
  };
  return [...half(sorted), ...half([...sorted].reverse())];
}

// MARK: painting

/** RGBA pixels to paint, as an ImageData holds them. */
export interface Pixels { data: Uint8ClampedArray; width: number; height: number }

/**
 * Paint the ring and the triangle for a hue into `pixels`, `scale` device pixels per px. Each pixel takes the colour
 * of the nearest point of the ring or triangle, and its coverage (about one device pixel of edge) as alpha.
 */
export function paintPicker(pixels: Pixels, g: PickerGeometry, hue: number, scale: number): void {
  const [hc, white, black] = triangleCorners(hue, g);
  const { data, width, height } = pixels;
  const pure = hsbToRgb({ h: hue, s: 1, b: 1 });
  const put = (i: number, rgb: Rgb, alpha: number) => {
    data[i] = rgb.r; data[i + 1] = rgb.g; data[i + 2] = rgb.b; data[i + 3] = Math.round(255 * alpha);
  };
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = 4 * (y * width + x);
      data[i + 3] = 0;
      const p = { x: (x + 0.5) / scale, y: (y + 0.5) / scale };
      const d = Math.hypot(p.x - g.cx, p.y - g.cy);
      // the ring: covered between the inner and the outer circle, fading over one device pixel at each
      const ring = Math.min(d - g.inner, g.outer - d) * scale + 0.5;
      if (ring > 0) {
        put(i, hsbToRgb({ h: ringHue(p, g), s: 1, b: 1 }), Math.min(1, ring));
        continue;
      }
      if (d > g.corner + 1) continue;
      const q = nearestInTriangle(p, hc, white, black);
      const outside = Math.hypot(q.x - p.x, q.y - p.y) * scale;
      if (outside >= 1) continue;
      // the hue, white and black mixed by the point's weights; black adds nothing
      const [wHue, wWhite] = barycentric(q, hc, white, black).map((w) => Math.max(0, w));
      const v = (channel: number) => channel * wHue + 255 * wWhite;
      put(i, { r: v(pure.r), g: v(pure.g), b: v(pure.b) }, 1 - outside);
    }
  }
}

// MARK: the picker

/** A chosen colour in every model. */
export interface PickedColour { hex: string; rgb: Rgb; hsb: Hsb; lab: Lab }

/** A colour from HSB in every model; RGB and CIELAB are of the rounded hex colour, so that they read back the same. */
export function pickedColour(hsb: Hsb): PickedColour {
  const hex = rgbToHex(hsbToRgb(hsb));
  const rgb = hexToRgb(hex)!;
  return { hex, rgb, hsb: { ...hsb }, lab: rgbToLab(rgb) };
}

/** A colour given as hex or HSB, as HSB; an unreadable hex is black. */
const toHsb = (value: string | Hsb, keep?: Hsb): Hsb => (typeof value === "string" ? keepHue(rgbToHsb(hexToRgb(value) ?? { r: 0, g: 0, b: 0 }), keep) : { ...value });

export interface ColourPickerOptions {
  /** The colour shown first, as hex or HSB. */
  value: string | Hsb;
  /** Each change, during a drag too. */
  onChange?: (colour: PickedColour) => void;
  /** The end of a change: a drag released, a key, a typed value. One call is one undo step. */
  onCommit?: (colour: PickedColour) => void;
  /** A target colour, drawn as a dot with the tolerance ring around it. */
  target?: string | null;
  /** The radius of the tolerance ring and of the area around the samples, as a share of the triangle's side (0–1). */
  tolerance?: number;
  /** Sample colours, drawn as dots with a shaded area around them. */
  samples?: readonly string[];
  /** The models shown below the picker, in this order (default all of `COLOUR_MODELS`). */
  models?: readonly ColourModel[];
  /** The picker's name for assistive technology (default `Colour`). */
  label?: string;
  size?: number;
  document?: Document;
}

/** A colour picker: the ring and triangle, a swatch of the chosen (and target) colour, and a typed row per model. */
export function createColourPicker(options: ColourPickerOptions) {
  const doc = options.document ?? document;
  const size = options.size ?? PICKER_SIZE_PX;
  const models = options.models ?? COLOUR_MODELS;
  const g = pickerGeometry(size);
  let hsb = toHsb(options.value);
  let target = options.target ?? null;
  let tolerance = options.tolerance ?? 0;
  let samples = [...(options.samples ?? [])];

  const make = <K extends keyof HTMLElementTagNameMap>(tag: K, cls: string, text?: string) => {
    const e = doc.createElement(tag);
    e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };
  const element = make("div", "colour-picker");
  const canvas = make("canvas", "colour-wheel");
  canvas.tabIndex = 0;
  canvas.setAttribute("role", "group");
  canvas.setAttribute("aria-roledescription", "colour picker");
  canvas.setAttribute("aria-label", options.label ?? "Colour");
  setTip(canvas, "Set the hue on the ring, and the saturation and brightness in the triangle.");
  canvas.style.width = `${size}px`;
  canvas.style.height = `${size}px`;
  const swatches = make("div", "colour-swatches");
  const chosenSwatch = make("span", "colour-swatch chosen"), targetSwatch = make("span", "colour-swatch target");
  setTip(chosenSwatch, "The chosen colour.");
  setTip(targetSwatch, "The target colour.");
  swatches.append(chosenSwatch, targetSwatch);
  const rows = models.map((model) => {
    const row = make("div", "row");
    const value = make("span", "value");
    row.append(make("span", "label", COLOUR_MODEL_LABELS[model]), value);
    editableValue(value, () => formatColour(model, hsb), (text) => {
      const next = parseColour(model, text, hsb);
      if (!next) return false;
      hsb = next;
      update("commit");
      return true;
    }, COLOUR_MODEL_TIPS[model]);
    return { model, value, row };
  });
  element.append(canvas, swatches, ...rows.map((r) => r.row));

  // painting: the ring and triangle are painted once per hue and size, the marks on every change
  const base = doc.createElement("canvas");
  let paintedHue = NaN, paintedScale = NaN;
  // The bitmap has exactly one pixel per screen pixel, so the browser never stretches it: the device-pixel width the
  // layout reports (which follows page zoom and the display), or the size times devicePixelRatio before the first report.
  let devicePx = Math.round(size * (globalThis.devicePixelRatio || 1));
  const draw = () => {
    if (canvas.width !== devicePx) canvas.width = base.width = canvas.height = base.height = devicePx;
    const scale = devicePx / size;
    const ctx = canvas.getContext("2d"), baseCtx = base.getContext("2d");
    if (!ctx || !baseCtx) return;
    if (hsb.h !== paintedHue || scale !== paintedScale) {
      const image = baseCtx.createImageData(base.width, base.height);
      paintPicker(image, g, hsb.h, scale);
      baseCtx.putImageData(image, 0, 0);
      paintedHue = hsb.h;
      paintedScale = scale;
    }
    const style = getComputedStyle(element);
    const token = (name: string) => style.getPropertyValue(name).trim();
    const [mark, edge, area] = [token(PICKER_TOKENS.mark), token(PICKER_TOKENS.edge), token(PICKER_TOKENS.area)];
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(base, 0, 0);
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    const ring = (p: Point, r: number) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, 2 * Math.PI);
      ctx.lineWidth = 3; ctx.strokeStyle = edge; ctx.stroke();
      ctx.lineWidth = 1.5; ctx.strokeStyle = mark; ctx.stroke();
    };
    const dot = (p: Point, hex: string) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, DOT_RADIUS_PX, 0, 2 * Math.PI);
      ctx.fillStyle = hex; ctx.fill();
      ctx.lineWidth = 1; ctx.strokeStyle = mark; ctx.stroke();
    };
    const reach = Math.max(SAMPLE_AREA_MIN_PX, tolerance * triangleSide(g));
    // samples: the area within the tolerance of their hull, then a dot for each
    const samplePoints = samples.map((hex) => ({ hex, p: trianglePoint(toHsb(hex, hsb), g) }));
    if (samplePoints.length) {
      const hull = convexHull(samplePoints.map((s) => s.p));
      ctx.save();
      ctx.globalAlpha = 0.25;
      ctx.fillStyle = ctx.strokeStyle = area;
      ctx.lineJoin = ctx.lineCap = "round";
      ctx.lineWidth = 2 * reach;
      ctx.beginPath();
      if (hull.length === 1) {
        ctx.arc(hull[0].x, hull[0].y, reach, 0, 2 * Math.PI);
        ctx.fill();
      } else {
        hull.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
      for (const s of samplePoints) dot(s.p, s.hex);
    }
    // the target: a dot, the tolerance ring around it, and a tick at its hue on the ring
    if (target) {
      const t = toHsb(target, hsb);
      const p = trianglePoint(t, g);
      if (tolerance > 0) {
        ctx.save();
        ctx.setLineDash([3, 2]);
        ring(p, tolerance * triangleSide(g));
        ctx.restore();
      }
      dot(p, target);
      const [a, b] = [polar(g, t.h, g.inner), polar(g, t.h, g.inner + RING_WIDTH_PX / 3)];
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
      ctx.lineWidth = 3; ctx.strokeStyle = edge; ctx.stroke();
      ctx.lineWidth = 1.5; ctx.strokeStyle = mark; ctx.stroke();
    }
    // the chosen colour: a bar across the ring at its hue, and a ring in the triangle
    const [a, b] = [polar(g, hsb.h, g.inner - 1), polar(g, hsb.h, g.outer + 1)];
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
    ctx.lineWidth = 4; ctx.strokeStyle = edge; ctx.stroke();
    ctx.lineWidth = 2; ctx.strokeStyle = mark; ctx.stroke();
    ring(trianglePoint(hsb, g), MARK_RADIUS_PX);
  };

  /** Show the colour; `change` also calls `onChange`, `commit` both `onChange` and `onCommit`. */
  const update = (notify: "none" | "change" | "commit") => {
    const picked = pickedColour(hsb);
    chosenSwatch.style.setProperty("--swatch", picked.hex);
    targetSwatch.hidden = !target;
    if (target) targetSwatch.style.setProperty("--swatch", target);
    for (const r of rows) r.value.textContent = formatColour(r.model, hsb);
    canvas.setAttribute("aria-valuetext", formatColour("hsb", hsb));
    draw();
    if (notify !== "none") options.onChange?.(picked);
    if (notify === "commit") options.onCommit?.(picked);
  };

  const pointAt = (e: PointerEvent): Point => {
    const r = canvas.getBoundingClientRect();
    return { x: ((e.clientX - r.left) * size) / Math.max(1, r.width), y: ((e.clientY - r.top) * size) / Math.max(1, r.height) };
  };
  canvas.addEventListener("pointerdown", (e) => {
    const region = pickerRegion(pointAt(e), g);
    if (!region || e.button !== 0) return;
    e.preventDefault();
    canvas.focus();
    const before = formatColour("hex", hsb) + hsb.h;
    // A drag on the ring repaints the triangle for every hue, so pointer moves are shown once per frame.
    let latest: PointerEvent | null = null, frame = 0;
    const show = () => {
      frame = 0;
      if (!latest) return;
      const p = pointAt(latest);
      latest = null;
      hsb = region === "ring" ? { ...hsb, h: ringHue(p, g) } : { h: hsb.h, ...triangleColour(p, hsb.h, g) };
      update("change");
    };
    const move = (ev: PointerEvent) => {
      latest = ev;
      if (!frame) frame = requestAnimationFrame(show);
    };
    followPointer(canvas, e, {
      move,
      end: () => {
        cancelAnimationFrame(frame);
        show();
        if (formatColour("hex", hsb) + hsb.h !== before) options.onCommit?.(pickedColour(hsb));
      },
    });
    latest = e;
    show();
  });
  canvas.addEventListener("keydown", (e) => {
    const next = pickerKey(hsb, e.key);
    if (!next) return;
    e.preventDefault();
    e.stopPropagation();
    hsb = next;
    update("commit");
  });

  update("none");
  requestAnimationFrame(draw);
  // redraw when the screen pixels under the picker change: page zoom, another display, a scaled panel
  new ResizeObserver(([entry]) => {
    const reported = entry.devicePixelContentBoxSize?.[0]?.inlineSize ?? Math.round(entry.contentRect.width * (globalThis.devicePixelRatio || 1));
    if (reported > 0 && reported !== devicePx) {
      devicePx = reported;
      draw();
    }
  }).observe(canvas, { box: "device-pixel-content-box" });
  return {
    element,
    get value(): PickedColour { return pickedColour(hsb); },
    /** Show a colour without calling `onChange` or `onCommit`. */
    set(value: string | Hsb): void {
      hsb = toHsb(value, hsb);
      update("none");
    },
    setTarget(hex: string | null): void { target = hex; draw(); targetSwatch.hidden = !hex; if (hex) targetSwatch.style.setProperty("--swatch", hex); },
    setTolerance(share: number): void { tolerance = Math.max(0, share); draw(); },
    setSamples(list: readonly string[]): void { samples = [...list]; draw(); },
  };
}

/** The colour after a key: Left and Right change saturation, Up and Down brightness (1 % each), Page Up and Page Down the hue (5°). */
export function pickerKey(hsb: Hsb, key: string): Hsb | null {
  const clamp01 = (v: number) => Math.max(0, Math.min(1, Math.round(v * 100) / 100));
  switch (key) {
    case "ArrowRight": return { ...hsb, s: clamp01(hsb.s + KEY_STEP) };
    case "ArrowLeft": return { ...hsb, s: clamp01(hsb.s - KEY_STEP) };
    case "ArrowUp": return { ...hsb, b: clamp01(hsb.b + KEY_STEP) };
    case "ArrowDown": return { ...hsb, b: clamp01(hsb.b - KEY_STEP) };
    case "PageUp": return { ...hsb, h: (hsb.h + HUE_KEY_STEP_DEG) % 360 };
    case "PageDown": return { ...hsb, h: (hsb.h - HUE_KEY_STEP_DEG + 360) % 360 };
    default: return null;
  }
}
