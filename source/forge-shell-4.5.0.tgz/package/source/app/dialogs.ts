// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { dialogActions, type DialogButton } from "./layout-order";

export type SaveChoice = "save" | "discard" | "cancel";

/** Save, Don't save and Cancel, placed in the platform's order by `dialogActions`. */
const SAVE_BUTTONS: DialogButton[] = [
  { label: "Save", role: "primary", className: "save" },
  { label: "Don't save", role: "destructive", className: "discard" },
  { label: "Cancel", role: "cancel", className: "cancel" },
];

/**
 * Ask whether to save a document before its tab closes, like a Mac document window:
 * Save (Return), Don't save (⌘D) or Cancel (Escape).
 */
export function askToSave(name: string): Promise<SaveChoice> {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="save-prompt" role="alertdialog" aria-labelledby="save-prompt-title">
        <div class="title" id="save-prompt-title"></div>
        <div class="detail">Your changes will be lost if you don't save them.</div>
      </div>`;
    backdrop.querySelector(".save-prompt")!.append(dialogActions(SAVE_BUTTONS));
    backdrop.querySelector(".title")!.textContent = `Do you want to save the changes to “${name}”?`;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const done = (choice: SaveChoice) => {
      document.removeEventListener("keydown", keys, true);
      backdrop.remove();
      previousFocus?.focus();
      resolve(choice);
    };
    const keys = (e: KeyboardEvent) => {
      e.stopPropagation();
      if (e.key === "Escape") done("cancel");
      // Enter on a focused button presses that button; anywhere else it chooses Save.
      else if (e.key === "Enter" && !(e.target instanceof HTMLButtonElement)) done("save");
      else if (e.key.toLowerCase() === "d" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        done("discard");
      }
    };
    backdrop.querySelector(".save")!.addEventListener("click", () => done("save"));
    backdrop.querySelector(".discard")!.addEventListener("click", () => done("discard"));
    backdrop.querySelector(".cancel")!.addEventListener("click", () => done("cancel"));
    document.addEventListener("keydown", keys, true);
    document.getElementById("overlay-root")!.append(backdrop);
    (backdrop.querySelector(".save") as HTMLButtonElement).focus();
  });
}

export interface UnsavedChoice { choice: SaveChoice; save: number[] }

/**
 * Closing the window (or quitting) with unsaved documents: list them, all ticked, each with where it
 * saves (its own file, overwritten, or a new file). Save (Return) saves the ticked ones and closes,
 * Don't save (⌘D) closes without saving, Cancel (Escape) keeps the window.
 */
export function askToSaveAll(documents: { name: string; path: string | null }[], pluralNoun: string): Promise<UnsavedChoice> {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="save-prompt unsaved" role="alertdialog" aria-labelledby="unsaved-title">
        <div class="title" id="unsaved-title"></div>
        <div class="detail">Choose which to save. The rest of the changes will be lost.</div>
        <div class="unsaved-list"></div>
      </div>`;
    backdrop.querySelector(".save-prompt")!.append(dialogActions(SAVE_BUTTONS));
    const n = documents.length;
    backdrop.querySelector(".title")!.textContent = n === 1 ? `Save the changes to “${documents[0].name}” before closing?` : `${n} ${pluralNoun} have unsaved changes. Save them before closing?`;
    const list = backdrop.querySelector(".unsaved-list")!;
    const boxes = documents.map((c) => {
      const row = document.createElement("label");
      row.className = "unsaved-row";
      const box = Object.assign(document.createElement("input"), { type: "checkbox", checked: true });
      const name = Object.assign(document.createElement("span"), { className: "name", textContent: c.name });
      const where = Object.assign(document.createElement("span"), { className: "where" });
      where.textContent = c.path ? `overwrites ${c.path.split(/[\\/]/).slice(-2).join("/")}` : "new file: you choose where";
      where.title = c.path ?? "";
      row.append(box, name, where);
      list.append(row);
      return box;
    });
    const save = backdrop.querySelector<HTMLButtonElement>(".save")!;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const refresh = () => {
      const k = boxes.filter((b) => b.checked).length;
      save.textContent = k === n ? (n === 1 ? "Save" : "Save all") : `Save ${k}`;
      save.disabled = k === 0;
    };
    boxes.forEach((b) => b.addEventListener("change", refresh));
    refresh();
    const done = (choice: SaveChoice) => {
      document.removeEventListener("keydown", keys, true);
      backdrop.remove();
      previousFocus?.focus();
      resolve({ choice, save: boxes.flatMap((b, i) => (b.checked ? [i] : [])) });
    };
    const keys = (e: KeyboardEvent) => {
      e.stopPropagation();
      if (e.key === "Escape") done("cancel");
      else if (e.key === "Enter" && !(e.target instanceof HTMLButtonElement) && !save.disabled) done("save");
      else if (e.key.toLowerCase() === "d" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        done("discard");
      }
    };
    save.addEventListener("click", () => done("save"));
    backdrop.querySelector(".discard")!.addEventListener("click", () => done("discard"));
    backdrop.querySelector(".cancel")!.addEventListener("click", () => done("cancel"));
    document.addEventListener("keydown", keys, true);
    document.getElementById("overlay-root")!.append(backdrop);
    save.focus();
  });
}

/** One proposed change: what it is, its current value and the proposed one. */
export type ProposedChange = [label: string, current: string, proposed: string];

/**
 * Show proposed changes before applying them: what was found, a table of the changes (unchanged rows dimmed) and
 * Apply (Return) or Cancel (Escape). Resolves true to apply.
 */
export function askToApply(title: string, findings: readonly string[], changes: readonly ProposedChange[], columns: readonly [string, string, string] = ["Setting", "Current", "Proposed"]): Promise<boolean> {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="save-prompt review" role="dialog" aria-labelledby="review-title">
        <div class="title" id="review-title"></div>
        <ul class="findings"></ul>
        <table class="changes"><thead><tr></tr></thead><tbody></tbody></table>
      </div>`;
    const prompt = backdrop.querySelector(".save-prompt")!;
    prompt.append(dialogActions([{ label: "Apply", role: "primary", className: "apply" }, { label: "Cancel", role: "cancel", className: "cancel" }]));
    backdrop.querySelector(".title")!.textContent = title;
    const list = backdrop.querySelector(".findings")!;
    for (const finding of findings) list.append(Object.assign(document.createElement("li"), { textContent: finding }));
    if (!findings.length) list.remove();
    for (const label of columns) backdrop.querySelector("thead tr")!.append(Object.assign(document.createElement("th"), { scope: "col", textContent: label }));
    const body = backdrop.querySelector("tbody")!;
    for (const [label, current, proposed] of changes) {
      const row = document.createElement("tr");
      for (const [className, text] of [["label", label], ["from", current], ["to", proposed]]) row.append(Object.assign(document.createElement("td"), { className, textContent: text }));
      if (current === proposed) row.classList.add("same");
      body.append(row);
    }
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const done = (ok: boolean) => {
      document.removeEventListener("keydown", keys, true);
      backdrop.remove();
      previousFocus?.focus();
      resolve(ok);
    };
    const keys = (event: KeyboardEvent) => {
      event.stopPropagation();
      if (event.key === "Escape") done(false);
      else if (event.key === "Enter" && !(event.target instanceof HTMLButtonElement)) done(true);
    };
    backdrop.querySelector(".apply")!.addEventListener("click", () => done(true));
    backdrop.querySelector(".cancel")!.addEventListener("click", () => done(false));
    document.addEventListener("keydown", keys, true);
    document.getElementById("overlay-root")!.append(backdrop);
    (backdrop.querySelector(".apply") as HTMLButtonElement).focus();
  });
}

/** A row of a table picker: its id, the text of each column, and whether it can be picked. */
export interface PickRow { id: string; cells: readonly string[]; disabled?: boolean }

/** The rows whose cells contain every word of the query, ignoring case; an empty query keeps them all. */
export function filterRows<T extends PickRow>(rows: readonly T[], query: string): T[] {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  return rows.filter((row) => { const text = row.cells.join(" ").toLowerCase(); return words.every((word) => text.includes(word)); });
}

export interface PickOptions {
  title: string;
  columns: readonly string[];
  rows: readonly PickRow[];
  /** Several rows may be ticked; one row is picked otherwise. */
  multiple?: boolean;
  /** The label of the primary button, such as `Add` or `Use`. */
  action: string;
  placeholder?: string;
  /** With `multiple`, the rows ticked to begin with. */
  ticked?: readonly string[];
}

/**
 * A searchable table to pick from: a search field that filters as it is typed, the table (Up and Down move, a click
 * or Return picks one row, or ticks with `multiple`), and the action (Return) and Cancel (Escape). Resolves the ids
 * picked, or null when cancelled.
 */
export function askToPick(options: PickOptions): Promise<string[] | null> {
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="save-prompt picker" role="dialog" aria-labelledby="picker-title">
        <div class="title" id="picker-title"></div>
        <input class="picker-search" type="search" autocomplete="off" spellcheck="false">
        <div class="picker-body"><table class="picker-table"><thead><tr></tr></thead><tbody></tbody></table><div class="picker-empty" hidden>No matches.</div></div>
      </div>`;
    const prompt = backdrop.querySelector(".save-prompt")!;
    prompt.append(dialogActions([{ label: options.action, role: "primary", className: "pick" }, { label: "Cancel", role: "cancel", className: "cancel" }]));
    backdrop.querySelector(".title")!.textContent = options.title;
    const search = backdrop.querySelector<HTMLInputElement>(".picker-search")!;
    search.placeholder = options.placeholder ?? "Search";
    search.setAttribute("aria-label", options.placeholder ?? "Search");
    const head = backdrop.querySelector("thead tr")!;
    if (options.multiple) head.append(document.createElement("th"));
    for (const column of options.columns) head.append(Object.assign(document.createElement("th"), { scope: "col", textContent: column }));
    const body = backdrop.querySelector("tbody")!;
    const empty = backdrop.querySelector<HTMLElement>(".picker-empty")!;
    const ticked = new Set<string>(options.ticked ?? []);
    let shown: PickRow[] = [], active = 0;
    const pickButton = backdrop.querySelector<HTMLButtonElement>(".pick")!;
    const refresh = () => {
      shown = filterRows(options.rows, search.value);
      active = Math.min(active, Math.max(0, shown.length - 1));
      body.replaceChildren(...shown.map((row, index) => {
        const tr = document.createElement("tr");
        tr.classList.toggle("active", index === active);
        tr.classList.toggle("disabled", !!row.disabled);
        if (options.multiple) {
          const box = Object.assign(document.createElement("input"), { type: "checkbox", checked: ticked.has(row.id), disabled: !!row.disabled });
          box.setAttribute("aria-label", row.cells[0] ?? row.id);
          box.addEventListener("change", () => { if (box.checked) ticked.add(row.id); else ticked.delete(row.id); refresh(); });
          tr.append(Object.assign(document.createElement("td"), { className: "check" }));
          tr.firstChild!.appendChild(box);
        }
        for (const cell of row.cells) tr.append(Object.assign(document.createElement("td"), { textContent: cell }));
        tr.addEventListener("click", (event) => {
          if (row.disabled || (event.target as HTMLElement).closest("input")) return;
          active = index;
          if (options.multiple) { if (!ticked.delete(row.id)) ticked.add(row.id); refresh(); } else done([row.id]);
        });
        return tr;
      }));
      empty.hidden = shown.length > 0;
      pickButton.disabled = options.multiple ? ticked.size === 0 : !shown.some((row) => !row.disabled);
    };
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const done = (ids: string[] | null) => {
      document.removeEventListener("keydown", keys, true);
      backdrop.remove();
      previousFocus?.focus();
      resolve(ids);
    };
    const pick = () => {
      // With nothing ticked, Return picks the highlighted row, as a single pick does.
      if (options.multiple && ticked.size) done([...ticked]);
      else if (shown[active] && !shown[active].disabled) done([shown[active].id]);
    };
    const keys = (event: KeyboardEvent) => {
      event.stopPropagation();
      if (event.key === "Escape") { event.preventDefault(); done(null); }
      else if (event.key === "ArrowDown" || event.key === "ArrowUp") { event.preventDefault(); active = Math.max(0, Math.min(shown.length - 1, active + (event.key === "ArrowDown" ? 1 : -1))); refresh(); body.querySelector("tr.active")?.scrollIntoView({ block: "nearest" }); }
      else if (event.key === "Enter" && !(event.target instanceof HTMLButtonElement)) { event.preventDefault(); pick(); }
    };
    search.addEventListener("input", () => { active = 0; refresh(); });
    pickButton.addEventListener("click", pick);
    backdrop.querySelector(".cancel")!.addEventListener("click", () => done(null));
    document.addEventListener("keydown", keys, true);
    document.getElementById("overlay-root")!.append(backdrop);
    refresh();
    search.focus();
  });
}

/** One answer of a choice dialog. `role` places it (`dialogButtonOrder`); `key` is a Cmd or Ctrl shortcut letter, as ⌘D for Don't save. */
export interface ChoiceButton<Id extends string = string> { id: Id; label: string; role: DialogButton["role"]; key?: string }

export interface ChoiceOptions<Id extends string = string> {
  /** The question or the situation, one sentence: `3 files already exist.` */
  title: string;
  /** What each answer does, in sentences. */
  detail?: string;
  /** Two or more answers. Exactly one is `cancel`, which Escape chooses; at most one is `primary`, which Return chooses. */
  buttons: readonly ChoiceButton<Id>[];
  /** The answer that has the focus at first: the primary one when not given. */
  focus?: Id;
}

/** The answers' problems: none without a Cancel, two primaries, a repeated id or key. Empty when the buttons are valid. */
export function choiceProblems(buttons: readonly ChoiceButton[]): string[] {
  const problems: string[] = [];
  if (buttons.length < 2) problems.push("A choice needs at least two answers.");
  if (buttons.filter((button) => button.role === "cancel").length !== 1) problems.push("A choice has exactly one Cancel answer, which Escape chooses.");
  if (buttons.filter((button) => button.role === "primary").length > 1) problems.push("A choice has at most one primary answer, which Return chooses.");
  if (new Set(buttons.map((button) => button.id)).size !== buttons.length) problems.push("Each answer has its own id.");
  const keys = buttons.flatMap((button) => (button.key ? [button.key.toLowerCase()] : []));
  if (new Set(keys).size !== keys.length) problems.push("Each answer has its own shortcut.");
  return problems;
}

/**
 * Ask a question with two or more answers, as Finder's Replace, Keep both or Cancel: the title, the detail, and the
 * answers in the platform's order. Return chooses the primary answer (a focused button presses itself), Escape
 * chooses Cancel, and Cmd or Ctrl with an answer's `key` chooses it. Resolves the id of the answer. It is drawn in the
 * page, so it works the same in the desktop application and its browser preview; never a native message box.
 */
export function askToChoose<Id extends string>(options: ChoiceOptions<Id>): Promise<Id> {
  const problems = choiceProblems(options.buttons);
  if (problems.length) return Promise.reject(new Error(problems.join(" ")));
  return new Promise((resolve) => {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="save-prompt choice" role="alertdialog" aria-labelledby="choice-title" aria-describedby="choice-detail">
        <div class="title" id="choice-title"></div>
        <div class="detail" id="choice-detail"></div>
      </div>`;
    backdrop.querySelector(".title")!.textContent = options.title;
    const detail = backdrop.querySelector<HTMLElement>(".detail")!;
    if (options.detail) detail.textContent = options.detail; else detail.remove();
    const classOf = (index: number) => `choice-${index}`;
    backdrop.querySelector(".save-prompt")!.append(dialogActions(options.buttons.map((button, index) => ({ label: button.label, role: button.role, className: classOf(index) }))));
    const cancel = options.buttons.find((button) => button.role === "cancel")!;
    const primary = options.buttons.find((button) => button.role === "primary");
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const done = (id: Id) => {
      document.removeEventListener("keydown", keys, true);
      backdrop.remove();
      previousFocus?.focus();
      resolve(id);
    };
    const keys = (event: KeyboardEvent) => {
      event.stopPropagation();
      if (event.key === "Escape") { event.preventDefault(); done(cancel.id); return; }
      // Return on a focused button presses that button; anywhere else it chooses the primary answer.
      if (event.key === "Enter" && primary && !(event.target instanceof HTMLButtonElement)) { event.preventDefault(); done(primary.id); return; }
      const keyed = (event.metaKey || event.ctrlKey) && options.buttons.find((button) => button.key?.toLowerCase() === event.key.toLowerCase());
      if (keyed) { event.preventDefault(); done(keyed.id); }
    };
    options.buttons.forEach((button, index) => backdrop.querySelector(`.${classOf(index)}`)!.addEventListener("click", () => done(button.id)));
    document.addEventListener("keydown", keys, true);
    document.getElementById("overlay-root")!.append(backdrop);
    const focusIndex = options.buttons.findIndex((button) => button.id === (options.focus ?? primary?.id ?? cancel.id));
    backdrop.querySelector<HTMLButtonElement>(`.${classOf(Math.max(0, focusIndex))}`)!.focus();
  });
}
