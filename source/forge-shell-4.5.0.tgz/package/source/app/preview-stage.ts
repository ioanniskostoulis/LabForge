// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The preview of a generator pane: an image, a table or an element the application draws, panned and zoomed as
// a zoomable preview. Two-finger scroll or a drag moves it; a pinch, Cmd-scroll or the
// mouse wheel zooms at the pointer (`wheelIntent`); a double click or Space fits it again. A plot or an image fits whole
// ("contain"); a table fits its width and scrolls down ("width"). The content is laid out once at its own size inside
// one transformed layer, so zooming never lays it out again. It cannot be moved away from what it shows (`keepInView`).
import { followPointer } from "./pointer-drag";
import { wheelIntent } from "./wheel";

/** What a preview shows. `src` is any image URL: a file URL, a data URL or an object URL of a Blob. */
export type PreviewContent =
  | { kind: "image"; src: string; alt?: string }
  | { kind: "table"; headers: string[]; rows: string[][] }
  | { kind: "element"; element: HTMLElement; width: number; height: number };

/** Content pixels to stage pixels: pixel = content × scale + origin. Fit follows the stage's size until the view is zoomed or moved. */
export type PreviewView = { scale: number; ox: number; oy: number; fitting: boolean };
/** "contain" shows the whole content (a plot, an image); "width" fits the width and scrolls down (a table). */
export type PreviewFit = "contain" | "width";

export const PREVIEW_SCALE = { min: 0.05, max: 12 } as const;
/** Space kept around fitted content. */
export const PREVIEW_MARGIN = 16;
/** The largest scale a fit uses: a table at its own text size, a plot or an image at most twice its own size. */
export const PREVIEW_MAX_FIT: Record<PreviewFit, number> = { width: 1, contain: 2 };
/** A key press zooms by this much about the middle of the stage. */
const KEY_ZOOM = 1.2;

const clamp = (value: number, low: number, high: number) => Math.min(high, Math.max(low, value));
type Size = { width: number; height: number };

/** Up and down limits of a width fit: the content's top no lower than the margin, its end no higher than the bottom margin. */
export function clampTop(oy: number, scale: number, content: Size, stage: Size): number {
  const tall = content.height * scale;
  return clamp(oy, Math.min(PREVIEW_MARGIN, stage.height - tall - PREVIEW_MARGIN), PREVIEW_MARGIN);
}

/**
 * The fitted view of `content` in `stage`. "contain" centres it whole; "width" fills the width and keeps the line at
 * the top of `previous` at the top (or starts at the top with `top`). Neither magnifies past `maxFit`: a table no larger
 * than its text size, a plot or image at most twice its own, so a small one is not blown up.
 */
export function fitPreview(content: Size, stage: Size, mode: PreviewFit, previous?: PreviewView, top = false, maxFit = PREVIEW_MAX_FIT[mode]): PreviewView {
  if (content.width <= 0 || content.height <= 0 || stage.width <= 0 || stage.height <= 0) return { scale: 1, ox: 0, oy: 0, fitting: true };
  const across = (stage.width - 2 * PREVIEW_MARGIN) / content.width;
  const scale = clamp(Math.min(mode === "contain" ? Math.min(across, (stage.height - 2 * PREVIEW_MARGIN) / content.height) : across, maxFit), PREVIEW_SCALE.min, PREVIEW_SCALE.max);
  const oy = mode === "contain" ? (stage.height - content.height * scale) / 2
    : clampTop(top || !previous ? PREVIEW_MARGIN : PREVIEW_MARGIN - ((PREVIEW_MARGIN - previous.oy) / previous.scale) * scale, scale, content, stage);
  return { scale, ox: (stage.width - content.width * scale) / 2, oy, fitting: true };
}

/** One axis kept within reach: content no wider than the stage stays inside it, wider content always covers it, with the margin. */
function keepAxis(origin: number, length: number, stage: number): number {
  const low = stage - PREVIEW_MARGIN - length, high = PREVIEW_MARGIN;
  return length <= stage - 2 * PREVIEW_MARGIN ? clamp(origin, high, low) : clamp(origin, low, high);
}

/**
 * `view` moved back within reach of `content`: a preview cannot be dragged or zoomed away from what it shows. Content
 * smaller than the stage stays wholly inside it; larger content always fills it, and its edge stops at the margin.
 */
export function keepInView(view: PreviewView, content: Size, stage: Size): PreviewView {
  if (content.width <= 0 || content.height <= 0 || stage.width <= 0 || stage.height <= 0) return view;
  return { ...view, ox: keepAxis(view.ox, content.width * view.scale, stage.width), oy: keepAxis(view.oy, content.height * view.scale, stage.height) };
}

/** Zoom `view` by `factor` about (x, y) in stage pixels, within `PREVIEW_SCALE`; the view stops fitting. */
export function zoomPreview(view: PreviewView, factor: number, x: number, y: number): PreviewView {
  const scale = clamp(view.scale * factor, PREVIEW_SCALE.min, PREVIEW_SCALE.max);
  return { scale, ox: x - (x - view.ox) * (scale / view.scale), oy: y - (y - view.oy) * (scale / view.scale), fitting: false };
}

export interface PreviewStageOptions {
  mode(): PreviewFit;
  /** The view or the content changed: refresh readouts. */
  changed?(): void;
  /** An image could not be loaded. */
  failed?(error: unknown): void;
}

export class PreviewStage {
  view: PreviewView = { scale: 1, ox: 0, oy: 0, fitting: true };
  private readonly layer = Object.assign(document.createElement("div"), { className: "preview-layer" });
  private size: Size = { width: 0, height: 0 };
  private generation = 0;

  constructor(readonly stage: HTMLElement, private readonly options: PreviewStageOptions) {
    stage.classList.add("preview-stage");
    stage.tabIndex = 0;
    stage.append(this.layer);
    new ResizeObserver(() => { if (this.view.fitting) this.fit(); else this.place(); }).observe(stage);
    this.navigation();
  }

  get loaded(): boolean { return this.size.width > 0; }
  /** The zoom in per cent of the content's own size. */
  get percent(): number { return Math.round(this.view.scale * 100); }

  /** Show `content`; the view fits it unless it was zoomed or moved. Resolves once an image has loaded. */
  async show(content: PreviewContent): Promise<void> {
    const generation = ++this.generation;
    let node: HTMLElement, size: Size;
    if (content.kind === "image") {
      const image = Object.assign(document.createElement("img"), { className: "preview-image", alt: content.alt ?? "", draggable: false });
      image.src = content.src;
      try { await image.decode(); } catch (error) { if (generation === this.generation) this.options.failed?.(error); return; }
      node = image;
      size = { width: image.naturalWidth, height: image.naturalHeight };
    } else if (content.kind === "table") {
      node = previewTable(content.headers, content.rows);
      size = { width: 0, height: 0 };
    } else {
      node = content.element;
      size = { width: content.width, height: content.height };
    }
    if (generation !== this.generation) return;
    this.layer.replaceChildren(node);
    // A table is measured at its own size, laid out untransformed in the layer.
    if (content.kind === "table") size = { width: node.offsetWidth, height: node.offsetHeight };
    else { node.style.width = `${size.width}px`; node.style.height = `${size.height}px`; }
    const first = !this.loaded;
    this.size = size;
    if (first || this.view.fitting) this.fit(first); else this.place();
  }

  clear(): void {
    this.generation++;
    this.layer.replaceChildren();
    this.size = { width: 0, height: 0 };
    this.view = { scale: 1, ox: 0, oy: 0, fitting: true };
    this.place();
  }

  /** Fit the content again: whole, or to the width from the line at the top (from the top with `top`). */
  fit(top = false): void {
    const stage = { width: this.stage.clientWidth, height: this.stage.clientHeight };
    // Not laid out yet (the pane is hidden): the resize observer fits it once it has a size.
    if (!this.loaded || stage.width <= 0 || stage.height <= 0) { this.view.fitting = true; this.place(); return; }
    this.view = fitPreview(this.size, stage, this.options.mode(), this.view, top);
    this.place();
  }

  /** Zoom by `factor` about (x, y) in stage pixels, or about the middle. */
  zoom(factor: number, x = this.stage.clientWidth / 2, y = this.stage.clientHeight / 2): void {
    if (!this.loaded) return;
    this.view = keepInView(zoomPreview(this.view, factor, x, y), this.size, { width: this.stage.clientWidth, height: this.stage.clientHeight });
    this.place();
  }

  /** Move the content by (dx, dy) pixels. A width fit only moves up and down, and stays fitted. */
  private move(dx: number, dy: number): void {
    const stage = { width: this.stage.clientWidth, height: this.stage.clientHeight };
    if (this.view.fitting && this.options.mode() === "width") this.view.oy = clampTop(this.view.oy + dy, this.view.scale, this.size, stage);
    else this.view = keepInView({ ...this.view, ox: this.view.ox + dx, oy: this.view.oy + dy, fitting: false }, this.size, stage);
    this.place();
  }

  private navigation(): void {
    const stage = this.stage;
    stage.addEventListener("wheel", (event) => {
      if (!this.loaded) return;
      event.preventDefault();
      const intent = wheelIntent(event, false);
      const box = stage.getBoundingClientRect();
      if (intent.kind === "zoom") this.zoom(intent.factor, event.clientX - box.left, event.clientY - box.top);
      else this.move(-intent.dx, -intent.dy);
    }, { passive: false });
    stage.addEventListener("pointerdown", (event) => {
      if (!this.loaded) return;
      let x = event.clientX, y = event.clientY;
      const drag = (next: PointerEvent) => { this.move(next.clientX - x, next.clientY - y); x = next.clientX; y = next.clientY; };
      // the primary or the middle button pans
      if (!followPointer(stage, event, { move: drag, end: () => stage.classList.remove("panning") }, [0, 1])) return;
      event.preventDefault();
      stage.focus({ preventScroll: true });
      stage.classList.add("panning");
    });
    stage.addEventListener("auxclick", (event) => { if (event.button === 1) event.preventDefault(); });
    stage.addEventListener("dblclick", () => this.fit());
    stage.addEventListener("keydown", (event) => {
      if (!this.loaded || event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.key === " ") this.fit();
      else if (event.key === "+" || event.key === "=") this.zoom(KEY_ZOOM);
      else if (event.key === "-") this.zoom(1 / KEY_ZOOM);
      else return;
      event.preventDefault();
      // Space here fits the preview only, not the document behind the panel.
      event.stopPropagation();
    });
  }

  private place(): void {
    this.layer.style.transform = `translate(${this.view.ox}px, ${this.view.oy}px) scale(${this.view.scale})`;
    this.options.changed?.();
  }
}

/** A table preview: headers and rows, numbers right-aligned as in the Terminal's tables. */
export function previewTable(headers: readonly string[], rows: readonly (readonly string[])[]): HTMLTableElement {
  const table = Object.assign(document.createElement("table"), { className: "preview-table" });
  const numeric = (column: number) => rows.length > 0 && rows.every((row) => /^[+−-]?(?:\d|\.\d)/.test(row[column] ?? ""));
  if (headers.length) {
    const head = table.createTHead().insertRow();
    headers.forEach((title, column) => {
      const cell = document.createElement("th");
      cell.scope = "col";
      cell.textContent = title;
      cell.classList.toggle("numeric", numeric(column));
      head.append(cell);
    });
  }
  const body = table.createTBody();
  for (const row of rows) {
    const line = body.insertRow();
    row.forEach((value, column) => {
      const cell = line.insertCell();
      cell.textContent = value;
      cell.classList.toggle("numeric", numeric(column));
    });
  }
  return table;
}
