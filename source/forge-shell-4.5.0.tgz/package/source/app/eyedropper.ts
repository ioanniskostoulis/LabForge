// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The eyedropper: a tool mode that picks a colour from the content. The shell owns the mode and its label, the
// crosshair cursor, the averaging square that follows the pointer and its size (1, 3 or 5 px); the application reads
// the pixels, or lets `averagePixels` average them.
import type { Rgb } from "./colour-models";
import type { createToolModes } from "./tool-modes";
import { createSelectControl } from "./select-control";

// MARK: given values

/** The tool's id in the tool modes. */
export const EYEDROPPER_ID = "eyedropper";
/** The mode label is `Pick a colour. Press Esc to finish` (`modeLabel`). */
export const EYEDROPPER_VERB = "Pick";
export const EYEDROPPER_OBJECT = "a colour";
/** Sides of the averaging square, in content pixels. */
export const EYEDROPPER_SIZES = [1, 3, 5] as const;
/** The size used when none is given. */
export const EYEDROPPER_DEFAULT_SIZE = 3;

// MARK: method

/** The name of a size, as the size choice shows it: `3 × 3 px`. */
export const eyedropperSizeLabel = (size: number): string => `${size} × ${size} px`;

/** The square of `size` pixels centred on pixel (x, y), cut to an image `width` × `height`; null when it misses the image. */
export function sampleSquare(x: number, y: number, size: number, width: number, height: number): { left: number; top: number; right: number; bottom: number } | null {
  const cx = Math.floor(x), cy = Math.floor(y), half = Math.floor(size / 2);
  const left = Math.max(0, cx - half), top = Math.max(0, cy - half);
  const right = Math.min(width, cx - half + size), bottom = Math.min(height, cy - half + size);
  return left < right && top < bottom ? { left, top, right, bottom } : null;
}

/** The mean colour of the square of `size` pixels centred on (x, y), over the pixels inside the image; null outside it. */
export function averagePixels(pixels: { data: ArrayLike<number>; width: number; height: number }, x: number, y: number, size: number): Rgb | null {
  const square = sampleSquare(x, y, size, pixels.width, pixels.height);
  if (!square) return null;
  let r = 0, g = 0, b = 0, n = 0;
  for (let py = square.top; py < square.bottom; py++) {
    for (let px = square.left; px < square.right; px++) {
      const i = 4 * (py * pixels.width + px);
      r += pixels.data[i]; g += pixels.data[i + 1]; b += pixels.data[i + 2]; n++;
    }
  }
  return { r: r / n, g: g / n, b: b / n };
}

// MARK: the mode

type ToolModes = Pick<ReturnType<typeof createToolModes>, "activate" | "neutral" | "watch" | "active">;

export interface EyedropperOptions {
  /** The element over the content: it takes the cursor and the averaging square, and must be positioned. */
  surface: HTMLElement;
  /** The content pixel under a pointer position (default: the position in the surface over `scale`); null off the content. */
  toContent?: (clientX: number, clientY: number) => { x: number; y: number } | null;
  /** Screen px per content pixel, for the square's size on screen (default 1). */
  scale?: () => number;
  sizes?: readonly number[];
  size?: number;
  /** A click on the content: the pixel and the square's size. The application reads the colour. */
  onPick: (x: number, y: number, size: number) => void;
  /** The mode left without a pick (Esc, or another tool). */
  onCancel?: () => void;
  /** A change of the square's size, to remember it. */
  onSize?: (size: number) => void;
  /** Stay in the mode after a pick (default: back to the neutral mode). */
  repeat?: boolean;
  document?: Document;
}

/** The eyedropper mode over a surface, in an application's tool modes. */
export function createEyedropper(modes: ToolModes, options: EyedropperOptions) {
  const doc = options.document ?? document;
  const sizes: readonly number[] = options.sizes ?? EYEDROPPER_SIZES;
  let size = options.size ?? EYEDROPPER_DEFAULT_SIZE;
  if (!sizes.includes(size)) throw new Error(`The eyedropper size ${size} is not one of ${sizes.join(", ")}.`);
  const { surface } = options;
  const scale = () => options.scale?.() ?? 1;
  const square = doc.createElement("div");
  square.className = "eyedropper-square";
  square.hidden = true;
  let picked = false;

  const toContent = (e: PointerEvent) => {
    if (options.toContent) return options.toContent(e.clientX, e.clientY);
    const r = surface.getBoundingClientRect();
    return { x: (e.clientX - r.left) / scale(), y: (e.clientY - r.top) / scale() };
  };
  const placeSquare = (e: PointerEvent) => {
    const r = surface.getBoundingClientRect();
    const side = Math.max(3, size * scale());
    square.hidden = toContent(e) === null;
    square.style.width = square.style.height = `${side}px`;
    square.style.left = `${e.clientX - r.left - side / 2}px`;
    square.style.top = `${e.clientY - r.top - side / 2}px`;
  };
  const move = (e: Event) => placeSquare(e as PointerEvent);
  const leave = () => { square.hidden = true; };
  const down = (e: Event) => {
    const ev = e as PointerEvent;
    if (ev.button !== 0) return;
    const at = toContent(ev);
    if (!at) return;
    ev.preventDefault();
    ev.stopPropagation();
    picked = true;
    options.onPick(Math.floor(at.x), Math.floor(at.y), size);
    if (!options.repeat) modes.neutral();
    else picked = false;
  };
  const key = (e: Event) => {
    const n = Number((e as KeyboardEvent).key);
    if (sizes.includes(n)) setSize(n);
  };
  const setSize = (n: number) => {
    if (!sizes.includes(n) || n === size) return;
    size = n;
    options.onSize?.(n);
  };

  let stopWatching: (() => void) | null = null;
  const teardown = () => {
    stopWatching?.();
    stopWatching = null;
    surface.classList.remove("eyedropper-active");
    surface.removeEventListener("pointermove", move);
    surface.removeEventListener("pointerleave", leave);
    surface.removeEventListener("pointerdown", down, true);
    doc.removeEventListener("keydown", key);
    square.remove();
    if (!picked) options.onCancel?.();
  };

  return {
    /** Enter the mode: the mode label, the crosshair and the square. */
    activate(): void {
      if (stopWatching) return;
      picked = false;
      modes.activate(EYEDROPPER_ID, EYEDROPPER_VERB, EYEDROPPER_OBJECT);
      surface.classList.add("eyedropper-active");
      surface.append(square);
      surface.addEventListener("pointermove", move);
      surface.addEventListener("pointerleave", leave);
      surface.addEventListener("pointerdown", down, true);
      doc.addEventListener("keydown", key);
      stopWatching = modes.watch((id) => { if (id !== EYEDROPPER_ID) teardown(); });
    },
    /** Leave the mode without a pick. */
    cancel(): void { if (modes.active === EYEDROPPER_ID) modes.neutral(); },
    get active(): boolean { return stopWatching !== null; },
    get size(): number { return size; },
    /** Change the square's size; the keys 1, 3 and 5 do the same while the mode is on. */
    setSize,
    /** The size choice, as a select for a settings or inspector row. */
    sizeSelect(): HTMLButtonElement {
      return createSelectControl({
        doc, choices: sizes.map((n) => ({ value: String(n), label: eyedropperSizeLabel(n) })),
        value: String(size), label: "Eyedropper size", className: "field-select select-control",
        onChange: (value) => setSize(Number(value)),
      });
    },
  };
}
