// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The Terminal side of a generator pane: `plot`, `table` or any noun the application gives its pane opens the pane
// and reads or sets its options by name, in the forms of TERMINAL.md (query, change, already).
//   plot                    opens the pane
//   plot fields             lists the options and their values
//   plot <field>            says the value: "X label is Time (s)."
//   plot <field> <value>    sets it and opens the pane: "X label set to Time (s)."
//   plot save               saves the code, as the pane's Save button does
import type { ConsoleResult } from "./terminal";
import { allFields, fieldName, findField, parseValue, shownValue, type GeneratorGroup, type GeneratorValues } from "./generator-fields";

/** What the command needs of a pane; `GeneratorPane` is one. */
export interface GeneratorTarget {
  /** The pane's noun as typed, such as `plot`. */
  readonly noun: string;
  groups(): GeneratorGroup[];
  readonly values: GeneratorValues;
  set(patch: GeneratorValues): void;
  /** Whether Save would do something now, and the sentence saying why not. */
  canSave(): true | string;
  save(): Promise<void> | void;
}

/** Run `<noun> [args]`. `open` shows the pane in the bottom panel. */
export async function runGeneratorCommand(target: GeneratorTarget, args: readonly string[], open: () => void): Promise<ConsoleResult> {
  const groups = target.groups();
  const [first = "", ...rest] = args;
  if (!first) { open(); return {}; }
  if (first === "fields") {
    return { columns: allFields(groups).map((field) => ({ label: fieldName(field), comment: `${field.label}: ${shownValue(field, target.values[field.key])}`, subdued: field.disabled })) };
  }
  if (first === "save") {
    const ready = target.canSave();
    if (ready !== true) return { lines: [ready] };
    await target.save();
    return {};
  }
  const field = findField(groups, first);
  if (!field) return { lines: [`Unknown ${target.noun} field: ${first}. Type ${target.noun} fields to list them.`] };
  const current = target.values[field.key];
  if (!rest.length) return { lines: [`${field.label} is ${shownValue(field, current)}.`] };
  if (field.disabled) return { lines: [`${field.label} cannot be set now.`] };
  const parsed = parseValue(field, rest.join(" "));
  if ("problem" in parsed) return { lines: [parsed.problem] };
  if (parsed.value === current || (parsed.value === "" && current === undefined)) return { lines: [`${field.label} is already ${shownValue(field, current)}.`] };
  target.set({ [field.key]: parsed.value });
  open();
  return { lines: [`${field.label} set to ${shownValue(field, parsed.value)}.`] };
}

/** Completions after `<noun> `: `fields`, `save` and every field's name; after a select or check field, its values. */
export function generatorCompletions(target: GeneratorTarget, typed: string): string[] {
  const words = typed.split(/\s+/);
  if (words.length <= 1) return ["fields", "save", ...allFields(target.groups()).map(fieldName)].filter((word) => word.startsWith(words[0] ?? ""));
  const field = findField(target.groups(), words[0]);
  const options = field?.kind === "check" ? ["on", "off"] : field?.kind === "select" ? field.choices.map(([value]) => value).filter((value) => value && value !== "---") : [];
  const last = words.at(-1) ?? "";
  return words.length === 2 ? options.filter((value) => value.startsWith(last)) : [];
}
