// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { displayKey } from "./menus";
import { setTip } from "./tips";
import { createToolButton, toolTooltip, type ToolButtonOptions } from "./tool-button";

export interface FlyoutTool extends ToolButtonOptions {}

/**
 * The markup of one row of a flyout menu, in the three columns of every menu row: the check column, empty since a tool
 * is an action and not a checkable item, the icon and name, and the shortcut. The name and the shortcut are filled in
 * as text.
 */
export function flyoutItemMarkup(tool: FlyoutTool): string {
  return `<span class="label flyout-label"><span class="flyout-icon">${tool.icon}</span><span class="flyout-name"></span></span>${tool.shortcut ? '<span class="key"></span>' : ""}`;
}

/** The tooltip of a flyout button: the family and its current tool, `Shapes: Rectangle (R)`. */
export function flyoutTip(family: string, tool: FlyoutTool): string {
  return `${family}: ${toolTooltip(tool)}`;
}

/** Optional module: a palette family. The button shows the chosen tool and opens a menu of the family. */
export function createFlyoutGroup(options: { id: string; label: string; tools: FlyoutTool[]; onSelect(id: string): void; overlay?: HTMLElement }) {
  const doc = document;
  let current = options.tools[0];
  const button = createToolButton({ ...current, id: options.id, label: options.label });
  button.classList.add("flyout");
  button.setAttribute("aria-haspopup", "menu");
  button.setAttribute("aria-expanded", "false");
  setTip(button, flyoutTip(options.label, current));
  const mark = doc.createElement("span");
  mark.className = "flyout-mark";
  button.append(mark);
  let menu: HTMLElement | null = null;

  const close = (refocus: boolean): void => {
    menu?.remove();
    menu = null;
    button.setAttribute("aria-expanded", "false");
    doc.removeEventListener("pointerdown", outside, true);
    if (refocus) button.focus();
  };
  const outside = (event: Event): void => { if (!menu?.contains(event.target as Node) && event.target !== button) close(false); };
  /** Show `tool` as the family's current tool, without reporting a choice. */
  const show = (tool: FlyoutTool): void => {
    current = tool;
    button.innerHTML = tool.icon;
    button.append(mark);
    setTip(button, flyoutTip(options.label, tool));
  };
  const choose = (tool: FlyoutTool): void => {
    show(tool);
    close(true);
    options.onSelect(tool.id);
  };
  const open = (): void => {
    menu = doc.createElement("div");
    menu.className = "menu-popup context tool-flyout";
    menu.setAttribute("role", "menu");
    const items: HTMLButtonElement[] = options.tools.map((tool) => {
      const item = doc.createElement("button");
      item.type = "button";
      item.className = "menu-item";
      item.setAttribute("role", "menuitem");
      item.disabled = tool.enabled === false;
      item.innerHTML = flyoutItemMarkup(tool);
      item.querySelector(".flyout-name")!.textContent = tool.label;
      if (tool.shortcut) item.querySelector(".key")!.textContent = displayKey(tool.shortcut);
      item.addEventListener("click", () => choose(tool));
      return item;
    });
    menu.append(...items);
    menu.addEventListener("keydown", (event) => {
      const enabled = items.filter((item) => !item.disabled);
      const at = enabled.indexOf(doc.activeElement as HTMLButtonElement);
      if (event.key === "Escape") { event.preventDefault(); close(true); }
      else if (event.key === "ArrowDown") { event.preventDefault(); enabled[(at + 1) % enabled.length]?.focus(); }
      else if (event.key === "ArrowUp") { event.preventDefault(); enabled[(at - 1 + enabled.length) % enabled.length]?.focus(); }
    });
    const rect = button.getBoundingClientRect();
    (options.overlay ?? doc.getElementById("overlay-root") ?? doc.body).append(menu);
    // Keep the menu inside the window: slide left at the right edge, open upward at the bottom.
    const size = menu.getBoundingClientRect();
    menu.style.left = `${Math.max(4, Math.min(rect.left, window.innerWidth - size.width - 4))}px`;
    menu.style.top = `${rect.bottom + 2 + size.height > window.innerHeight - 4 ? Math.max(4, rect.top - 2 - size.height) : rect.bottom + 2}px`;
    button.setAttribute("aria-expanded", "true");
    doc.addEventListener("pointerdown", outside, true);
    items.find((item) => !item.disabled)?.focus();
  };
  button.addEventListener("click", () => (menu ? close(true) : open()));
  button.addEventListener("keydown", (event) => { if (event.key === "ArrowDown" && !menu) { event.preventDefault(); open(); } });
  return {
    button,
    get tool(): FlyoutTool { return current; },
    /** Show the tool with this id as the current one, for example when the app changes tool itself. */
    setTool(id: string): void { const tool = options.tools.find((item) => item.id === id); if (tool) show(tool); },
    /** Mark the family selected while one of its tools is the active tool. */
    setSelected(selected: boolean): void { button.classList.toggle("selected", selected); },
    close: () => close(false),
  };
}
