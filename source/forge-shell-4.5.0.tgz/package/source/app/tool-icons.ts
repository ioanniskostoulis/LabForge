// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { LUCIDE_ICONS, type LucideIconName } from "./lucide-icons";

/** Icons are drawn at 16 px with a 1.25 px visible line that takes its colour from the button state (`currentColor`). */
export const TOOL_ICON_SIZE = 16;
export const TOOL_ICON_STROKE = 1.25;

/** Wrap path data in the 16 px icon box. Domain icons drawn on a 16 px grid use this; they share size, stroke and colour. */
export function toolIcon(body: string): string {
  return `<svg width="${TOOL_ICON_SIZE}" height="${TOOL_ICON_SIZE}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${TOOL_ICON_STROKE}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}

/**
 * A Lucide icon of the shell's list at `size` px. Lucide's glyph fills 20 of its 24 units, which read larger than the
 * shell's old shapes, so the drawing grid is widened to 26.67 units: the glyph then fills 75 % of the box, as before.
 * The stroke is scaled to keep the visible line at `TOOL_ICON_STROKE` (1.25 px at 16 px gives 2.08 on this grid).
 */
export const LUCIDE_GRID = 26.6667;
function lucideMarkup(body: string, size: number): string {
  const offset = (-(LUCIDE_GRID - 24) / 2).toFixed(4);
  const stroke = ((TOOL_ICON_STROKE * LUCIDE_GRID) / size).toFixed(4);
  return `<svg width="${size}" height="${size}" viewBox="${offset} ${offset} ${LUCIDE_GRID} ${LUCIDE_GRID}" fill="none" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}

/** The largest side, in Lucide units, that a normalized glyph is drawn at, and how far it may be scaled to reach it. */
export const ICON_OPTICAL_EXTENT = 18;
export const ICON_SCALE_LIMITS = { min: 0.9, max: 1.125 } as const;

/**
 * The largest side of each normalized glyph as Lucide draws it, measured on its 24-unit grid. Lucide's glyphs run from
 * 16 units (undo) to 20 (copy, settings), so side by side some read a size larger; each is scaled to
 * `ICON_OPTICAL_EXTENT` instead. Glyphs that are small by design (close, the chevrons, more, add, remove, check) and the
 * pointer, which has its own rotation, are left as drawn. A new icon is measured and added here.
 */
export const ICON_EXTENTS: Partial<Record<LucideIconName, number>> = {
  undo: 16, redo: 16, cut: 18, copy: 20, paste: 20, fit: 18, zoomIn: 18, zoomOut: 18,
  warning: 20, error: 20, info: 20, delete: 20, duplicate: 20, rotate: 18, edit: 20, readOnly: 20, plant: 15,
  search: 18, reveal: 20, export: 18, import: 18, link: 20, show: 20, activity: 20, hide: 20, lock: 20, unlock: 20, pin: 20,
  checkCircle: 20, refresh: 18, sliders: 18, terminal: 18, code: 20, settings: 20,
  play: 18, pause: 18, stop: 18, reset: 18, step: 18,
};

/** The scale that brings a glyph to the common size: 1 for a glyph left as drawn. */
export function iconScale(name: LucideIconName): number {
  const extent = ICON_EXTENTS[name];
  if (!extent) return 1;
  return Math.min(ICON_SCALE_LIMITS.max, Math.max(ICON_SCALE_LIMITS.min, ICON_OPTICAL_EXTENT / extent));
}

/** Scale a glyph about the grid's centre, dividing the stroke by the scale so the visible line stays the same. */
function normalized(body: string, scale: number, size: number): string {
  if (scale === 1) return body;
  const stroke = ((TOOL_ICON_STROKE * LUCIDE_GRID) / size / scale).toFixed(4);
  return `<g transform="translate(12 12) scale(${scale.toFixed(4)}) translate(-12 -12)" stroke-width="${stroke}">${body}</g>`;
}

export function lucideIcon(name: LucideIconName, size = TOOL_ICON_SIZE): string {
  return lucideMarkup(normalized(LUCIDE_ICONS[name], iconScale(name), size), size);
}

/** The stroke of a solid shape, in grid units: just enough to round its corners, so it is barely larger than its outline. */
export const SOLID_STROKE = 1;

/** Fill every closed shape of Lucide markup in `currentColor`, with the thin `SOLID_STROKE` around it. */
const solid = (markup: string): string => markup.replace(/<(path|rect)\b/g, `<$1 fill="currentColor" stroke-width="${SOLID_STROKE}"`);

/**
 * The solid glyphs: shapes that read better filled than outlined at a small size. Pause's bars are narrowed by a unit
 * each, so the gap between them stays open at 12 px; Step's bar stays a line of the usual weight.
 */
const SOLID_BODIES = {
  play: solid(LUCIDE_ICONS.play),
  pause: solid('<rect x="5.5" y="3" width="4" height="18" rx="1"/><rect x="14.5" y="3" width="4" height="18" rx="1"/>'),
  stop: solid(LUCIDE_ICONS.stop),
  step: LUCIDE_ICONS.step.replace(/<path d="M6[^>]*\/>/, (triangle) => solid(triangle)),
} as const;

/** A solid glyph at `size` px. */
export function solidIcon(name: keyof typeof SOLID_BODIES, size = TOOL_ICON_SIZE): string {
  return lucideMarkup(SOLID_BODIES[name], size);
}

/** The macOS pointer's angle, in degrees clockwise from the Lucide source orientation. */
export const POINTER_ROTATION = 15;
/** The vertical correction after rotation: 12 − ((2.31 + 20.45) / 2), in SVG units. */
export const POINTER_NUDGE_Y = 0.62;

/** The shared pointer glyph, an outline rotated once here so every use has the same macOS orientation. */
export function pointerIcon(size = TOOL_ICON_SIZE): string {
  return lucideMarkup(`<g transform="translate(0 ${POINTER_NUDGE_Y}) rotate(${POINTER_ROTATION} 12 12)">${LUCIDE_ICONS.pointer}</g>`, size);
}

/** The shared set for standard actions. */
export const TOOL_ICONS = {
  undo: lucideIcon("undo"), redo: lucideIcon("redo"), cut: lucideIcon("cut"), copy: lucideIcon("copy"), paste: lucideIcon("paste"),
  fit: lucideIcon("fit"), zoomIn: lucideIcon("zoomIn"), zoomOut: lucideIcon("zoomOut"),
} as const;

export type ToolIconName = keyof typeof TOOL_ICONS;

/** Status icons for problems, coloured by the element they sit in. */
export const STATUS_ICONS = {
  warning: lucideIcon("warning"), error: lucideIcon("error"), info: lucideIcon("info"),
} as const;

export type StatusIconName = keyof typeof STATUS_ICONS;

/**
 * The shared set for everything else an application shows: navigation, editing, files and running. An application
 * draws none of these itself; `forge-shell check-app` warns about an inline icon that repeats one of them.
 */
export const UI_ICONS = {
  close: lucideIcon("close"), chevronRight: lucideIcon("chevronRight"), chevronLeft: lucideIcon("chevronLeft"),
  chevronUp: lucideIcon("chevronUp"), chevronDown: lucideIcon("chevronDown"), more: lucideIcon("more"),
  add: lucideIcon("add"), remove: lucideIcon("remove"), delete: lucideIcon("delete"), duplicate: lucideIcon("duplicate"),
  rotate: lucideIcon("rotate"), edit: lucideIcon("edit"), readOnly: lucideIcon("readOnly"), pointer: pointerIcon(), plant: lucideIcon("plant"), check: lucideIcon("check"),
  search: lucideIcon("search"), reveal: lucideIcon("reveal"), export: lucideIcon("export"), import: lucideIcon("import"), link: lucideIcon("link"),
  show: lucideIcon("show"), hide: lucideIcon("hide"), activity: lucideIcon("activity"), lock: lucideIcon("lock"), unlock: lucideIcon("unlock"), pin: lucideIcon("pin"),
  checkCircle: lucideIcon("checkCircle"), refresh: lucideIcon("refresh"), settings: lucideIcon("settings"),
  sliders: lucideIcon("sliders"), terminal: lucideIcon("terminal"), code: lucideIcon("code"),
} as const;

export type UiIconName = keyof typeof UI_ICONS;

/**
 * The run controls of a panel button (Run, Pause, Stop, Reset, Step), drawn at 12 px in the text colour. Run, Pause,
 * Stop and Step are solid shapes, which read better than outlines at this size; Reset is an open arrow and stays a line.
 */
export const BUTTON_GLYPHS = {
  play: solidIcon("play", 12), pause: solidIcon("pause", 12), stop: solidIcon("stop", 12), reset: lucideIcon("reset", 12), step: solidIcon("step", 12),
} as const;
