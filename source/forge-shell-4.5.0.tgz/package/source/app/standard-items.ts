// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The standard menu items, the same in every application: each standard action has one label, one key and, where it
// has one, one Terminal command, so that Fit is View › Fit, Cmd+0 and `zoom fit` everywhere. An application chooses which
// items it has and never writes their labels or keys itself.
import type { MenuNode } from "./menus";
import { UNIVERSAL_SHORTCUTS, STANDARD_SHORTCUT_IDS, replaceShortcut } from "./shortcuts";
import type { StandardAction } from "./shared-commands";

export interface StandardItem {
  /** The menu label; `{noun}` and `{product}` are filled from the profile. */
  label: string;
  /** The accelerator on each platform; absent for an item without a key. */
  key?(mac: boolean): string;
  /** A key the application handles itself and the menu only shows (Delete), on each platform. */
  hint?(mac: boolean): string;
  /** The standard role a native menu performs (`cut`, `copy`, `paste`, `selectAll`, `togglefullscreen`). */
  role?: string;
  /** The Terminal command that runs the same action, where there is one. */
  command?: string;
}

const universal = (action: StandardAction) => () => UNIVERSAL_SHORTCUTS[STANDARD_SHORTCUT_IDS[action]];
const item = (label: string, action: StandardAction | null, extra: Omit<StandardItem, "label" | "key"> = {}): StandardItem =>
  ({ label, ...(action && STANDARD_SHORTCUT_IDS[action] ? { key: universal(action) } : {}), ...extra });

/** Every standard action's label, key, role and Terminal command. */
export const STANDARD_ITEMS: Record<StandardAction, StandardItem> = {
  "file.new": item("New {noun}", "file.new", { command: "new" }),
  "file.newWindow": item("New window", "file.newWindow"),
  "file.open": item("Open…", "file.open", { command: "open" }),
  "file.save": item("Save", "file.save", { command: "save" }),
  "file.saveAs": item("Save as…", "file.saveAs", { command: "save as" }),
  "file.print": item("Print…", "file.print", { command: "print" }),
  "file.close": item("Close", "file.close", { command: "close" }),
  "app.settings": item("Settings…", "app.settings"),
  "edit.undo": item("Undo", "edit.undo", { command: "undo" }),
  "edit.redo": item("Redo", "edit.redo", { command: "redo" }),
  "edit.cut": item("Cut", "edit.cut", { role: "cut" }),
  "edit.copy": item("Copy", "edit.copy", { role: "copy" }),
  "edit.paste": item("Paste", "edit.paste", { role: "paste" }),
  "edit.duplicate": item("Duplicate", "edit.duplicate"),
  // Delete is handled by the application where something is selected, and by text fields elsewhere; the menu shows it.
  "edit.delete": item("Delete", null, { hint: (mac) => (mac ? "Backspace" : "Delete") }),
  "edit.selectAll": item("Select all", "edit.selectAll", { role: "selectAll" }),
  "edit.find": item("Find…", "edit.find"),
  "edit.findNext": item("Find next", "edit.findNext"),
  "edit.findPrevious": item("Find previous", "edit.findPrevious"),
  "edit.replace": { label: "Replace…", key: (mac) => replaceShortcut(mac) },
  "edit.goToLine": item("Go to line…", "edit.goToLine"),
  "edit.toggleComment": item("Toggle comment", "edit.toggleComment"),
  "arrange.bringForward": item("Bring forward", "arrange.bringForward"),
  "arrange.sendBackward": item("Send backward", "arrange.sendBackward"),
  "arrange.bringToFront": item("Bring to front", "arrange.bringToFront"),
  "arrange.sendToBack": item("Send to back", "arrange.sendToBack"),
  "view.zoomIn": item("Zoom in", "view.zoomIn", { command: "zoom in" }),
  "view.zoomOut": item("Zoom out", "view.zoomOut", { command: "zoom out" }),
  "view.fit": item("Fit", "view.fit", { command: "zoom fit" }),
  "view.actualSize": item("Actual size", "view.actualSize", { command: "zoom actual" }),
  "view.inspector": item("Show inspector", "view.inspector", { command: "inspector" }),
  "view.bottomPanel": item("Show bottom panel", "view.bottomPanel", { command: "panel" }),
  // The platform's own full-screen key (Ctrl+Cmd+F on macOS, F11 on Windows) comes with the role.
  "view.fullScreen": item("Toggle full screen", null, { role: "togglefullscreen" }),
  "tab.next": item("Next tab", "tab.next"),
  "tab.prev": item("Previous tab", "tab.prev"),
  about: item("About {product}", null, { command: "about" }),
  "about.whatsNew": item("What's new…", null, { command: "changes" }),
  "about.shortcuts": item("Keyboard shortcuts…", null, { command: "shortcuts" }),
  "about.licenses": item("Licenses…", null, { command: "licenses" }),
  // Not a menu item or a command any more: the welcome screen offers updates (`showUpdateNotice`). Kept so older menus compile.
  "about.updates": item("Check for updates…", null),
};

const isMac = typeof navigator !== "undefined" && /Mac/.test(navigator.platform);

/**
 * The menu item of a standard action, with its label, key, hint and role: `standardItem("view.fit")` is
 * `{ id: "view.fit", label: "Fit", key: "CmdOrCtrl+0" }`. `extra` adds the state (`enabled`, `checked`) or removes the
 * role (`{ role: undefined }`) where the application handles the action itself, such as Copy on a canvas.
 */
export function standardItem(action: StandardAction, profile: { noun?: string; product?: string } = {}, extra: Partial<MenuNode> = {}, mac = isMac): MenuNode {
  const entry = STANDARD_ITEMS[action];
  const label = entry.label.replace("{noun}", profile.noun ?? "document").replace("{product}", profile.product ?? "");
  const node: MenuNode = { id: action, label, ...(entry.key ? { key: entry.key(mac) } : {}), ...(entry.hint ? { hint: entry.hint(mac) } : {}), ...(entry.role ? { role: entry.role } : {}), ...extra };
  if ("role" in extra && extra.role === undefined) delete node.role;
  return node;
}

/** The View menu's zoom group in its standard order: Zoom in, Zoom out, Fit, Actual size. */
export function zoomItems(enabled = true): MenuNode[] {
  return (["view.zoomIn", "view.zoomOut", "view.fit", "view.actualSize"] as const).map((action) => standardItem(action, {}, { enabled }));
}

/** The Arrange group in its standard order: Bring forward, Send backward, Bring to front, Send to back. */
export function arrangeItems(enabled = true): MenuNode[] {
  return (["arrange.bringForward", "arrange.sendBackward", "arrange.bringToFront", "arrange.sendToBack"] as const).map((action) => standardItem(action, {}, { enabled }));
}
