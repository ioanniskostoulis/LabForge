// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The Settings dialog (app.settings, Cmd+,): pages in a sidebar, each with the shell's icon, and on each page the
// inspector's own rows: a label and a select, a checkbox row, or a read-only value. Every row changes its setting at
// once; there is no Apply. The shell gives the pages every application has (General, Terminal, Updates); an
// application adds its own pages (Display, Editor, Export) as data, and a page without rows is left out. A setting
// shown here keeps its menu item and Terminal command: the dialog is one more way to it, not its only place.
import { AUTOSAVE_CHOICES, AUTOSAVE_LABELS, type AutosaveChoice } from "./saving";
import { UI_ICONS } from "./tool-icons";
import type { ShellPreferenceState } from "./shell-preferences";
import type { InfoOptions } from "./about";
import { link } from "./about";
import { createSelectControl } from "./select-control";
import { HISTORY_LIMITS, LINE_SPACINGS, TERMINAL_PREFERENCE_DEFAULTS, type HistoryLimit, type LineSpacing, type TerminalPreferences } from "./terminal-preferences";
import { checkForUpdate, lastCheckedText, lastUpdateCheck, readUpdatePreferences, rememberUpdateCheck, runInstall, updateAsset, writeUpdatePreferences, type UpdateNoticeOptions, type UpdateResult } from "./updates";

/**
 * One row of a page. `tip` is the row's tooltip, a sentence with a final period. `command` gives the Terminal command
 * that sets a value (`theme dark`), shown beside the row so the dialog teaches the Terminal; `default` is the value
 * Restore page defaults puts back.
 */
export type SettingRow =
  | { kind: "select"; label: string; tip?: string; choices: readonly (readonly [value: string, label: string])[]; value(): string; set(value: string): void; command(value: string): string; default?: string }
  | { kind: "check"; label: string; tip?: string; value(): boolean; set(value: boolean): void; command(value: boolean): string; default?: boolean }
  | { kind: "value"; label: string; value(): string }
  | { kind: "element"; element(): HTMLElement };

/** A titled part of a page; the first part of a page may have no title. */
export interface SettingsSection {
  title?: string;
  /** Omit the generated first heading when the page has one compact, self-evident group. */
  heading?: false;
  rows: readonly SettingRow[];
}

/**
 * A page of the sidebar: its id, its title and the shell icon beside it (`UI_ICONS`). `subscribe` reports changes made
 * outside the dialog (a Terminal command, a shortcut), so that the page on screen shows them at once; it returns the
 * function that stops listening.
 */
export interface SettingsPage { id: string; title: string; icon: string; sections: readonly SettingsSection[]; subscribe?(listener: () => void): () => void }

export interface SettingsDialog {
  /** Show a page by its id. */
  showPage(id: string): void;
  close(): void;
}

/** A capital T leaves more apparent space at its left edge than the vertical stems in D and E. */
const opticalInitialClass = (text: string): string => text.startsWith("T") ? " optical-initial-t" : "";

/** Where a page sits in the sidebar: General first, the application's own pages next, then Terminal, Health and Updates last. */
const pageRank = (id: string): number => ({ general: 0, terminal: 2, health: 3, updates: 4 } as Record<string, number>)[id] ?? 1;

/** The pages that have rows, in the shell's order; pages of equal rank keep the order the application gave them. */
export function visiblePages(pages: readonly SettingsPage[]): SettingsPage[] {
  return pages.filter((page) => page.sections.some((section) => section.rows.length > 0)).sort((a, b) => pageRank(a.id) - pageRank(b.id));
}

/** The values of a page's rows, to tell whether a change reported from outside changes anything on screen. */
const signature = (page: SettingsPage): string =>
  JSON.stringify(page.sections.flatMap((section) => section.rows).map((row) => (row.kind === "element" ? null : row.value())));

/** True while the dialog applies the person's own edit, whose row already shows it. */
let editing = false;
const edit = (apply: () => void): void => { editing = true; try { apply(); } finally { editing = false; } };

let open: SettingsDialog | null = null;
let lastPage = "";

/**
 * Show the Settings dialog in the frame of the Help dialogs (About, What's new, Keyboard shortcuts, Licenses), titled
 * SETTINGS in a slim band, with Restore page defaults (this page) and Close at the bottom. Below the title, the sidebar of pages and the chosen page, laid out as the options of the Plots and Tables panes: uppercase
 * group titles, a label and a 22 px control on each row, on-off options as checkboxes side by side. Up and Down move
 * between pages in the sidebar, Tab stays inside the dialog, and Escape or Close closes it and returns the focus. It
 * opens on the page last shown in this launch, or `page`; a second call while it is open shows that page.
 */
export function showSettings(options: { pages: readonly SettingsPage[]; page?: string }): SettingsDialog {
  const pages = visiblePages(options.pages);
  if (open) { open.showPage(options.page ?? lastPage); return open; }
  const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const backdrop = Object.assign(document.createElement("div"), { className: "modal-backdrop info settings" });
  const dialog = Object.assign(document.createElement("div"), { className: "about settings-dialog" });
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  // The title: SETTINGS in capitals in a slim band on --raised, as a section of the inspector is headed.
  const band = Object.assign(document.createElement("h2"), { className: "settings-band", id: "settings-title", textContent: "Settings" });
  dialog.setAttribute("aria-labelledby", band.id);
  const nav = Object.assign(document.createElement("div"), { className: "settings-nav" });
  nav.setAttribute("role", "tablist");
  nav.setAttribute("aria-orientation", "vertical");
  nav.setAttribute("aria-label", "Settings pages");
  const body = Object.assign(document.createElement("div"), { className: "settings-page generator-fields" });
  body.setAttribute("role", "tabpanel");
  const tabs = pages.map((page) => {
    const tab = Object.assign(document.createElement("button"), { type: "button", className: "settings-tab" });
    tab.setAttribute("role", "tab");
    tab.id = `settings-tab-${page.id}`;
    tab.dataset.page = page.id;
    tab.innerHTML = `<span class="settings-tab-icon" aria-hidden="true">${page.icon}</span>`;
    tab.append(Object.assign(document.createElement("span"), { className: `settings-tab-label${opticalInitialClass(page.title)}`, textContent: page.title }));
    tab.addEventListener("click", () => showPage(page.id));
    return tab;
  });
  nav.append(...tabs);
  const main = Object.assign(document.createElement("div"), { className: "settings-main" });
  main.append(nav, body);
  const foot = Object.assign(document.createElement("div"), { className: "settings-foot" });
  const restore = Object.assign(document.createElement("button"), { type: "button", className: "panel-button restore", textContent: "Restore page defaults" });
  restore.title = "Put every setting on this page back to its default.";
  const close = Object.assign(document.createElement("button"), { type: "button", className: "panel-button close", textContent: "Close" });
  foot.append(restore, Object.assign(document.createElement("span"), { className: "spacer" }), close);
  dialog.append(band, main, foot);
  let current: SettingsPage | null = null;
  /** The signature of the page as drawn, and the stop function of its subscription to outside changes. */
  let shown = "";
  let stopWatching: (() => void) | null = null;
  /** Restore page defaults is enabled while a row of the page is not at its default. */
  const refresh = () => { restore.disabled = !current || !changedRows(current).length; if (current) shown = signature(current); };
  restore.addEventListener("click", () => {
    if (!current) return;
    for (const row of changedRows(current)) {
      if (row.kind === "select" && row.default !== undefined) edit(() => row.set(row.default as string));
      else if (row.kind === "check" && row.default !== undefined) edit(() => row.set(row.default as boolean));
    }
    showPage(current.id);
  });
  backdrop.append(dialog);

  function showPage(id: string): void {
    const index = Math.max(0, pages.findIndex((page) => page.id === id));
    const page = pages[index];
    if (!page) return;
    lastPage = page.id;
    current = page;
    tabs.forEach((tab, at) => { tab.setAttribute("aria-selected", String(at === index)); tab.tabIndex = at === index ? 0 : -1; });
    body.setAttribute("aria-labelledby", tabs[index].id);
    // An untitled first section takes the page's title, so every group is headed as on the Plots and Tables panes.
    draw(page);
    body.scrollTop = 0;
    refresh();
    // A change made elsewhere while the page is open (a Terminal command) redraws the rows, keeping the place and the focus.
    stopWatching?.();
    stopWatching = page.subscribe?.(() => {
      if (editing || current !== page || signature(page) === shown) return;
      const place = body.scrollTop;
      const focused = body.contains(document.activeElement) ? document.activeElement?.getAttribute("aria-label") : null;
      draw(page);
      body.scrollTop = place;
      if (focused) body.querySelector<HTMLElement>(`[aria-label="${CSS.escape(focused)}"]`)?.focus();
      refresh();
    }) ?? null;
  }
  function draw(page: SettingsPage): void {
    body.replaceChildren(...page.sections.filter((section) => section.rows.length).map((section, at) =>
      renderSection(section.title || at > 0 || section.heading === false ? section : { ...section, title: page.title }, refresh)));
  }
  const done = () => {
    stopWatching?.();
    document.removeEventListener("keydown", keys, true);
    backdrop.remove();
    open = null;
    previousFocus?.focus();
  };
  const keys = (event: KeyboardEvent) => {
    if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); done(); return; }
    // A tab list inside a page (the Health intervals) takes its own Left and Right.
    if ((event.key === "ArrowLeft" || event.key === "ArrowRight") && event.target instanceof HTMLElement && body.contains(event.target) && event.target.closest('[role="tablist"]')) return;
    // Up and Down move between pages while the sidebar has the focus.
    if ((event.key === "ArrowDown" || event.key === "ArrowUp") && event.target instanceof HTMLElement && nav.contains(event.target)) {
      event.preventDefault();
      const at = tabs.indexOf(event.target as HTMLButtonElement);
      const next = tabs[(at + (event.key === "ArrowDown" ? 1 : -1) + tabs.length) % tabs.length];
      next.click();
      next.focus();
      return;
    }
    if (event.key === "Tab") {
      const focusable = [...dialog.querySelectorAll<HTMLElement>("button, select, input, a[href], [tabindex='0']")].filter((element) => !(element as HTMLButtonElement).disabled && element.offsetParent !== null);
      const first = focusable[0], last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
    event.stopPropagation();
  };
  close.addEventListener("click", done);
  backdrop.addEventListener("mousedown", (event) => { if (event.target === backdrop) done(); });
  document.addEventListener("keydown", keys, true);
  (document.getElementById("overlay-root") ?? document.body).append(backdrop);
  showPage(options.page ?? lastPage);
  tabs.find((tab) => tab.getAttribute("aria-selected") === "true")?.focus();
  open = { showPage, close: done };
  return open;
}

/** The rows of a page that have a default and are not at it. */
export function changedRows(page: SettingsPage): SettingRow[] {
  return page.sections.flatMap((section) => section.rows).filter((row) =>
    (row.kind === "select" && row.default !== undefined && row.value() !== row.default) || (row.kind === "check" && row.default !== undefined && row.value() !== row.default));
}

/** The Terminal command of a row's value, quiet and monospace, kept up to date as the value changes. */
function commandHint<T>(row: { command(value: T): string }, value: T): HTMLElement {
  const hint = Object.assign(document.createElement("code"), { className: "settings-command", textContent: row.command(value) });
  hint.title = "The Terminal command for this setting.";
  return hint;
}

/**
 * A group of rows, headed as the Plots and Tables options are. A checkbox takes a row of its own, its box and label in
 * the control column, so that every row's Terminal command lines up in the column at the right.
 */
function renderSection(section: SettingsSection, changed: () => void): HTMLElement {
  const healthActivity = section.title === "Activity" && section.rows.some((row) => row.kind === "element");
  const box = Object.assign(document.createElement("section"), { className: `generator-group${healthActivity ? " health-group" : ""}` });
  if (section.title) {
    box.setAttribute("aria-label", section.title);
    box.append(Object.assign(document.createElement("h3"), { className: `generator-group-title t-section${opticalInitialClass(section.title)}`, textContent: section.title }));
  }
  for (const row of section.rows) box.append(row.kind === "check" ? renderCheck(row, changed) : renderRow(row, changed));
  return box;
}

/** A row as on the Plots and Tables panes: the label, then the control filling the rest. */
export function settingsField(label: string, control: HTMLElement, hint: HTMLElement | null = null): HTMLElement {
  const row = Object.assign(document.createElement("div"), { className: `generator-field${hint ? "" : " no-hint"}` });
  row.append(Object.assign(document.createElement("span"), { className: `generator-label${opticalInitialClass(label)}`, textContent: label }), control);
  if (hint) row.append(hint);
  return row;
}

function renderCheck(row: Extract<SettingRow, { kind: "check" }>, changed: () => void): HTMLElement {
  const box = Object.assign(document.createElement("div"), { className: "generator-check" });
  if (row.tip) box.title = row.tip;
  const input = Object.assign(document.createElement("input"), { type: "checkbox", checked: row.value() });
  input.setAttribute("aria-label", row.label);
  const hint = commandHint(row, row.value());
  input.addEventListener("change", () => { edit(() => row.set(input.checked)); hint.textContent = row.command(input.checked); changed(); });
  box.append(input, Object.assign(document.createElement("span"), { className: "generator-label", textContent: row.label }));
  const line = Object.assign(document.createElement("div"), { className: "settings-check" });
  line.append(box, hint);
  return line;
}

function renderRow(row: Exclude<SettingRow, { kind: "check" }>, changed: () => void): HTMLElement {
  if (row.kind === "element") return row.element();
  if (row.kind === "value") return settingsField(row.label, Object.assign(document.createElement("span"), { className: "settings-value", textContent: row.value() }));
  const hint = commandHint(row, row.value());
  const select = createSelectControl({
    choices: row.choices.map(([value, label]) => ({ value, label })), value: row.value(), label: row.label,
    className: "generator-input select-control", title: row.tip,
    onChange: (value) => { edit(() => row.set(value)); hint.textContent = row.command(value); changed(); },
  });
  return settingsField(row.label, select, hint);
}

// MARK: the pages every application has

/** General: appearance, the inspector, the bottom panel and autosave, the shared preferences of every application. */
export function generalPage(host: { settings: ShellPreferenceState; update(change: Partial<ShellPreferenceState>): void; subscribe?(listener: () => void): () => void }, extra: readonly SettingsSection[] = []): SettingsPage {
  const s = () => host.settings;
  const window: SettingRow[] = [
    { kind: "select", label: "Appearance", get choices() { return s().appearance === "pride" ? [["dark", "Dark"], ["light", "Light"], ["pride", "Pride"]] as const : [["dark", "Dark"], ["light", "Light"]] as const; }, value: () => s().appearance, set: (value) => host.update({ appearance: value as ShellPreferenceState["appearance"] }), command: (value) => `theme ${value}`, default: "dark" },
    // One row for whether the inspector is shown and on which side, as `inspector on|off|left|right` is one command.
    { kind: "select", label: "Inspector", choices: [["right", "Right"], ["left", "Left"], ["hidden", "Hidden"]], value: () => (s().showInspector ? s().inspectorSide : "hidden"),
      set: (value) => host.update(value === "hidden" ? { showInspector: false } : { showInspector: true, inspectorSide: value as "left" | "right" }),
      command: (value) => `inspector ${value === "hidden" ? "off" : value}`, default: "right" },
    { kind: "check", label: "Show bottom panel", value: () => s().showBottomPanel, set: (value) => host.update({ showBottomPanel: value }), command: (value) => `panel ${value ? "on" : "off"}`, default: true },
  ];
  const saving: SettingRow[] = s().autosave === undefined ? [] : [
    { kind: "select", label: "Autosave", choices: AUTOSAVE_CHOICES.map((choice) => [choice, AUTOSAVE_LABELS[choice]] as const), value: () => s().autosave ?? "off", set: (value) => host.update({ autosave: value as AutosaveChoice }), command: (value) => `autosave ${value}`, default: "off" },
  ];
  return { id: "general", title: "General", icon: UI_ICONS.sliders, subscribe: host.subscribe, sections: [{ title: "Window", rows: window }, { title: "Saving", rows: saving }, ...extra] };
}

/**
 * Terminal: its text size, 10 to 24 px, and, when the host passes the Terminal's `preferences`, how many commands the
 * history keeps, the banner, the caret, the line spacing and the wrapping.
 */
export function terminalPage(host: { fontSize(): number; setFontSize(size: number): void; preferences?: TerminalPreferences; subscribe?(listener: () => void): () => void }, extra: readonly SettingsSection[] = []): SettingsPage {
  const sizes = Array.from({ length: 15 }, (_, index) => String(index + 10));
  const preferences = host.preferences;
  const rows: SettingRow[] = [
    { kind: "select", label: "Text size", tip: "The Terminal's text size; Cmd+= and Cmd+- change it too.", choices: sizes.map((size) => [size, `${size} px`] as const), value: () => String(Math.round(host.fontSize())), set: (value) => host.setFontSize(Number(value)), command: (value) => `terminal font ${value}`, default: "12" },
    ...(preferences ? [
      { kind: "select", label: "History", tip: "How many commands the history keeps; it is cleared when the session ends.", choices: HISTORY_LIMITS.map((limit) => [String(limit), `Last ${limit} commands`] as const), value: () => String(preferences.get().historyLimit), set: (value) => preferences.update({ historyLimit: Number(value) as HistoryLimit }), command: (value) => `history limit ${value}`, default: String(TERMINAL_PREFERENCE_DEFAULTS.historyLimit) },
      { kind: "select", label: "Line spacing", tip: "How closely the Terminal's lines are spaced.", choices: LINE_SPACINGS.map((choice) => [choice, choice[0].toUpperCase() + choice.slice(1)] as const), value: () => preferences.get().lineSpacing, set: (value) => preferences.update({ lineSpacing: value as LineSpacing }), command: (value) => `terminal spacing ${value}`, default: TERMINAL_PREFERENCE_DEFAULTS.lineSpacing },
      { kind: "check", label: "Wrap long lines", tip: "Wrap a line that is longer than the Terminal; otherwise the Terminal scrolls sideways.", value: () => preferences.get().wrap, set: (value) => preferences.update({ wrap: value }), command: (value) => `terminal wrap ${value ? "on" : "off"}`, default: TERMINAL_PREFERENCE_DEFAULTS.wrap },
      { kind: "check", label: "Show banner", tip: "Draw the wordmark, purpose and version above the transcript.", value: () => preferences.get().banner, set: (value) => preferences.update({ banner: value }), command: (value) => `terminal banner ${value ? "on" : "off"}`, default: TERMINAL_PREFERENCE_DEFAULTS.banner },
      { kind: "check", label: "Blinking caret", tip: "Fade the prompt's caret in and out; a steady caret stays solid.", value: () => preferences.get().caretBlink, set: (value) => preferences.update({ caretBlink: value }), command: (value) => `terminal caret ${value ? "blink" : "steady"}`, default: TERMINAL_PREFERENCE_DEFAULTS.caretBlink },
    ] satisfies SettingRow[] : []),
  ];
  const subscribe = (listener: () => void): (() => void) => {
    const stops = [host.subscribe?.(listener), preferences?.subscribe(listener)];
    return () => stops.forEach((stop) => stop?.());
  };
  return { id: "terminal", title: "Terminal", icon: UI_ICONS.terminal, subscribe, sections: [{ title: "Terminal", rows }, ...extra] };
}

export interface UpdatesPageOptions extends UpdateNoticeOptions {
  info: InfoOptions;
  /** The GitHub repository of the releases (`identity.repository`). */
  repository: string;
  /** Where the update preferences are kept, such as `<id>.updates`. */
  storageKey: string;
  storage?: Pick<Storage, "getItem" | "setItem">;
}


/**
 * Updates: the installed version, the latest release and when it was last checked, Check now and, on the desktop when
 * a newer release has this platform's installer, Update and restart, whose download the family's progress bar
 * follows. For now this is the only place an update is offered: there is no check at launch.
 */
export function updatesPage(options: UpdatesPageOptions): SettingsPage {
  const storage = options.storage ?? localStorage;
  const preferences = () => readUpdatePreferences(options.storageKey, storage);
  const actions = (): HTMLElement => {
    const box = Object.assign(document.createElement("div"), { className: "settings-updates" });
    const latest = Object.assign(document.createElement("span"), { className: "settings-value" });
    const checked = Object.assign(document.createElement("span"), { className: "settings-value" });
    const buttons = Object.assign(document.createElement("div"), { className: "settings-buttons" });
    const check = Object.assign(document.createElement("button"), { type: "button", className: "panel-button", textContent: "Check now" });
    const status = Object.assign(document.createElement("div"), { className: "settings-status update-status" });
    buttons.append(check);
    box.append(settingsField("Installed", Object.assign(document.createElement("span"), { className: "settings-value", textContent: options.info.version })),
      settingsField("Latest", latest), settingsField("Last checked", checked), buttons, status);
    const show = (result: UpdateResult | null) => {
      checked.textContent = lastCheckedText(preferences().lastChecked);
      buttons.querySelector(".update-install")?.remove();
      status.replaceChildren();
      latest.classList.toggle("available", result?.status === "available");
      latest.classList.toggle("current", result?.status === "current");
      if (!result) { latest.textContent = "Not checked yet"; return; }
      if (result.status === "current") {
        latest.textContent = `${options.info.version}, up to date`;
        const history = link("View release history", `https://github.com/${options.repository}/releases`);
        status.innerHTML = `${history}. You’re running the latest version.`;
        return;
      }
      if (result.status !== "available") { latest.textContent = "Unknown"; status.textContent = result.reason; return; }
      latest.textContent = `${result.release.version} available`;
      const asset = options.install && options.platform ? updateAsset(result.release, options.info.productName, options.platform) : null;
      const page = link("Open the release page", result.release.url);
      status.innerHTML = asset ? `${page} to read what has changed.` : `${page} to download it.`;
      if (!asset) return;
      const install = Object.assign(document.createElement("button"), { type: "button", className: "panel-button primary update-install", textContent: "Update and restart" });
      buttons.append(install);
      runInstall(options, asset, install, status, page);
    };
    const checkNow = async () => {
      check.disabled = true;
      latest.textContent = "Checking…";
      const result = await checkForUpdate(options.repository, options.info.version, options.request ?? fetch);
      rememberUpdateCheck(result, options.storageKey, storage);
      check.disabled = false;
      show(result);
    };
    check.addEventListener("click", () => void checkNow());
    show(lastUpdateCheck());
    void checkNow();
    return box;
  };
  // The page checks immediately when opened; Check now repeats the same check on demand.
  return { id: "updates", title: "Updates", icon: UI_ICONS.refresh, sections: [{ rows: [{ kind: "element", element: actions }] }] };
}
