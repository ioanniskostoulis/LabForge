// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Checking for a newer release on GitHub: the latest published release of the application's repository is compared
// with the running version. The person is told; on the desktop, Update and restart installs it (desktop/updater.ts).
// The GitHub API answers without sign-in only for a public repository; a private one answers as unavailable.
import { escape, infoWindow, link, type InfoOptions } from "./about";
import { createProgressBar } from "./progress-bar";
import type { StorageLike as SavingStorage } from "./saving";

/** A file published with a release: its download address, size in bytes and SHA-256 digest when GitHub gives one. */
export interface ReleaseAsset { name: string; url: string; size: number; sha256: string | null }

/** The newest release of a repository, as the update check reads it. */
export interface Release { version: string; url: string; name: string; assets: ReleaseAsset[] }

/** What installing an update did: the app restarts into it, or the downloaded installer was opened, or it failed. */
export type InstallResult = { status: "restarting" } | { status: "opened" } | { status: "failed"; reason: string };

/** The installer of a release for this platform, named as the family names them (`<Name>-v<version>.dmg` or `.exe`). */
export function updateAsset(release: Release, productName: string, platform: string): ReleaseAsset | null {
  const extension = platform === "darwin" ? "dmg" : platform === "win32" ? "exe" : null;
  return extension ? release.assets.find((asset) => asset.name === `${productName}-v${release.version}.${extension}`) ?? null : null;
}

export type UpdateResult =
  | { status: "available"; release: Release }
  | { status: "current"; release: Release }
  | { status: "unavailable"; reason: string };

/** Automatic checks run at most once in this period, in ms (one day). */
export const UPDATE_CHECK_INTERVAL_MS = 24 * 3600 * 1000;

/** The numeric parts of a version or tag (`v3.1.0` → [3, 1, 0]), or null when it is not one. */
export function parseVersion(text: string): number[] | null {
  const match = /^v?(\d+)\.(\d+)\.(\d+)$/.exec(text.trim());
  return match ? match.slice(1).map(Number) : null;
}

/** Negative when `a` is older than `b`, zero when equal, positive when newer; null when either is not a version. */
export function compareVersions(a: string, b: string): number | null {
  const first = parseVersion(a), second = parseVersion(b);
  if (!first || !second) return null;
  for (let index = 0; index < 3; index++) if (first[index] !== second[index]) return first[index] - second[index];
  return 0;
}

/** Whether a repository is named as `owner/name`. */
export function isRepository(text: unknown): text is string {
  return typeof text === "string" && /^[A-Za-z0-9-]+\/[A-Za-z0-9._-]+$/.test(text);
}

/** Read the latest release of `repository` (`owner/name`) and compare it with `version`. Never throws. */
export async function checkForUpdate(repository: string, version: string, request: typeof fetch = fetch): Promise<UpdateResult> {
  if (!isRepository(repository)) return { status: "unavailable", reason: "No release page is set for this app." };
  let response: Response;
  try {
    response = await request(`https://api.github.com/repos/${repository}/releases/latest`, { headers: { Accept: "application/vnd.github+json" } });
  } catch {
    return { status: "unavailable", reason: "Updates could not be checked. Check the internet connection." };
  }
  // A private repository, or one without published releases, answers 404 to a request without sign-in.
  if (response.status === 404) return { status: "unavailable", reason: "No public release was found." };
  if (!response.ok) return { status: "unavailable", reason: `Updates could not be checked: GitHub answered ${response.status}.` };
  try {
    const body = await response.json() as { tag_name?: unknown; html_url?: unknown; name?: unknown; assets?: unknown };
    const tag = String(body.tag_name ?? "");
    const order = compareVersions(tag, version);
    if (order === null || typeof body.html_url !== "string" || !body.html_url.startsWith("https://github.com/")) {
      return { status: "unavailable", reason: "The latest release has no version number." };
    }
    // Only files served from this repository's releases are kept.
    const prefix = `https://github.com/${repository}/releases/download/`;
    const assets = (Array.isArray(body.assets) ? body.assets : []).flatMap((item): ReleaseAsset[] => {
      const asset = item as { name?: unknown; browser_download_url?: unknown; size?: unknown; digest?: unknown };
      if (typeof asset.name !== "string" || typeof asset.browser_download_url !== "string" || !asset.browser_download_url.startsWith(prefix)) return [];
      const digest = typeof asset.digest === "string" && /^sha256:[0-9a-f]{64}$/.test(asset.digest) ? asset.digest.slice(7) : null;
      return [{ name: asset.name, url: asset.browser_download_url, size: Number(asset.size) || 0, sha256: digest }];
    });
    const release = { version: tag.replace(/^v/, ""), url: body.html_url, name: typeof body.name === "string" ? body.name : tag, assets };
    return order > 0 ? { status: "available", release } : { status: "current", release };
  } catch {
    return { status: "unavailable", reason: "The answer from GitHub could not be read." };
  }
}

/** The one-line result, as Messages and the status bar show it. */
export function updateMessage(result: UpdateResult, productName: string): string {
  if (result.status === "available") return `${productName} ${result.release.version} is available.`;
  if (result.status === "current") return `${productName} is up to date.`;
  return result.reason;
}

type StorageLike = Pick<SavingStorage, "getItem" | "setItem">;

/**
 * Whether a check is due: at most once a day, kept under `storageKey`. Records the check when
 * it is due.
 */
export function updateCheckDue(storageKey: string, storage: StorageLike = localStorage, now = Date.now()): boolean {
  let last: number | null = null;
  try { const stored = storage.getItem(storageKey); last = stored === null ? null : Number(stored); } catch { /* storage unavailable: check */ }
  // Never checked, an unreadable value or a time in the future (the clock was changed) all make the check due.
  if (last !== null && Number.isFinite(last) && last <= now && now - last < UPDATE_CHECK_INTERVAL_MS) return false;
  try { storage.setItem(storageKey, String(now)); } catch { /* storage unavailable */ }
  return true;
}

export interface UpdateNoticeOptions {
  /** The desktop platform (`darwin`, `win32`); with `install`, a release with this platform's installer offers Update and restart. */
  platform?: string;
  /** The desktop bridge's `installUpdate`; without it (the browser), the release page is offered. */
  install?(asset: ReleaseAsset): Promise<InstallResult>;
  /**
   * Make the app ready to quit before the download: save or discard unsaved work, as the app's own save prompt does.
   * Resolves false when the person cancels, and nothing is installed. A discard must also clear the window's edited
   * state (`setEdited(false)`) before it resolves, or `hasUnsavedWork` in the main process still stops the update.
   * Without `prepare`, a window with unsaved work stops the update with a message.
   */
  prepare?(): Promise<boolean>;
  /** The desktop bridge's `onUpdateProgress`, which the progress bar follows. */
  onProgress?(listener: (progress: { done: number; total: number }) => void): void;
  request?: typeof fetch;
  /** Where the update preferences are kept (`<id>.updates`): each check is recorded for the Updates page. */
  storageKey?: string;
}

/** The last check of this launch, which the Updates page shows. */
let lastResult: UpdateResult | null = null;
export const lastUpdateCheck = (): UpdateResult | null => lastResult;

/** Remember a check: its result for this launch and its time under `storageKey`. */
export function rememberUpdateCheck(result: UpdateResult, storageKey?: string, storage: StorageLike = localStorage, now = Date.now()): void {
  lastResult = result;
  if (storageKey) writeUpdatePreferences(storageKey, { lastChecked: now }, storage);
}

/** The progress bar that the running download moves; the bridge's listener is registered once per `onProgress`. */
let progressTarget: ((progress: { done: number; total: number }) => void) | null = null;
const listening = new WeakSet<object>();
function followProgress(options: UpdateNoticeOptions, target: (progress: { done: number; total: number }) => void): void {
  progressTarget = target;
  if (options.onProgress && !listening.has(options.onProgress)) {
    listening.add(options.onProgress);
    options.onProgress((progress) => progressTarget?.(progress));
  }
}

/** Megabytes with one decimal: `12.4 MB`. */
const megabytes = (bytes: number) => `${(bytes / 1_048_576).toFixed(1)} MB`;

/**
 * Install `asset` when `button` is pressed: the family's progress bar (`createProgressBar`, as the setup draws it)
 * follows the download under `status`, then the status says what happens next; after a failure the reason is shown,
 * the release page offered and the button enabled again.
 */
export function runInstall(options: UpdateNoticeOptions, asset: ReleaseAsset, button: HTMLButtonElement, status: HTMLElement, page: string): void {
  button.addEventListener("click", async () => {
    button.disabled = true;
    // A prepare that throws, at once or later, counts as cancelled.
    const prepare = options.prepare;
    if (prepare && !(await Promise.resolve().then(() => prepare()).catch(() => false))) {
      status.textContent = "Update cancelled. Your documents are still open.";
      button.disabled = false;
      return;
    }
    status.classList.add("progressing");
    const bar = createProgressBar("Downloading");
    status.replaceChildren(bar.element);
    followProgress(options, ({ done, total }) => {
      const whole = total || asset.size;
      bar.set(whole ? done / whole : 0, whole ? `Downloading ${megabytes(done)} of ${megabytes(whole)}` : `Downloading ${megabytes(done)}`);
    });
    const outcome = await options.install!(asset).catch((error: unknown): InstallResult => ({ status: "failed", reason: error instanceof Error ? error.message : String(error) }));
    progressTarget = null;
    if (outcome.status === "restarting") bar.finish("Installing. The app restarts when it is done.");
    else if (outcome.status === "opened") bar.finish("The installer is open. Drag the app into Applications to finish.");
    else { bar.finish(); status.classList.remove("progressing"); status.innerHTML = `${escape(outcome.reason)} ${page} to download it.`; button.disabled = false; }
  });
}

/** What the app remembers about updates: whether to check at launch (on unless turned off), and the last check. */
export interface UpdatePreferences { atLaunch: boolean; lastChecked: number | null }

/** The update preferences kept under `storageKey`. */
export function readUpdatePreferences(storageKey: string, storage: StorageLike = localStorage): UpdatePreferences {
  try {
    const stored = JSON.parse(storage.getItem(storageKey) ?? "{}") as Partial<UpdatePreferences>;
    return { atLaunch: stored.atLaunch !== false, lastChecked: typeof stored.lastChecked === "number" && Number.isFinite(stored.lastChecked) ? stored.lastChecked : null };
  } catch { return { atLaunch: true, lastChecked: null }; }
}

/** Change the update preferences kept under `storageKey`. */
export function writeUpdatePreferences(storageKey: string, change: Partial<UpdatePreferences>, storage: StorageLike = localStorage): UpdatePreferences {
  const next = { ...readUpdatePreferences(storageKey, storage), ...change };
  try { storage.setItem(storageKey, JSON.stringify(next)); } catch { /* storage unavailable */ }
  return next;
}

/** When a check ran, as the Updates page says it: `Today, 09:14`, `Yesterday, 18:02`, or the date. */
export function lastCheckedText(time: number | null, now = Date.now()): string {
  if (time === null) return "Never";
  const at = new Date(time), today = new Date(now);
  const clock = at.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const day = (date: Date) => new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const days = Math.round((day(today) - day(at)) / 86_400_000);
  if (days === 0) return `Today, ${clock}`;
  if (days === 1) return `Yesterday, ${clock}`;
  return `${at.toLocaleDateString([], { day: "numeric", month: "short", year: "numeric" })}, ${clock}`;
}

/**
 * The update card at the top of the welcome screen. Off for now: no application calls it, and Settings › Updates is
 * where an update is offered. It is kept so that it can come back. The application checks once at launch; when a newer release is
 * published the card is put at the top of `emptyState`, so it shows every time the welcome screen does, until Later
 * hides it for this launch. It says `<Name> <version> is available. You have <version>.`, links the release page and,
 * on the desktop with this platform's installer, offers **Update and restart**, whose download the progress bar follows.
 * Nothing is shown when the app is up to date or the check fails, and there is no check when Check at launch is off
 * (Settings › Updates, kept under `storageKey`). There is no menu item and no command for it.
 */
export async function showUpdateNotice(emptyState: HTMLElement, info: InfoOptions, repository: string, options: UpdateNoticeOptions = {}): Promise<UpdateResult | null> {
  // Check at launch can be turned off on the Updates page of Settings.
  if (options.storageKey && !readUpdatePreferences(options.storageKey).atLaunch) return null;
  const result = await checkForUpdate(repository, info.version, options.request ?? fetch);
  rememberUpdateCheck(result, options.storageKey);
  if (result.status !== "available") return result;
  emptyState.querySelector(".update-notice")?.remove();
  const asset = options.install && options.platform ? updateAsset(result.release, info.productName, options.platform) : null;
  const page = link("Open the release page", result.release.url);
  const card = document.createElement("section");
  card.className = "update-notice";
  card.setAttribute("role", "status");
  card.setAttribute("aria-label", "Update available");
  card.innerHTML = `<div class="update-notice-text">
      <div class="update-notice-title">${escape(updateMessage(result, info.productName))}</div>
      <div class="update-notice-detail update-status">You have ${escape(info.version)}. ${asset ? `${page} to read what has changed.` : `${page} to download it.`}</div>
    </div>
    <div class="update-notice-actions">
      <button class="panel-button update-later" type="button">Later</button>
      ${asset ? `<button class="panel-button primary update-install" type="button">Update and restart</button>` : ""}
    </div>`;
  card.querySelector(".update-later")!.addEventListener("click", () => card.remove());
  const button = card.querySelector<HTMLButtonElement>(".update-install");
  if (button && asset) runInstall(options, asset, button, card.querySelector<HTMLElement>(".update-status")!, page);
  emptyState.prepend(card);
  return result;
}

/**
 * The update dialog: checks now and shows the result in an information dialog. The shell offers updates on the welcome
 * screen (`showUpdateNotice`); this dialog remains for an application that has not moved yet.
 * @deprecated Use `showUpdateNotice`; Check for updates… is no longer a menu item or a command.
 */
export async function showUpdateCheck(info: InfoOptions, repository: string, options: UpdateNoticeOptions = {}): Promise<UpdateResult> {
  infoWindow("check for updates", info, `<div class="block update-check"><p class="about-intro">Checking for updates…</p></div>`);
  const result = await checkForUpdate(repository, info.version, options.request ?? fetch);
  const body = document.querySelector<HTMLElement>(".modal-backdrop.info .update-check");
  if (!body) return result;
  if (result.status !== "available") { body.innerHTML = `<p class="about-intro">${escape(updateMessage(result, info.productName))}</p>`; return result; }
  const asset = options.install && options.platform ? updateAsset(result.release, info.productName, options.platform) : null;
  const page = `${link("Open the release page", result.release.url)}`;
  body.innerHTML = `<p class="about-intro">${escape(updateMessage(result, info.productName))} You have ${escape(info.version)}.</p>
    <p class="about-intro update-status">${asset ? `${page} to read what has changed.` : `${page} to download it.`}</p>
    ${asset ? `<button class="panel-button primary update-install">Update and restart</button>` : ""}`;
  const button = body.querySelector<HTMLButtonElement>(".update-install");
  if (button && asset) runInstall(options, asset, button, body.querySelector<HTMLElement>(".update-status")!, page);
  return result;
}
