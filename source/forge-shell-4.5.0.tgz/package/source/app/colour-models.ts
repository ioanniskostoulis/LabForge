// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Colour models of the colour picker: sRGB in 0–255, hue, saturation and brightness (HSB, also called HSV), hex and
// CIELAB under the D65 white point. Each model can be shown as text and read back from typed text.

/** sRGB, each channel from 0 to 255. */
export interface Rgb { r: number; g: number; b: number }
/** Hue in degrees from 0 to below 360; saturation and brightness from 0 to 1. */
export interface Hsb { h: number; s: number; b: number }
/** CIELAB (D65): L from 0 to 100, a and b about −128 to 127. */
export interface Lab { l: number; a: number; b: number }

/** The models the picker can show, in the order of its rows. */
export const COLOUR_MODELS = ["hex", "rgb", "hsb", "lab"] as const;
export type ColourModel = (typeof COLOUR_MODELS)[number];

/** Row labels of the models. */
export const COLOUR_MODEL_LABELS: Record<ColourModel, string> = { hex: "Hex", rgb: "RGB", hsb: "HSB", lab: "Lab" };

/** The sentence that says what to type for each model (the tooltip of its editable value). */
export const COLOUR_MODEL_TIPS: Record<ColourModel, string> = {
  hex: "Enter a hex colour, such as #3a7bd5.",
  rgb: "Enter red, green and blue, each from 0 to 255.",
  hsb: "Enter the hue in degrees, then saturation and brightness from 0 to 100 %.",
  lab: "Enter CIELAB L from 0 to 100, then a and b from -128 to 127.",
};

// MARK: given values of CIELAB

/** The D65 white point in XYZ, Y = 1. */
export const D65 = { x: 0.95047, y: 1, z: 1.08883 };
/** sRGB (linear) to XYZ under D65, by rows. */
const RGB_TO_XYZ = [
  [0.4124564, 0.3575761, 0.1804375],
  [0.2126729, 0.7151522, 0.072175],
  [0.0193339, 0.119192, 0.9503041],
];
/** XYZ to sRGB (linear) under D65, the inverse of RGB_TO_XYZ. */
const XYZ_TO_RGB = [
  [3.2404542, -1.5371385, -0.4985314],
  [-0.969266, 1.8760108, 0.041556],
  [0.0556434, -0.2040259, 1.0572252],
];
/** The CIELAB junction δ = 6/29: the cube root is replaced by a line below δ³. */
const DELTA = 6 / 29;
/** A typed CIELAB colour may fall this far outside 0–255 in a channel and still count as in the sRGB range. */
const GAMUT_SLACK = 0.5;

// MARK: conversions

const clamp = (v: number, min: number, max: number): number => Math.max(min, Math.min(max, v));

/** HSB to sRGB: the hue picks the sector, saturation mixes towards white, brightness scales towards black. */
export function hsbToRgb({ h, s, b }: Hsb): Rgb {
  const f = (n: number) => {
    const k = (n + h / 60) % 6;
    return b - b * s * clamp(Math.min(k, 4 - k), 0, 1);
  };
  return { r: f(5) * 255, g: f(3) * 255, b: f(1) * 255 };
}

/** sRGB to HSB. A grey has hue 0 and saturation 0; black has all three 0. */
export function rgbToHsb({ r, g, b }: Rgb): Hsb {
  const [rf, gf, bf] = [r / 255, g / 255, b / 255];
  const max = Math.max(rf, gf, bf), min = Math.min(rf, gf, bf), c = max - min;
  let h = 0;
  if (c > 0) {
    if (max === rf) h = 60 * (((gf - bf) / c) % 6);
    else if (max === gf) h = 60 * ((bf - rf) / c + 2);
    else h = 60 * ((rf - gf) / c + 4);
  }
  return { h: (h + 360) % 360, s: max > 0 ? c / max : 0, b: max };
}

/** `#rrggbb`, lower case, from channels rounded to whole numbers. */
export function rgbToHex({ r, g, b }: Rgb): string {
  return "#" + [r, g, b].map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, "0")).join("");
}

/** A hex colour (`#rgb` or `#rrggbb`, the `#` optional, any case), or null. */
export function hexToRgb(text: string): Rgb | null {
  const m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(text.trim());
  if (!m) return null;
  const digits = m[1].length === 3 ? [...m[1]].map((d) => d + d).join("") : m[1];
  return { r: parseInt(digits.slice(0, 2), 16), g: parseInt(digits.slice(2, 4), 16), b: parseInt(digits.slice(4, 6), 16) };
}

/** sRGB to CIELAB (D65): undo the sRGB curve, take XYZ, divide by the white point and apply the CIELAB function. */
export function rgbToLab({ r, g, b }: Rgb): Lab {
  const linear = [r, g, b].map((v) => {
    const c = v / 255;
    return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  const [x, y, z] = RGB_TO_XYZ.map((row) => row[0] * linear[0] + row[1] * linear[1] + row[2] * linear[2]);
  const f = (t: number) => (t > DELTA ** 3 ? Math.cbrt(t) : t / (3 * DELTA ** 2) + 4 / 29);
  const [fx, fy, fz] = [f(x / D65.x), f(y / D65.y), f(z / D65.z)];
  return { l: 116 * fy - 16, a: 500 * (fx - fy), b: 200 * (fy - fz) };
}

/** CIELAB (D65) to sRGB, or null when the colour lies outside the sRGB range. */
export function labToRgb({ l, a, b }: Lab): Rgb | null {
  const fy = (l + 16) / 116, fx = fy + a / 500, fz = fy - b / 200;
  const inverse = (t: number) => (t > DELTA ? t ** 3 : 3 * DELTA ** 2 * (t - 4 / 29));
  const xyz = [inverse(fx) * D65.x, inverse(fy) * D65.y, inverse(fz) * D65.z];
  const channels = XYZ_TO_RGB.map((row) => {
    const c = row[0] * xyz[0] + row[1] * xyz[1] + row[2] * xyz[2];
    return 255 * (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.sign(c) * Math.abs(c) ** (1 / 2.4) - 0.055);
  });
  if (channels.some((v) => v < -GAMUT_SLACK || v > 255 + GAMUT_SLACK)) return null;
  const [rv, gv, bv] = channels.map((v) => clamp(v, 0, 255));
  return { r: rv, g: gv, b: bv };
}

// MARK: text

/** The text of a colour in one model: `#3a7bd5`, `58, 123, 213`, `215°, 73 %, 84 %`, `51.7, 9.7, -52.3`. */
export function formatColour(model: ColourModel, hsb: Hsb): string {
  const rgb = hsbToRgb(hsb);
  if (model === "hex") return rgbToHex(rgb);
  if (model === "rgb") return [rgb.r, rgb.g, rgb.b].map((v) => Math.round(v)).join(", ");
  if (model === "hsb") return `${Math.round(hsb.h) % 360}°, ${Math.round(hsb.s * 100)} %, ${Math.round(hsb.b * 100)} %`;
  const lab = rgbToLab({ r: Math.round(rgb.r), g: Math.round(rgb.g), b: Math.round(rgb.b) });
  return [lab.l, lab.a, lab.b].map((v) => (Math.abs(v) < 0.05 ? 0 : v).toFixed(1)).join(", ");
}

/** Three numbers separated by commas or spaces, with `°` and `%` ignored and `−` read as a minus; or null. */
export function parseTriple(text: string): [number, number, number] | null {
  const parts = text.replace(/−/g, "-").replace(/[°%]/g, " ").trim().split(/[\s,;]+/).filter(Boolean);
  if (parts.length !== 3) return null;
  const values = parts.map(Number);
  return values.every(Number.isFinite) ? (values as [number, number, number]) : null;
}

/**
 * A typed colour in one model, as HSB, or null when the text is not a colour of that model. `keep` is the colour
 * before typing: its hue is kept for a grey and its hue and saturation for black, which have none of their own.
 */
export function parseColour(model: ColourModel, text: string, keep?: Hsb): Hsb | null {
  let rgb: Rgb | null = null;
  if (model === "hex") rgb = hexToRgb(text);
  else {
    const t = parseTriple(text);
    if (!t) return null;
    if (model === "hsb") {
      const [h, s, b] = t;
      if (s < 0 || s > 100 || b < 0 || b > 100) return null;
      return { h: ((h % 360) + 360) % 360, s: s / 100, b: b / 100 };
    }
    if (model === "rgb") rgb = t.every((v) => v >= 0 && v <= 255) ? { r: t[0], g: t[1], b: t[2] } : null;
    else rgb = t[0] >= 0 && t[0] <= 100 ? labToRgb({ l: t[0], a: t[1], b: t[2] }) : null;
  }
  return rgb ? keepHue(rgbToHsb(rgb), keep) : null;
}

/** `next` with the hue of `keep` when `next` is grey, and also its saturation when `next` is black. */
export function keepHue(next: Hsb, keep?: Hsb): Hsb {
  if (!keep) return next;
  if (next.b === 0) return { h: keep.h, s: keep.s, b: 0 };
  if (next.s === 0) return { h: keep.h, s: 0, b: next.b };
  return next;
}
