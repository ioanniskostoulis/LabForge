// Licensed under the GNU General Public License v2 or later. See LICENSE.

import { attachSelectionShape } from "./selection-shape";
import { listNumber } from "./listing";
import { createTerminalPreferences, terminalPreferenceCommand, type TerminalPreferences } from "./terminal-preferences";

/** Items of a help grid sharing one label column: the longest label and a space, at least 12 characters. */
function aligned(items: ConsoleListItem[], longest = Math.max(0, ...items.map((item) => item.label.length))): ConsoleListItem[] {
  const labelWidth = Math.max(12, longest + 1);
  return items.map((item) => ({ ...item, labelWidth }));
}

export interface ConsoleListItem { label: string; comment: string; enabled?: boolean; marker?: string; indent?: number; labelWidth?: number; subdued?: boolean; }
export interface ConsoleTable { headers: string[]; rows: string[][]; numbered?: boolean; }
export interface ConsoleResult { lines?: (string | ConsoleListItem)[]; columns?: ConsoleListItem[]; groups?: { title: string; items: ConsoleListItem[] }[]; tables?: ConsoleTable[]; clear?: boolean; download?: { name: string; text: string; mimeType?: string }; }
export interface ConsoleHost { execute(line: string, signal?: AbortSignal): Promise<ConsoleResult>; complete(line: string): string[]; }

export interface TerminalOptions {
  appName: string;
  tagline: string;
  historyStorageKey: string;
  fontSize(): number;
  setFontSize(size: number): void;
  onFontSizeChange(listener: () => void): void;
  /** The history limit, banner and caret preferences; share the store with the Settings page. Session only when omitted. */
  preferences?: TerminalPreferences;
}

/** Native text input and selectable transcript, with no operating-system shell. */
export class TerminalPanel {
  private readonly output = Object.assign(document.createElement("div"), { className: "console-output" });
  private readonly input = Object.assign(document.createElement("input"), { className: "console-input", autocomplete: "off", spellcheck: false });
  private readonly status = Object.assign(document.createElement("div"), { className: "console-announcement" });
  private readonly prompt = document.createElement("form");
  // The prompt's caret, drawn as the shared editor's: it glides between positions and fades as it blinks.
  private readonly field = Object.assign(document.createElement("span"), { className: "console-field" });
  private readonly caret = Object.assign(document.createElement("span"), { className: "console-caret" });
  private readonly measure = document.createElement("canvas").getContext("2d");
  private readonly banner = Object.assign(document.createElement("header"), { className: "console-banner" });
  private history: string[] = [];
  private historyAt = 0;
  private draft = "";
  private busy = false;
  private abort: AbortController | null = null;
  private downloads: string[] = [];
  /** The Terminal's own preferences; the Settings page and the `history limit`, `banner` and `caret` commands change them. */
  readonly preferences: TerminalPreferences;

  constructor(private readonly host: HTMLElement, logo: string, version: string, private readonly commands: ConsoleHost, private readonly options: TerminalOptions) {
    // history belongs to the opened document: it starts empty and is no longer stored
    try { localStorage.removeItem(options.historyStorageKey); } catch { /* Storage may be unavailable. */ }
    host.setAttribute("role", "region");
    host.setAttribute("aria-label", `${options.appName} command console`);
    host.tabIndex = -1;
    this.output.setAttribute("role", "log");
    this.output.setAttribute("aria-label", "Command output");
    this.output.setAttribute("aria-live", "polite");
    this.status.setAttribute("role", "status");
    this.input.setAttribute("aria-label", `${options.appName} command`);
    this.input.setAttribute("autocapitalize", "off");
    const banner = this.banner;
    const mark = document.createElement("pre");
    mark.textContent = logo.trimEnd();
    mark.setAttribute("aria-hidden", "true");
    const name = Object.assign(document.createElement("span"), { className: "console-announcement", textContent: options.appName });
    const title = Object.assign(document.createElement("div"), { className: "console-title", textContent: options.tagline + "   " });
    title.append(Object.assign(document.createElement("span"), { textContent: "v" + version }));
    banner.append(mark, name, title, Object.assign(document.createElement("div"), { className: "console-hint", textContent: "Type help to list commands." }));
    this.prompt.className = "console-prompt";
    const marker = Object.assign(document.createElement("span"), { className: "console-prompt-mark", textContent: "> " });
    marker.setAttribute("aria-hidden", "true");
    this.caret.setAttribute("aria-hidden", "true");
    this.field.append(this.input, this.caret);
    this.prompt.append(marker, this.field);
    const place = () => this.placeCaret();
    for (const event of ["input", "focus", "blur", "select", "scroll", "pointerup", "keyup"]) this.input.addEventListener(event, place);
    // Arrow keys and Home or End move the caret after their keydown has been handled.
    this.input.addEventListener("keydown", () => requestAnimationFrame(place));
    document.addEventListener("selectionchange", () => { if (document.activeElement === this.input) place(); });
    // The caret is measured in the prompt's font: measure again once web fonts have loaded.
    void document.fonts?.ready.then(place);
    this.prompt.addEventListener("submit", (e) => { e.preventDefault(); void this.submit(); });
    host.addEventListener("keydown", (e) => this.key(e));
    // Keep application part shortcuts out of selected console text, but retain native copy/paste.
    host.addEventListener("keyup", (e) => e.stopPropagation());
    host.replaceChildren(banner, this.output, this.prompt, this.status);
    attachSelectionShape(host);
    // on the whole bottom panel: the empty notes and the Messages log use the terminal's text size
    const appearance = () => (host.closest("#bottom") as HTMLElement ?? host).style.setProperty("--console-size", Math.min(24, Math.max(10, Number(options.fontSize()) || 12)) + "px");
    appearance();
    options.onFontSizeChange(() => { appearance(); this.placeCaret(); });
    this.preferences = options.preferences ?? createTerminalPreferences();
    this.applyPreferences();
    this.preferences.subscribe(() => this.applyPreferences());
  }

  /** Draw the preferences: the banner, the caret's blink, the spacing and the wrapping are attributes of the host, which the shared styles read. */
  private applyPreferences(): void {
    const { banner, caretBlink, historyLimit, lineSpacing, wrap } = this.preferences.get();
    this.host.dataset.banner = banner ? "on" : "off";
    this.host.dataset.caret = caretBlink ? "blink" : "steady";
    this.host.dataset.spacing = lineSpacing;
    this.host.dataset.wrap = wrap ? "on" : "off";
    if (this.history.length > historyLimit) {
      this.history = this.history.slice(-historyLimit);
      this.historyAt = Math.min(this.historyAt, this.history.length);
    }
  }

  /**
   * Put the drawn caret at the insertion point: shown only while the prompt has the focus, nothing is selected and no
   * command runs. Each move restarts the blink, so the caret stays solid while typing.
   */
  private placeCaret(): void {
    const input = this.input;
    const shown = document.activeElement === input && !input.readOnly && input.selectionStart === input.selectionEnd && !!this.measure;
    this.field.classList.toggle("caret-drawn", shown);
    if (!shown) return;
    const style = getComputedStyle(input);
    this.measure!.font = style.font;
    const x = this.measure!.measureText(input.value.slice(0, input.selectionStart ?? 0)).width - input.scrollLeft;
    this.caret.style.transform = `translateX(${Math.max(0, Math.min(x, input.clientWidth - 1))}px)`;
    this.caret.classList.remove("blinking");
    void this.caret.offsetWidth;
    this.caret.classList.add("blinking");
  }

  show(): void { this.input.focus({ preventScroll: true }); }

  /**
   * Select all: in the prompt, the text after the `>` (nothing when it is empty); elsewhere in the console, and while a
   * command runs, the whole transcript, drawn in the `--selection` colour by `attachSelectionShape`.
   */
  selectAll(): void {
    if (!this.busy && document.activeElement === this.input) { this.input.select(); return; }
    // The read-only prompt would keep the selection to itself, so the console takes the focus first.
    this.host.focus({ preventScroll: true });
    const range = document.createRange();
    range.setStartBefore(this.banner);
    range.setEndAfter(this.output);
    const selection = document.getSelection();
    selection?.removeAllRanges();
    selection?.addRange(range);
  }

  /** Put a command at the prompt for the user to edit and run (a menu's "…" that the console does). */
  prefill(text: string): void {
    this.input.value = text;
    this.input.focus({ preventScroll: true });
    this.input.setSelectionRange(text.length, text.length);
  }

  /** Run a command as if typed (a menu item the console does: Export, Power report). */
  async run(line: string): Promise<void> {
    this.input.value = line;
    await this.submit();
  }

  /** Forget previous commands (a document was opened, or `history clear`). */
  clearHistory(): void {
    this.history = [];
    this.historyAt = 0;
    this.draft = "";
  }

  /** `history`, `history N` (the last N) and `history clear`. */
  private historyCommand(arg: string): ConsoleResult {
    if (arg === "clear") {
      this.clearHistory();
      return { lines: ["History cleared."] };
    }
    // the commands before this one
    const past = this.history.slice(0, -1);
    const count = arg ? Number(arg) : past.length;
    const from = Math.max(0, past.length - count);
    if (!past.length) return { lines: ["No commands yet."] };
    return { lines: past.slice(from).map((entry, i) => ({ marker: `[${from + i + 1}]`, label: entry, comment: "" })) };
  }

  zoom(delta: number): void {
    this.options.setFontSize(Math.min(24, Math.max(10, (Number(this.options.fontSize()) || 12) + delta)));
  }

  private async submit(): Promise<void> {
    if (this.busy) return;
    const line = this.input.value.trim();
    if (!line) return;
    // one copy of each command: running it again moves it to the end
    this.history = [...this.history.filter((entry) => entry !== line), line].slice(-this.preferences.get().historyLimit);
    this.historyAt = this.history.length;
    this.draft = "";
    const echo = this.write("", "command");
    echo.append(Object.assign(document.createElement("span"), { className: "console-echo-prompt", textContent: "> " }), document.createTextNode(line));
    this.output.append(echo);
    this.input.value = "";
    this.busy = this.input.readOnly = true;
    this.placeCaret();
    this.abort = new AbortController();
    this.output.setAttribute("aria-busy", "true");
    this.status.textContent = "Running command";
    this.scrollToPrompt();
    try {
      const asked = /^history(?:\s+(\d+|clear))?$/.exec(line);
      const result: ConsoleResult = terminalPreferenceCommand(line, this.preferences, this.options)
        ?? (asked ? this.historyCommand(asked[1] ?? "") : await this.commands.execute(line, this.abort.signal));
      if (result.clear) {
        for (const url of this.downloads) URL.revokeObjectURL(url);
        this.downloads = [];
        this.output.replaceChildren();
      } else {
        const block = document.createElement("div");
        for (const text of result.lines ?? []) block.append(typeof text === "string" ? this.write(text) : this.listItem(text));
        if (result.columns?.length) {
          const grid = Object.assign(document.createElement("div"), { className: "console-help" });
          for (const item of aligned(result.columns)) grid.append(this.listItem(item));
          block.append(grid);
        }
        // headed groups (help): a title, then its items in the same columns
        // one label column for every group, wide enough for the longest command syntax
        const widest = Math.max(0, ...(result.groups ?? []).flatMap((g) => g.items.map((item) => item.label.length)));
        for (const group of result.groups ?? []) {
          if (!group.items.length) continue;
          block.append(this.write(group.title, "console-group"));
          const grid = Object.assign(document.createElement("div"), { className: "console-help" });
          for (const item of aligned(group.items, widest)) grid.append(this.listItem(item));
          block.append(grid);
        }
        for (const data of result.tables ?? []) block.append(this.table(data));
        this.output.append(block);
        if (result.download) {
          const url = URL.createObjectURL(new Blob([result.download.text], { type: result.download.mimeType ?? "text/plain" }));
          this.downloads.push(url);
          const link = Object.assign(document.createElement("a"), { href: url, download: result.download.name, textContent: `Download ${result.download.name}`, className: "console-download" });
          block.append(link);
          // Leave a real link in the transcript if an embedded browser blocks automatic downloads.
          link.click();
        }
      }
    } catch (error) {
      this.output.append(this.write("Error: " + (error instanceof Error ? error.message : String(error))));
    } finally {
      this.busy = this.input.readOnly = false;
      this.abort = null;
      this.prompt.hidden = false;
      if (document.activeElement === document.body) this.input.focus({ preventScroll: true });
      this.output.setAttribute("aria-busy", "false");
      this.status.textContent = "Ready";
      this.scrollToPrompt();
      this.placeCaret();
    }
  }

  private scrollToPrompt(): void { this.host.scrollTop = this.host.scrollHeight; }

  private key(e: KeyboardEvent): void {
    // undo and redo with nothing at the prompt are the document's (the page's shortcuts take them)
    const mod = /Mac/.test(navigator.platform) ? e.metaKey : e.ctrlKey;
    if (mod && e.key.toLowerCase() === "z" && e.target === this.input && !this.input.value) return;
    e.stopPropagation();
    if (e.ctrlKey && e.key.toLowerCase() === "c" && this.busy) {
      e.preventDefault(); this.abort?.abort(); return;
    }
    if (mod && !e.altKey && !e.shiftKey && e.key.toLowerCase() === "a") {
      e.preventDefault();
      this.selectAll();
      return;
    }
    if (mod && !e.altKey && ["+", "=", "-"].includes(e.key)) {
      e.preventDefault();
      this.zoom(e.key === "-" ? -1 : 1);
      return;
    }
    if (e.target !== this.input || this.busy || e.isComposing) return;
    if (e.key === "ArrowUp" || e.key === "ArrowDown") {
      e.preventDefault();
      if (this.historyAt === this.history.length) this.draft = this.input.value;
      this.historyAt = Math.min(this.history.length, Math.max(0, this.historyAt + (e.key === "ArrowUp" ? -1 : 1)));
      this.input.value = this.historyAt === this.history.length ? this.draft : this.history[this.historyAt];
      this.input.setSelectionRange(this.input.value.length, this.input.value.length);
    } else if (e.key === "Tab" && !e.shiftKey) {
      e.preventDefault();
      const caret = this.input.selectionStart ?? this.input.value.length;
      const matches = this.commands.complete(this.input.value.slice(0, caret));
      const tail = this.input.value.slice(caret);
      if (matches.length === 1) {
        const prefix = matches[0] + (tail.startsWith(" ") ? "" : " ");
        this.input.value = prefix + tail;
        this.input.setSelectionRange(prefix.length, prefix.length);
      } else if (matches.length > 1) {
        this.output.append(this.write(matches.join("   ")));
        this.scrollToPrompt();
      }
      this.status.textContent = matches.length + " completions";
    } else if (e.key === "Escape") {
      e.preventDefault();
      (this.host.closest("#bottom")?.querySelector<HTMLElement>(".tab.active") ?? this.host).focus();
    }
  }

  private write(text: string, className = ""): HTMLElement {
    const listing = !className && /^ *(\[\d+\])   (.*?) — (.*)$/.exec(text);
    if (listing) return this.listItem({ marker: listing[1], label: listing[2], comment: listing[3] });
    return Object.assign(document.createElement("div"), { className: "console-line " + className, textContent: text });
  }

  private listItem(item: ConsoleListItem): HTMLElement {
    const row = document.createElement("div");
    const hasState = item.enabled !== undefined;
    row.className = "console-list " + (hasState ? item.enabled ? "enabled" : "disabled" : item.marker ? "numbered" : "plain");
    if (item.subdued) row.classList.add("subdued");
    const number = !hasState && /^\[(\d+)\]$/.exec(item.marker ?? "");
    if (number) {
      // the shared listing column: "   [9]   ", "  [10]   "
      const column = listNumber(Number(number[1]));
      row.append(document.createTextNode(column.slice(0, column.indexOf("["))));
      row.append(Object.assign(document.createElement("span"), { className: "console-state", textContent: item.marker }));
      row.append(document.createTextNode("   "));
    } else if (hasState || item.marker) {
      // states right-aligned the same way, so labels line up: "   [on]   ", "  [off]   "
      const state = item.marker ?? (item.enabled ? "[on]" : "[off]");
      row.append(document.createTextNode(" ".repeat(Math.max(1, 6 - state.length))));
      row.append(Object.assign(document.createElement("span"), { className: "console-state", textContent: state }));
      row.append(document.createTextNode("   "));
    }
    if (item.indent) row.style.paddingLeft = `${item.indent * 3}ch`;
    const label = Object.assign(document.createElement("strong"), { textContent: item.label });
    // The label column lines up, but never takes more than 45 % of the Terminal: a longer label wraps.
    if (item.labelWidth !== undefined) label.style.minWidth = `min(${item.labelWidth}ch, 45cqw)`;
    row.append(label);
    // A note has no label: its sentence stands alone, without the dash that separates a label from its description.
    if (item.comment) row.append(Object.assign(document.createElement("span"), { className: "console-comment", textContent: (item.label ? " - " : "") + item.comment }));
    return row;
  }

  private table(data: ConsoleTable): HTMLElement {
    const wrapper = Object.assign(document.createElement("div"), { className: "console-table-scroll" });
    const table = Object.assign(document.createElement("table"), { className: "console-table" + (data.numbered ? " numbered" : "") });
    const numeric = (column: number) => !(data.numbered && column === 0) && data.rows.length > 0
      && data.rows.every((row) => /^[+−-]?(?:\d|\.\d)/.test(row[column] ?? ""));
    if (data.headers.length) {
      const head = table.createTHead().insertRow();
      data.headers.forEach((title, column) => {
        const cell = document.createElement("th");
        cell.scope = "col";
        cell.textContent = title;
        cell.classList.toggle("numeric", numeric(column));
        head.append(cell);
      });
    }
    const body = table.createTBody();
    for (const row of data.rows) {
      const tr = body.insertRow();
      row.forEach((value, column) => {
        const cell = tr.insertCell();
        cell.textContent = value;
        cell.classList.toggle("numeric", numeric(column));
      });
    }
    wrapper.append(table);
    return wrapper;
  }
}
