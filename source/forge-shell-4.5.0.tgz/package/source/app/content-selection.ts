// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Selecting and rearranging content: parts on a canvas, points of a plot, scopes, tabs. The colour of content
// selection is `--pick` (cyan), separate from the accent, which marks the interface's own selection.

export interface Rect { x: number; y: number; width: number; height: number }
export interface Point { x: number; y: number }

/** A pointer that moves this far, in px, from where it went down starts a drag; less is a click. */
export const DRAG_THRESHOLD = 5;
/** The selection box: its fill strength, outline width in px and dash pattern in px (dash, gap), at any zoom. */
export const SELECTION_BOX = { fillAlpha: 0.12, lineWidth: 1, dash: [4, 3] as const };

/** Has the pointer moved far enough from (x0, y0) to start a drag? */
export function dragStarted(x0: number, y0: number, x: number, y: number, threshold = DRAG_THRESHOLD): boolean {
  return Math.hypot(x - x0, y - y0) >= threshold;
}

/** The rectangle between two corners, whichever way the box was dragged. */
export function boxRect(x0: number, y0: number, x1: number, y1: number): Rect {
  return { x: Math.min(x0, x1), y: Math.min(y0, y1), width: Math.abs(x1 - x0), height: Math.abs(y1 - y0) };
}

const inside = (inner: Rect, outer: Rect) => inner.x >= outer.x && inner.y >= outer.y && inner.x + inner.width <= outer.x + outer.width && inner.y + inner.height <= outer.y + outer.height;
const touches = (a: Rect, b: Rect) => a.x <= b.x + b.width && b.x <= a.x + a.width && a.y <= b.y + b.height && b.y <= a.y + a.height;

/**
 * What Fit frames: the selected items when there are any, else every item, as one rectangle; null when there is
 * nothing. Double Space and Cmd+0 both fit this, so a selection is brought into view and an empty one shows all.
 */
export function fitBounds<T>(items: Iterable<T>, selected: ReadonlySet<T> | readonly T[], bounds: (item: T) => Rect): Rect | null {
  const chosen = [...(Array.isArray(selected) ? selected : [...(selected as ReadonlySet<T>)])];
  const framed = chosen.length ? chosen : [...items];
  if (!framed.length) return null;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const item of framed) {
    const r = bounds(item);
    x0 = Math.min(x0, r.x); y0 = Math.min(y0, r.y); x1 = Math.max(x1, r.x + r.width); y1 = Math.max(y1, r.y + r.height);
  }
  return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
}

/** The items a selection box takes: those wholly inside it (`inside`, the default), or those it touches (`touch`). */
export function boxHits<T>(items: readonly T[], bounds: (item: T) => Rect, box: Rect, mode: "inside" | "touch" = "inside"): T[] {
  return items.filter((item) => (mode === "inside" ? inside(bounds(item), box) : touches(bounds(item), box)));
}

/**
 * The selection after a click or a box: `replace` (no modifier) takes the hits alone, `add` (Shift) adds them to the
 * selection, `toggle` (Cmd or Ctrl) adds the hits that were not selected and removes those that were.
 */
export function nextSelection<T>(base: ReadonlySet<T>, hits: readonly T[], mode: "replace" | "add" | "toggle"): Set<T> {
  if (mode === "replace") return new Set(hits);
  const next = new Set(base);
  for (const hit of hits) {
    if (mode === "add") next.add(hit);
    else if (!next.delete(hit)) next.add(hit);
  }
  return next;
}

/** The selection mode of a pointer event: Shift adds, Cmd (macOS) or Ctrl toggles, anything else replaces. */
export function selectionMode(event: { shiftKey: boolean; metaKey: boolean; ctrlKey: boolean }, mac: boolean): "replace" | "add" | "toggle" {
  if (event.shiftKey) return "add";
  return (mac ? event.metaKey : event.ctrlKey) ? "toggle" : "replace";
}

export type DropEdge = "above" | "below" | "left" | "right";

/**
 * Where a dragged item lands on a target: on its left or right side within `side` of either edge (20 % of the width,
 * at most 40 px), otherwise above or below its middle. `vertical` targets (list rows) only take above and below,
 * `horizontal` ones (tabs) only left and right.
 */
export function dropEdge(point: Point, target: Rect, layout: "grid" | "vertical" | "horizontal" = "grid"): DropEdge {
  if (layout === "vertical") return point.y < target.y + target.height / 2 ? "above" : "below";
  if (layout === "horizontal") return point.x < target.x + target.width / 2 ? "left" : "right";
  const side = Math.min(40, target.width * 0.2);
  if (point.x < target.x + side) return "left";
  if (point.x > target.x + target.width - side) return "right";
  return point.y < target.y + target.height / 2 ? "above" : "below";
}

/**
 * The index a dragged item takes in a one-dimensional list when dropped at `position` (x for a row of tabs, y for a
 * column), given where each item starts and ends along that axis, in list order.
 */
export function dropIndex(spans: readonly { start: number; end: number }[], position: number): number {
  const index = spans.findIndex((span) => position < (span.start + span.end) / 2);
  return index < 0 ? spans.length : index;
}

/** The list with the item at `from` moved so that it lands before the item that was at `to` (`to` may be the length). */
export function moveItem<T>(list: readonly T[], from: number, to: number): T[] {
  const next = [...list];
  const [item] = next.splice(from, 1);
  next.splice(to > from ? to - 1 : to, 0, item);
  return next;
}

/** The content selection colour of the page's current appearance, for drawing on a canvas. */
export function pickColor(element: Element = document.body): string {
  return getComputedStyle(element).getPropertyValue("--pick").trim() || "#2fd3e6";
}

/** Draw a selection box on a canvas in the content selection colour, its outline 1 px and dashed at any `scale`. */
export function drawSelectionBox(ctx: CanvasRenderingContext2D, box: Rect, scale = 1, color = pickColor()): void {
  ctx.save();
  ctx.globalAlpha = SELECTION_BOX.fillAlpha;
  ctx.fillStyle = color;
  ctx.fillRect(box.x, box.y, box.width, box.height);
  ctx.globalAlpha = 1;
  ctx.strokeStyle = color;
  ctx.lineWidth = SELECTION_BOX.lineWidth / scale;
  ctx.setLineDash(SELECTION_BOX.dash.map((length) => length / scale));
  ctx.strokeRect(box.x, box.y, box.width, box.height);
  ctx.restore();
}
