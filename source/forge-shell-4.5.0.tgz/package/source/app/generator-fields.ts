// Licensed under the GNU General Public License v2 or later. See LICENSE.
// The options of a generator pane, described as data: the pane draws them, and the Terminal reads and sets them by
// name (`runGeneratorCommand`), so a field typed at the prompt and one changed in the pane are the same change.

/** The values of a pane's options by key: text, a choice's value, or on and off. */
export type GeneratorValues = Record<string, string | boolean>;

/** In a select's options, a line between two groups of choices. */
export const CHOICE_RULE = "---";

interface FieldBase {
  key: string;
  label: string;
  /** The tooltip: a sentence with a final period saying what the field does and what it accepts. */
  tip: string;
  disabled?: boolean;
}
export type GeneratorField =
  | FieldBase & { kind: "text"; placeholder?: string }
  | FieldBase & { kind: "area"; rows?: number; placeholder?: string }
  | FieldBase & { kind: "select"; choices: readonly (readonly [value: string, label: string])[] }
  | FieldBase & { kind: "check" };

/** A titled group of options, headed like an inspector section. `idle` greys it out (nothing to read yet). */
export interface GeneratorGroup { title: string; fields: GeneratorField[]; idle?: boolean }

/** A field's name at the prompt: its label in lower case, words joined by hyphens (`X label` → `x-label`). */
export function fieldName(field: Pick<GeneratorField, "label">): string {
  return field.label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

/** Every field of the groups, in order. */
export function allFields(groups: readonly GeneratorGroup[]): GeneratorField[] {
  return groups.flatMap((group) => group.fields);
}

/** The field a typed name means: its prompt name or its key, without regard to case. */
export function findField(groups: readonly GeneratorGroup[], name: string): GeneratorField | undefined {
  const wanted = name.trim().toLowerCase();
  return allFields(groups).find((field) => fieldName(field) === wanted || field.key.toLowerCase() === wanted);
}

/** A value as the Terminal shows it: on or off, a choice by its label, empty text as `none`. */
export function shownValue(field: GeneratorField, value: string | boolean | undefined): string {
  if (field.kind === "check") return value ? "on" : "off";
  const text = String(value ?? "");
  if (field.kind === "select") return field.choices.find(([choice]) => choice === text)?.[1] || text || "none";
  return text || "none";
}

/** A typed value for `field`, or the sentence that says why it is not one. */
export function parseValue(field: GeneratorField, typed: string): { value: string | boolean } | { problem: string } {
  const text = typed.trim();
  if (field.kind === "check") {
    if (text === "on" || text === "off") return { value: text === "on" };
    return { problem: `${field.label} takes on or off.` };
  }
  if (field.kind === "select") {
    const choices = field.choices.filter(([value]) => value !== CHOICE_RULE);
    const hit = choices.find(([value, label]) => value.toLowerCase() === text.toLowerCase() || label.toLowerCase() === text.toLowerCase());
    if (hit) return { value: hit[0] };
    return { problem: `${field.label} takes one of: ${choices.map(([value, label]) => label || value).filter(Boolean).join(", ")}.` };
  }
  return { value: text === "none" ? "" : text };
}
