// Licensed under the GNU General Public License v2 or later. See LICENSE.

export interface ForgeIdentity {
  /** Product name as shown to users. */
  name: string;
  /** Lowercase identifier used for settings and other app-owned storage. */
  id: string;
  purpose: string;
  wordmarkPath: string;
  versionSource: string;
  port: number;
  /** The GitHub repository whose releases the update check reads, as `owner/name`; it must be public. */
  repository?: string;
}

export interface ForgeDocumentProfile {
  /** The main saved document; a project may contain several internally tabbed files. */
  noun: string;
  plural: string;
  extension: string;
  containsMultipleFiles: boolean;
  welcome: {
    title: string;
    newLabel: string;
    openLabel: string;
    detail: string;
  };
  tabs: {
    /** The noun represented by a tab, which may differ from the saved project noun. */
    noun: string;
    newTitle: string;
    closeTitle: string;
  };
}

/** Identity and document data consumed by the shell. Other domain sections join this profile as their renderers move. */
export interface ForgeAppProfile {
  identity: ForgeIdentity;
  document: ForgeDocumentProfile | null;
  html: { center: string; panes: string; prePaintScript?: string };
  theme: {
    dark: ForgeBrandAccents;
    light: ForgeBrandAccents;
  };
  desktop?: ForgeDesktopProfile;
}

export interface ForgeBrandAccents {
  accent: string;
  accentLight: string;
  accentAbout: string;
  accentFill: string;
  accentHover: string;
}

export interface ForgeDesktopProfile {
  appId: string;
  copyright: string;
  appIcon?: string;
  macCategory?: string;
  extraResources?: { from: string; to: string }[];
  document?: {
    name: string;
    description: string;
    iconStem: string;
    iconSource?: string;
    iconLabel: string;
    iconInk: string;
    role?: string;
    typeIdentifier: string;
    conformsTo: string[];
    mimeType: string;
  };
  installer?: { sidebar?: string; header?: string; include?: string };
}

/** App-owned catalogues and layout declarations that drive the shared renderers at runtime. */
export interface ForgeRuntimeProfile<MenuCommand, ConsoleCommand, InspectorSection extends string, Pane extends string, BuildMenus> {
  config: ForgeAppProfile;
  menus: { build: BuildMenus; commands: readonly MenuCommand[] };
  commands: readonly ConsoleCommand[];
  inspector: { sections: readonly InspectorSection[] };
  panes: readonly Pane[];
}

export const settingsStorageKey = (profile: ForgeAppProfile): string => `${profile.identity.id}.settings`;
export const terminalHistoryStorageKey = (profile: ForgeAppProfile): string => `${profile.identity.id}.console.history`;
export const terminalPreferencesStorageKey = (profile: ForgeAppProfile): string => `${profile.identity.id}.console.preferences`;
