// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Debounced previews for a generator pane: one build at a time, the newest code wins, and a build error is reported
// once until the preview builds again, for any kind of preview.

/** What a build gives: the preview, or the reason there is none. */
export type PreviewBuild<T> = { preview: T | null; error: string | null };

export type PreviewHandlers<T> = {
  build(code: string): Promise<PreviewBuild<T>>;
  /** A newer preview is ready. */
  show(preview: T): void;
  /** The build is waiting or running (true), or has finished (false). */
  busy(running: boolean): void;
  /** A build failed with a problem different from the last one reported. */
  problem(text: string): void;
};

/** An error's message without the prefixes Electron adds to errors from the desktop side. */
export function buildProblem(error: unknown): string {
  return String(error).replace(/^Error: (?:Error invoking remote method '[^']+': )?(?:Error: )?/, "");
}

export class PreviewScheduler<T> {
  private timer: ReturnType<typeof setTimeout> | undefined;
  private running = false;
  private pending: string | null = null;
  private lastProblem: string | null = null;

  constructor(private readonly handlers: PreviewHandlers<T>, private readonly delay = 600) {}

  /** Asks for a preview of `code` once typing pauses. */
  request(code: string): void {
    if (this.timer) clearTimeout(this.timer);
    this.handlers.busy(true);
    this.timer = setTimeout(() => { this.timer = undefined; this.pending = code; void this.next(); }, this.delay);
  }

  /** Stops waiting builds; a running build finishes but its result is dropped. */
  cancel(): void {
    if (this.timer) clearTimeout(this.timer);
    this.timer = undefined;
    this.pending = null;
    if (!this.running) this.handlers.busy(false);
  }

  private async next(): Promise<void> {
    if (this.running) return;
    const code = this.pending;
    this.pending = null;
    if (code === null) { this.handlers.busy(!!this.timer); return; }
    this.running = true;
    let result: PreviewBuild<T>;
    try { result = await this.handlers.build(code); }
    catch (error) { result = { preview: null, error: buildProblem(error) }; }
    this.running = false;
    // Newer code arrived while this one built: show nothing from the old build.
    if (this.pending === null && !this.timer) {
      if (result.preview !== null) { this.lastProblem = null; this.handlers.show(result.preview); }
      else if (result.error && result.error !== this.lastProblem) { this.lastProblem = result.error; this.handlers.problem(result.error); }
    }
    if (this.pending !== null) void this.next();
    else this.handlers.busy(!!this.timer);
  }
}
