// Licensed under the GNU General Public License v2 or later. See LICENSE.
import { listNumber } from "./listing";
import type { MenuNode } from "./menus";
import { standardItem } from "./standard-items";

export const escape = (t: string) => t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
/** `code` in changelog text. */
export const inline = (t: string) => escape(t).replace(/`([^`]+)`/g, "<code>$1</code>");
/** A numbered row in the terminal's listing format: the number column, then the text. */
export const listing = (n: number, text: string) => `<div class="listing"><span class="n">${listNumber(n)}</span>${text}</div>`;
/** A numbered row with a name column, then — what it is. */
export const named = (n: number, name: string, what: string) =>
  `<div class="listing named"><span class="n">${listNumber(n)}</span><span class="name">${name}</span><span class="c">${escape(what)}</span></div>`;
export const link = (name: string, url: string) => `<a href="${url}" target="_blank" rel="noopener">${escape(name)}</a>`;
/** A key and what it does, as help lists commands. */
export const term = (key: string, what: string) => `<div class="term"><span class="k">${escape(key)}</span><span>${escape(what)}</span></div>`;

/** The information dialog frame: wordmark, purpose, version, body and Close. */
export function infoWindow(name: string, options: { productName: string; purpose: string; logo: string; version: string }, body: string): void {
  const { productName, purpose, logo, version } = options;
  document.querySelector(".modal-backdrop.info")?.remove();
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop info";
  backdrop.innerHTML = `
    <div class="about" role="dialog">
      <div class="brandbox"><pre></pre><div class="tagline">${purpose}   <span class="version">v${version}</span></div><div class="subtitle"></div></div>
      <div class="body">
        ${body}
        <button class="panel-button close" style="flex:0 0 auto; width:90px">Close</button>
      </div>
    </div>`;
  backdrop.querySelector(".about")!.setAttribute("aria-label", `${productName} ${name}`);
  const wordmark = backdrop.querySelector("pre")!;
  wordmark.textContent = logo.trimEnd();
  wordmark.setAttribute("aria-hidden", "true");
  backdrop.querySelector(".subtitle")!.textContent = name;
  const close = () => {
    backdrop.remove();
    document.removeEventListener("keydown", esc);
  };
  const esc = (e: KeyboardEvent) => e.key === "Escape" && close();
  backdrop.querySelector(".close")!.addEventListener("click", close);
  backdrop.addEventListener("mousedown", (e) => {
    if (e.target === backdrop) close();
  });
  document.addEventListener("keydown", esc);
  document.getElementById("overlay-root")!.append(backdrop);
}

// MARK: the Help menu and its four dialogs

/** What every information dialog shows in its header. */
export interface InfoOptions { productName: string; purpose: string; logo: string; version: string }

/**
 * Help, in three groups with a separator between each: the product (About, where the platform's application menu
 * lacks it, and What's new…), using it (Keyboard shortcuts…, then the application's own `guides`), and the legal
 * (Licenses…). On macOS desktop the native application menu holds About and sends the same `about` action. Updates
 * are not in Help: Settings › Updates offers them. `_updates` is ignored; it remains so that older calls compile.
 */
export function helpMenu(productName: string, appMenuHasAbout: boolean, _updates = false, guides: readonly MenuNode[] = []): MenuNode {
  return {
    label: "Help",
    submenu: [
      ...(appMenuHasAbout ? [] : [standardItem("about", { product: productName })]), standardItem("about.whatsNew"),
      { separator: true },
      standardItem("about.shortcuts"), ...guides,
      { separator: true },
      standardItem("about.licenses"),
    ],
  };
}

/** One heading of release notes and its items, as What's new shows them. */
export interface ReleaseNoteBlock { heading: string; items: string[] }

/** The `## <version>` section of a changelog, else the newest section, as blocks under its `###` headings. */
export function releaseNoteBlocks(changelog: string, version: string): ReleaseNoteBlock[] {
  const lines = changelog.split(/\r?\n/);
  let start = lines.findIndex((line) => line.trim() === `## ${version}`);
  if (start < 0) start = lines.findIndex((line) => line.startsWith("## "));
  if (start < 0) return [];
  const end = lines.findIndex((line, index) => index > start && line.startsWith("## "));
  const blocks: ReleaseNoteBlock[] = [];
  let block: ReleaseNoteBlock = { heading: "", items: [] };
  let item: string | null = null;
  const flushItem = () => { if (item !== null) block.items.push(item); item = null; };
  const flushBlock = () => { flushItem(); if (block.heading || block.items.length) blocks.push(block); block = { heading: "", items: [] }; };
  for (const line of lines.slice(start + 1, end < 0 ? undefined : end)) {
    if (line.startsWith("### ")) { flushBlock(); block.heading = line.slice(4).trim(); }
    else if (line.startsWith("- ")) { flushItem(); item = line.slice(2).trim(); }
    else if (line.trim() && item !== null) item += ` ${line.trim()}`;
    else flushItem();
  }
  flushBlock();
  return blocks;
}

/** What's new: the release notes of this version from the shipped CHANGELOG.md, numbered per heading. */
export async function showWhatsNew(info: InfoOptions, changelogUrl = "CHANGELOG.md"): Promise<void> {
  let text = "";
  try { const response = await fetch(changelogUrl); if (response.ok) text = await response.text(); } catch { /* shown as unavailable */ }
  const html = releaseNoteBlocks(text, info.version).map((block) =>
    `<div class="block">${block.heading ? `<div class="about-heading">${escape(block.heading)}</div>` : ""}${block.items.map((item, index) => listing(index + 1, `<span class="t">${inline(item)}</span>`)).join("")}</div>`).join("");
  infoWindow("what's new", info, html || `<p class="about-intro">The release notes for this version aren't available.</p>`);
}

/** Keyboard shortcuts as groups of rows, each a written-out key and what it does. */
export type ShortcutGroups = [string, [string, string][]][];

/**
 * The keyboard shortcuts of a menu definition, one group per top-level menu that has any, in menu order. Keys are
 * written out (`shortcutText`), and a label loses its ellipsis.
 */
export function menuShortcutGroups(menus: readonly MenuNode[], written: (key: string) => string): ShortcutGroups {
  const groups: ShortcutGroups = [];
  for (const menu of menus) {
    const rows: [string, string][] = [];
    const seen = new Set<string>();
    const visit = (items: readonly MenuNode[]) => {
      for (const item of items) {
        const key = item.key ?? item.hint;
        if (key && item.label && !seen.has(key)) { seen.add(key); rows.push([written(key), item.label.replace(/…$/, "")]); }
        if (item.submenu) visit(item.submenu);
      }
    };
    visit(menu.submenu ?? []);
    if (rows.length && menu.label) groups.push([menu.label, rows]);
  }
  return groups;
}

/** Keyboard shortcuts…: the groups as help lists commands, key then what it does. */
export function showShortcuts(info: InfoOptions, groups: ShortcutGroups): void {
  // The key column fits the longest key, so that a long one (Control + Shift + Tab) never runs into its description.
  const width = Math.max(12, ...groups.flatMap(([, rows]) => rows.map(([key]) => key.length))) + 2;
  const html = groups.map(([title, rows]) =>
    `<div class="block"><div class="about-heading">${escape(title)}</div><div class="terms" style="--key-width: ${width}ch">${rows.map(([key, what]) => term(key, what)).join("")}</div></div>`).join("");
  infoWindow("keyboard shortcuts", info, html || `<p class="about-intro">There are no keyboard shortcuts yet.</p>`);
}

/** A work included from others: its name, what it is used for with its licence, and where it comes from. */
export type IncludedWork = [name: string, terms: string, url: string];

/** The works every application of the family includes: the shell, Electron and the wordmark lettering. */
export const SHARED_WORKS: readonly IncludedWork[] = [
  ["forge-shell", "the shared interface code; GPL v2 or later", "https://github.com/ioanniskostoulis/forge-shell"],
  ["Electron", "the desktop runtime; MIT, with Chromium's licenses in the app bundle", "https://github.com/electron/electron"],
  ["FIGlet Roman", "the ASCII wordmark (font not bundled)", "https://github.com/ankushbhagats/figlet-fonts/blob/master/Roman.flf"],
];

/** A further licence text shown after the GPL, such as the terms of a borrowed work; `skipParagraphs` drops a copyright header. */
export interface LicenseText { heading: string; url: string; skipParagraphs?: number }

/**
 * Licenses…: the application's own licence, what it includes from others, then the full GPL text from the shipped
 * LICENSE and any further texts the application ships.
 */
export async function showLicenses(info: InfoOptions, included: readonly IncludedWork[] = SHARED_WORKS, texts: readonly LicenseText[] = [], licenseUrl = "LICENSE"): Promise<void> {
  const rows = included.map(([name, terms, url], index) => named(index + 1, link(name, url), terms)).join("");
  infoWindow("licenses", info, `
        <div class="block">
          <div class="about-heading">${escape(info.productName)}</div>
          <p class="about-intro">Free software under the GNU General Public License, version 2 or (at your option) any later version, WITHOUT ANY WARRANTY. Its source ships with the app.</p>
        </div>
        <div class="block"><div class="about-heading">Included from others</div>${rows}</div>
        <div class="block">
          <div class="about-heading">GNU General Public License v2</div>
          <div class="license-text">Loading…</div>
        </div>
        ${texts.map((text) => `<div class="block"><div class="about-heading">${escape(text.heading)}</div><div class="license-text">Loading…</div></div>`).join("")}`);
  const targets = [...document.querySelectorAll<HTMLElement>(".about .license-text")];
  const sources = [{ url: licenseUrl, skipParagraphs: 0 }, ...texts];
  await Promise.all(sources.map(async (source, index) => {
    const target = targets[index];
    try {
      const response = await fetch(source.url);
      if (!response.ok) throw new Error("unavailable");
      const text = await response.text();
      // The original paragraphs, reflowed as prose; the wording and notices are kept.
      target?.replaceChildren(...text.trim().split(/\r?\n\s*\r?\n/).slice(source.skipParagraphs ?? 0)
        .map((block) => Object.assign(document.createElement("p"), { textContent: block.replace(/\s*\r?\n\s*/g, " ").trim() })));
    } catch {
      if (target) target.textContent = `The license text isn't available here: see ${source.url} in the source.`;
    }
  }));
}

/** About: the application's own paragraphs (HTML) above the shared licence summary. */
export function showAbout(info: InfoOptions, body = ""): void {
  infoWindow("about", info, `${body}
        <div class="block">
          <p class="about-intro">${escape(info.productName)} is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or (at your option) any later version. It is distributed WITHOUT ANY WARRANTY. <a href="https://www.gnu.org/licenses/old-licenses/gpl-2.0.html" target="_blank" rel="noopener">GNU General Public License v2</a></p>
          <p class="about-intro">Updates, maintenance, and support are not guaranteed.</p>
        </div>`);
}
