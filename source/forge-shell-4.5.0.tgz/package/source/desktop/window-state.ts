// Licensed under the GNU General Public License v2 or later. See LICENSE.

/** Main-process state shared by all windows of a Forge desktop app. */
export class DesktopWindowState<File> {
  private readonly startupFiles = new Map<number, File[]>();
  private readonly edited = new Set<number>();
  private readonly confirmed = new Set<number>();
  private quitting = false;

  setStartupFiles(id: number, files: File[]): void { this.startupFiles.set(id, files); }

  takeStartupFiles(id: number): File[] {
    const files = this.startupFiles.get(id) ?? [];
    this.startupFiles.set(id, []);
    return files;
  }

  setEdited(id: number, value: boolean): void {
    if (value) this.edited.add(id);
    else this.edited.delete(id);
  }

  /** Whether any window holds unsaved work, which an update must not quit over. */
  hasEdited(): boolean { return this.edited.size > 0; }

  needsClosePrompt(id: number): boolean { return this.edited.has(id) && !this.confirmed.has(id); }
  confirmClose(id: number): void { this.confirmed.add(id); }
  beginQuit(): void { this.quitting = true; }
  cancelQuit(): void { this.quitting = false; }

  /** Clear a closed window's state and say whether the pending quit can finish. */
  closed(id: number, remainingWindows: number): boolean {
    this.startupFiles.delete(id);
    this.edited.delete(id);
    this.confirmed.delete(id);
    return this.quitting && remainingWindows === 0;
  }
}
