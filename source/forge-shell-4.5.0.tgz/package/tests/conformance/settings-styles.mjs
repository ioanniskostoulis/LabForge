import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");

test("settings selects stay above the modal backdrop", () => {
  assert.match(css, /\.select-popup \{[^}]*z-index: 300;/);
});

test("settings rows reflow command hints in narrow windows", () => {
  assert.match(css, /@media \(max-width: 760px\) \{[\s\S]*\.settings-main \{ grid-template-columns: 140px minmax\(0, 1fr\); \}/);
  assert.match(css, /\.settings-page \.generator-field \.settings-command \{ grid-column: 2; justify-self: start; text-align: left; \}/);
  assert.match(css, /\.settings-page \.settings-check \.settings-command \{ grid-column: 1; justify-self: start; text-align: left; \}/);
  assert.match(css, /@media \(max-width: 480px\) \{[\s\S]*\.settings-page \.generator-field \{ grid-template-columns: minmax\(84px, 1fr\) minmax\(0, 1fr\); column-gap: 8px; \}/);
});

test("hintless Settings fields do not reserve a command column", () => {
  assert.match(css, /\.settings-page \.generator-field\.no-hint \{ grid-template-columns: var\(--settings-label-width\) minmax\(0, 1fr\); \}/);
});

test("Settings title and footer share the dialog inset", () => {
  assert.match(css, /\.settings-band \{[^}]*padding: 11px 12px;/);
  assert.match(css, /\.settings-foot \{[^}]*padding: 12px;/);
});

test("Updates tints the current release and stacks its download progress", () => {
  assert.match(css, /\.settings-value\.available, \.settings-value\.current \{ color: var\(--accent-light\);/);
  assert.match(css, /\.progress-bar \{ display: block;[^}]*white-space: pre; \}/);
  assert.match(css, /\.progress-bar \.progress-line \{ display: block; \}/);
  assert.match(css, /\.progress-bar \.progress-label \{ display: block; margin-top: 2px;/);
  assert.match(css, /\.settings-buttons \.panel-button \{ flex: none; padding: 0 17px; \}/);
});

test("Health settings stay inside a narrow page and its plant icon keeps the tab height", () => {
  assert.match(css, /\.settings-tab\[data-page="health"\] \.settings-tab-icon svg \{ width: 18px; height: 18px; \}/);
  assert.match(css, /\.health-group \.generator-group-title \{ margin-bottom: 10px; \}/);
  assert.match(css, /\.settings-page \.health-heading \{ grid-template-columns: var\(--settings-label-width\) minmax\(0, 1fr\); margin-bottom: 12px; \}/);
  assert.match(css, /\.health-modes button \{ height: 22px; padding: 0;[^}]*font: var\(--size\)\/22px var\(--ui\);/);
  assert.match(css, /\.health-chart-scroll \{ min-width: 0; overflow-x: visible;/);
  assert.match(css, /\.health-chart \{ display: grid; width: 100%;/);
  assert.match(css, /@media \(max-width: 620px\) \{[\s\S]*\.health-chart-scroll \{ overflow-x: auto; \}/);
  assert.match(css, /\.health-chart \{[^}]*min-width: 0;/);
  assert.match(css, /\.health-day \{ min-width: 0;/);
  assert.match(css, /@media \(max-width: 620px\) \{[\s\S]*\.health-modes \{ flex-wrap: wrap;/);
});

test("compact dialogs share the shell's radius, shadow and action spacing", () => {
  assert.match(css, /\.save-prompt, \.health-reminder-dialog \{ border-radius: 10px; box-shadow: 0 20px 60px rgba\(0, 0, 0, 0\.6\); \}/);
  assert.match(css, /\.save-prompt \.actions \{ display: flex; gap: var\(--gap\); margin-top: 12px; \}/);
  assert.match(css, /\.health-reminder-actions \{ display: flex; justify-content: flex-end; flex-wrap: wrap; gap: var\(--gap\); margin-top: 16px; \}/);
});

test("interactive checkbox rows and sliders expose their adjustment cursor", () => {
  assert.match(css, /input\[type="checkbox"\] \{[^}]*cursor: pointer;/);
  assert.doesNotMatch(css, /\.field\.check, \.generator-check \{ cursor: pointer; \}/);
  assert.match(css, /\.slider \{[^}]*cursor: pointer;/);
  assert.match(css, /\.slider-row\.disabled \.slider \{ cursor: default; \}/);
});
