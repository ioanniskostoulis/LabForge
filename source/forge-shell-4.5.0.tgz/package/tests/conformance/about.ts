import assert from "node:assert/strict";
import test from "node:test";
import { helpMenu, menuShortcutGroups, releaseNoteBlocks, SHARED_WORKS } from "../../source/app/about";

test("Help lists About only where the application menu lacks it, then What's new, Keyboard shortcuts and Licenses", () => {
  assert.deepEqual(helpMenu("Example", false).submenu!.map((item) => item.separator ? "-" : item.id), ["about", "about.whatsNew", "-", "about.shortcuts", "-", "about.licenses"]);
  assert.deepEqual(helpMenu("Example", true).submenu!.map((item) => item.separator ? "-" : item.id), ["about.whatsNew", "-", "about.shortcuts", "-", "about.licenses"], "three groups, two separators, also without About");
  assert.deepEqual(helpMenu("Example", true, false, [{ id: "guide", label: "Writing guide…" }]).submenu!.map((item) => item.separator ? "-" : item.id), ["about.whatsNew", "-", "about.shortcuts", "guide", "-", "about.licenses"], "an application's guides join Keyboard shortcuts");
  assert.equal(helpMenu("Example", false).submenu![0].label, "About Example");
});

test("What's new takes this version's changelog section, else the newest, with its headings and wrapped items", () => {
  const changelog = "# Changelog\n\n## Unreleased\n\n- Next.\n\n## 1.1.0\n\n### Added\n\n- One,\n  wrapped.\n- Two.\n\n### Fixed\n\n- Three.\n\n## 1.0.0\n\n- Old.\n";
  assert.deepEqual(releaseNoteBlocks(changelog, "1.1.0"), [{ heading: "Added", items: ["One, wrapped.", "Two."] }, { heading: "Fixed", items: ["Three."] }]);
  assert.deepEqual(releaseNoteBlocks(changelog, "9.9.9"), [{ heading: "", items: ["Next."] }]);
  assert.deepEqual(releaseNoteBlocks("", "1.0.0"), []);
});

test("keyboard shortcuts are grouped by top-level menu, written out, without ellipses or repeated keys", () => {
  const groups = menuShortcutGroups([
    { label: "File", submenu: [{ id: "file.new", label: "New document", key: "CmdOrCtrl+N" }, { id: "file.open", label: "Open…", key: "CmdOrCtrl+O" }, { separator: true }, { label: "Autosave", submenu: [{ id: "a", label: "Off" }] }] },
    { label: "Edit", submenu: [{ role: "undo", label: "Undo" }] },
    { label: "View", submenu: [{ id: "view.inspector", label: "Show inspector", key: "CmdOrCtrl+I" }, { id: "again", label: "Again", key: "CmdOrCtrl+I" }] },
  ], (key) => key.replace("CmdOrCtrl+", "Cmd + "));
  assert.deepEqual(groups, [["File", [["Cmd + N", "New document"], ["Cmd + O", "Open"]]], ["View", [["Cmd + I", "Show inspector"]]]]);
});

test("every application credits the shell, Electron and the wordmark lettering", () => {
  assert.deepEqual(SHARED_WORKS.map(([name]) => name), ["forge-shell", "Electron", "FIGlet Roman"]);
});
