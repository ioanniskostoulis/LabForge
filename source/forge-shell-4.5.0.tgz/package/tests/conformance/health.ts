import assert from "node:assert/strict";
import { test } from "node:test";
import { addHealthSeconds, createHealthTracker, healthChartDays, healthChartTiles, healthCommand, healthMonthLabels, healthPage, healthSecondsPerDate, healthTileLevel, showHealthBreakReminder, type HealthTracker } from "../../source/app/health";
import { UI_ICONS } from "../../source/app/tool-icons";

test("health reminder reports, sets and disables the daily active-use threshold", () => {
  let hours: number | null = 4;
  const tracker = {
    reminderAfterHours: () => hours,
    setReminderAfterHours: (value: number | null) => { hours = value; },
  } as HealthTracker;
  assert.deepEqual(healthCommand("", tracker), { lines: ["Break reminder set for after 4 hours."] });
  assert.deepEqual(healthCommand("reminder 2", tracker), { lines: ["Break reminder set for after 2 hours."] });
  assert.equal(hours, 2);
  assert.deepEqual(healthCommand("reminder off", tracker), { lines: ["Break reminders disabled."] });
  assert.equal(hours, null);
  assert.deepEqual(healthCommand("", tracker), { lines: ["Break reminders are off."] });
});

test("health reminder command refuses unsupported thresholds and extra arguments", () => {
  const tracker = { reminderAfterHours: () => 4, setReminderAfterHours() {} } as HealthTracker;
  assert.deepEqual(healthCommand("reminder 1", tracker), { lines: ["Break reminder takes off, 2, 3, 4, 5 or 6."] });
  assert.deepEqual(healthCommand("reminder 2 later", tracker), { lines: ["Usage: health reminder <off|2|3|4|5|6>."] });
  assert.deepEqual(healthCommand("other 2", tracker), { lines: ["Usage: health reminder <off|2|3|4|5|6>."] });
});

test("the Health page exposes the same supported reminder values and Terminal command", () => {
  const tracker = { reminderAfterHours: () => 4, setReminderAfterHours() {} } as HealthTracker;
  const page = healthPage(tracker);
  const reminder = page.sections[1].rows[0];
  assert.equal(reminder.kind, "select");
  if (reminder.kind !== "select") throw new Error("Health reminder must be a select row.");
  assert.equal(reminder.default, "4");
  assert.deepEqual(reminder.choices.map(([value]) => value), ["off", "2", "3", "4", "5", "6"]);
  assert.equal(reminder.command!(reminder.value()), "health reminder 4");
  assert.equal(page.icon, UI_ICONS.plant, "Settings uses the break dialog's plant icon");
});

test("health reminder choice survives tracker reload", () => {
  const previous = { document: globalThis.document, window: globalThis.window, requestAnimationFrame: globalThis.requestAnimationFrame };
  const listeners = new Map<string, EventListener>();
  const documentStub = {
    visibilityState: "hidden",
    hasFocus: () => false,
    addEventListener: (name: string, listener: EventListener) => listeners.set(name, listener),
    removeEventListener: (name: string) => { listeners.delete(name); },
  } as unknown as Document;
  const windowStub = {
    setInterval: () => 1,
    clearInterval() {},
    addEventListener() {},
    removeEventListener() {},
  } as unknown as Window & typeof globalThis;
  globalThis.document = documentStub;
  globalThis.window = windowStub;
  globalThis.requestAnimationFrame = (() => 1) as typeof requestAnimationFrame;
  const values = new Map<string, string>();
  const storage = { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => { values.set(key, value); } };
  try {
    const first = createHealthTracker({ storageKey: "health", storage, now: () => 1 });
    first.setReminderAfterHours(6);
    first.dispose();
    const second = createHealthTracker({ storageKey: "health", storage, now: () => 1 });
    assert.equal(second.reminderAfterHours(), 6);
    second.dispose();
    // two windows: each adds its own time to what the other saved, never over it
    let clock = 0;
    values.set("health", JSON.stringify({ reminderAfterHours: 4, days: [{ date: "2026-01-02", seconds: 600 }] }));
    const engagedDocument = { ...documentStub, visibilityState: "visible", hasFocus: () => true } as unknown as Document;
    globalThis.document = engagedDocument;
    const a = createHealthTracker({ storageKey: "health", storage, now: () => clock });
    const b = createHealthTracker({ storageKey: "health", storage, now: () => clock });
    clock = 10_000;
    a.dispose();
    b.dispose();
    const saved = JSON.parse(values.get("health")!) as { days: { date: string; seconds: number }[] };
    assert.equal(saved.days.find((day) => day.date === "2026-01-02")?.seconds, 600, "an older day survives both windows");
    assert.equal(saved.days.reduce((sum, day) => sum + day.seconds, 0), 620, "both windows' 10 s are kept");
    // storage that reads but cannot write: the window keeps adding to its own copy instead of starting over
    const full = { getItem: () => null, setItem: () => { throw new Error("quota"); } };
    clock = 0;
    const alone = createHealthTracker({ storageKey: "health", storage: full, now: () => clock });
    alone.setReminderAfterHours(3);
    clock = 10_000;
    listeners.get("visibilitychange")?.(new Event("visibilitychange"));
    clock = 20_000;
    listeners.get("visibilitychange")?.(new Event("visibilitychange"));
    assert.equal(alone.activeSecondsToday(), 20, "both stretches are kept although nothing is stored");
    assert.equal(alone.reminderAfterHours(), 3, "the reminder choice is kept too");
    alone.dispose();
  } finally {
    globalThis.document = previous.document;
    globalThis.window = previous.window;
    globalThis.requestAnimationFrame = previous.requestAnimationFrame;
  }
});

test("taking a short break closes the reminder before requesting the host close flow", () => {
  class FakeElement {
    className = "";
    innerHTML = "";
    textContent = "";
    children: FakeElement[] = [];
    listeners = new Map<string, () => void>();
    removed = false;
    setAttribute() {}
    append(...items: FakeElement[]) { this.children.push(...items); }
    addEventListener(name: string, listener: () => void) { this.listeners.set(name, listener); }
    removeEventListener() {}
    remove() { this.removed = true; }
    focus() {}
  }
  const previous = { document: globalThis.document, HTMLElement: globalThis.HTMLElement };
  const body = new FakeElement();
  const documentStub = {
    activeElement: null,
    body,
    createElement: () => new FakeElement(),
    getElementById: () => null,
    addEventListener() {},
    removeEventListener() {},
  } as unknown as Document;
  const events: string[] = [];
  globalThis.document = documentStub;
  globalThis.HTMLElement = FakeElement as unknown as typeof HTMLElement;
  try {
    const backdrop = showHealthBreakReminder(4, () => events.push("closed"), () => events.push("take-break"));
    const dialog = backdrop.children[0];
    const actions = dialog.children[0];
    actions.children[0].listeners.get("click")!();
    assert.equal(backdrop.removed, true);
    assert.deepEqual(events, ["closed", "take-break"]);
    // Keep working only closes the reminder and returns the focus to the field that had it
    const field = Object.assign(new FakeElement(), { isConnected: true, focused: false, focus() { this.focused = true; } });
    (documentStub as unknown as { activeElement: unknown }).activeElement = field;
    events.length = 0;
    const second = showHealthBreakReminder(4, () => events.push("closed"), () => events.push("take-break"));
    second.children[0].children[0].children[1].listeners.get("click")!();
    assert.equal(second.removed, true);
    assert.deepEqual(events, ["closed"]);
    assert.equal(field.focused, true);
    // with no break action given, the break closes the window through its normal close flow
    let closedWindow = 0;
    const previousWindow = globalThis.window;
    globalThis.window = { close: () => { closedWindow++; } } as unknown as Window & typeof globalThis;
    try {
      showHealthBreakReminder(4).children[0].children[0].children[0].listeners.get("click")!();
      assert.equal(closedWindow, 1);
    } finally { globalThis.window = previousWindow; }
  } finally {
    globalThis.document = previous.document;
    globalThis.HTMLElement = previous.HTMLElement;
  }
});

test("active time across midnight is shared between the two local dates", () => {
  const start = new Date(2026, 10, 12, 23, 59, 0).getTime();
  assert.deepEqual(healthSecondsPerDate(start, start + 90_000), [{ date: "2026-11-12", seconds: 60 }, { date: "2026-11-13", seconds: 30 }]);
  assert.deepEqual(healthSecondsPerDate(start, start), []);
});

test("a tile's level is its share of a full day rounded up to a quarter, and 0 only for no time", () => {
  assert.equal(healthTileLevel(0, 21_600), 0);
  assert.equal(healthTileLevel(1, 21_600), 1);
  assert.equal(healthTileLevel(5_400, 21_600), 1);
  assert.equal(healthTileLevel(5_401, 21_600), 2);
  assert.equal(healthTileLevel(21_600, 21_600), 4);
  assert.equal(healthTileLevel(90_000, 21_600), 4);
});

test("the chart covers 364 days ending today, in daily, weekly and cumulative views", () => {
  const today = new Date(2026, 10, 13, 15, 0, 0);
  const days = healthChartDays([{ date: "2026-11-13", seconds: 7_200 }, { date: "2026-11-12", seconds: 3_600 }, { date: "2025-11-14", seconds: 600 }], today);
  assert.equal(days.length, 364);
  assert.equal(localDay(days[363].date), "2026-11-13");
  assert.equal(localDay(days[0].date), "2025-11-15", "the day before the first tile is outside the chart");
  const daily = healthChartTiles(days, "daily");
  assert.equal(daily.length, 364);
  assert.deepEqual([daily[363].level, daily[362].level, daily[361].level], [2, 1, 0]);
  const weekly = healthChartTiles(days, "weekly");
  assert.equal(weekly.length, 52);
  assert.equal(weekly[51].ownSeconds, 10_800, "the last week holds both recorded days");
  const cumulative = healthChartTiles(days, "cumulative");
  assert.equal(cumulative[363].seconds, 10_800);
  assert.equal(cumulative[363].level, 4, "the running total ends at the whole total");
  assert.equal(cumulative[363].ownSeconds, 7_200);
  assert.equal(healthMonthLabels(days, "en-GB").length, 52);
});

test("month names keep three weeks to themselves, dropping a crowded first or last month", () => {
  // 52 weeks from 2025-11-19: November has two weeks before December, and the last November two weeks before the end.
  const start = new Date(2025, 10, 19);
  const days = Array.from({ length: 364 }, (_, index) => ({ date: new Date(start.getFullYear(), start.getMonth(), start.getDate() + index) }));
  const labels = healthMonthLabels(days, "en-GB");
  const named = labels.filter(Boolean);
  assert.equal(named[0], "Dec", "the two-week November at the start is left unnamed");
  assert.equal(named.at(-1), "Oct", "the November of the last week is left unnamed");
  labels.forEach((label, week) => { if (label) assert.ok(labels.slice(week + 1, week + 3).every((next) => !next), `${label} has room`); });
});

test("adding time keeps the days in date order and merges a date's seconds", () => {
  assert.deepEqual(addHealthSeconds([{ date: "2026-01-03", seconds: 5 }, { date: "2026-01-01", seconds: 1 }], [{ date: "2026-01-03", seconds: 2 }, { date: "2026-01-02", seconds: 4 }]),
    [{ date: "2026-01-01", seconds: 1 }, { date: "2026-01-02", seconds: 4 }, { date: "2026-01-03", seconds: 7 }]);
});

function localDay(date: Date): string { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; }
