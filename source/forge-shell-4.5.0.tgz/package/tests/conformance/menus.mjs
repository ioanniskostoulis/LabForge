import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
// Source checks of the shell itself; applications bundle the .ts tests, which read no files.
test("the 14 px check column is reserved only in a menu that has a checkable item, and hidden otherwise", () => {
  const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");
  assert.match(css, /\.menu-popup\.has-checks > \.menu-item \{[^}]*grid-template-columns: 14px minmax\(0, 1fr\) auto;/);
  assert.match(css, /\.menu-popup:not\(\.has-checks\) > \.menu-item \.check \{ display: none; \}/);
  assert.match(css, /\.menu-popup \{[^}]*border-radius: 10px;/);
  assert.match(css, /#menubar\.title-bar \{[^}]*-webkit-app-region: drag;/);
});

test("Cmd+A in the Terminal selects the prompt's text in the prompt and the transcript elsewhere, never the >", () => {
  const source = readFileSync(new URL("../../source/app/terminal.ts", import.meta.url), "utf8");
  assert.ok(source.includes("if (!this.busy && document.activeElement === this.input) { this.input.select(); return; }"), "the prompt keeps select all to its own text, also when empty");
  assert.ok(source.includes('e.key.toLowerCase() === "a") {'));
  const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");
  assert.match(css, /\.selection-shape input::selection, \.selection-shape textarea::selection \{ background: var\(--selection\); \}/, "the prompt's selection is visible");
  assert.match(css, /\.console-echo-prompt, \.console-prompt-mark \{ -webkit-user-select: none; user-select: none; \}/, "the > is never highlighted");
  assert.ok(readFileSync(new URL("../../source/app/selection-shape.ts", import.meta.url), "utf8").includes('userSelect === "none") continue;'));
  assert.ok(source.includes("range.setStartBefore(this.banner);") && source.includes("range.setEndAfter(this.output);"));
});
