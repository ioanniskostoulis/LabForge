import assert from "node:assert/strict";
import { test } from "node:test";
import { COLOUR_MODEL_TIPS, formatColour, hexToRgb, hsbToRgb, keepHue, labToRgb, parseColour, rgbToHex, rgbToHsb, rgbToLab, type Rgb } from "../../source/app/colour-models";
import { convexHull, paintPicker, pickedColour, pickerGeometry, pickerKey, pickerRegion, ringHue, triangleColour, triangleCorners, trianglePoint, PICKER_SIZE_PX } from "../../source/app/colour-picker";
import { checkTipWording } from "../../source/app/tips";

const near = (actual: number, expected: number, within: number, what: string) => assert.ok(Math.abs(actual - expected) <= within, `${what}: ${actual} is not ${expected} ± ${within}`);
const nearRgb = (actual: Rgb | null, expected: Rgb, within: number, what: string) => {
  assert.ok(actual, `${what}: no colour`);
  near(actual.r, expected.r, within, `${what} r`); near(actual.g, expected.g, within, `${what} g`); near(actual.b, expected.b, within, `${what} b`);
};

test("HSB gives the primaries and secondaries at the hue's sector, and greys at saturation 0", () => {
  assert.deepEqual(hsbToRgb({ h: 0, s: 1, b: 1 }), { r: 255, g: 0, b: 0 });
  assert.deepEqual(hsbToRgb({ h: 60, s: 1, b: 1 }), { r: 255, g: 255, b: 0 });
  assert.deepEqual(hsbToRgb({ h: 120, s: 1, b: 1 }), { r: 0, g: 255, b: 0 });
  assert.deepEqual(hsbToRgb({ h: 240, s: 1, b: 1 }), { r: 0, g: 0, b: 255 });
  assert.deepEqual(hsbToRgb({ h: 200, s: 0, b: 0.5 }), { r: 127.5, g: 127.5, b: 127.5 }, "a grey whatever the hue");
  // #3a7bd5 by hand: max 213, min 58, c = 155; hue = 60 × ((58 − 123) / 155 + 4) = 214.8°, s = 155 / 213, b = 213 / 255
  const hsb = rgbToHsb({ r: 58, g: 123, b: 213 });
  near(hsb.h, 214.84, 0.01, "hue"); near(hsb.s, 0.7277, 0.0001, "saturation"); near(hsb.b, 0.8353, 0.0001, "brightness");
  for (const hex of ["#000000", "#ffffff", "#3a7bd5", "#ff8000", "#12ab9c", "#7f7f7f"]) assert.equal(rgbToHex(hsbToRgb(rgbToHsb(hexToRgb(hex)!))), hex, `${hex} round trip`);
});

test("hex is read in both lengths and any case, and anything else is refused", () => {
  assert.deepEqual(hexToRgb("#3A7BD5"), { r: 58, g: 123, b: 213 });
  assert.deepEqual(hexToRgb("fa0"), { r: 255, g: 170, b: 0 });
  for (const bad of ["#3a7bd", "#ggg", "3a7bd5ff", ""]) assert.equal(hexToRgb(bad), null, bad);
  assert.equal(rgbToHex({ r: 255.4, g: -3, b: 300 }), "#ff00ff", "rounded and kept in 0–255");
});

test("CIELAB under D65 matches the reference values, and reads back to the same sRGB", () => {
  const white = rgbToLab({ r: 255, g: 255, b: 255 });
  near(white.l, 100, 0.01, "white L"); near(white.a, 0, 0.01, "white a"); near(white.b, 0, 0.01, "white b");
  // sRGB red, by the CIE formulas: L 53.24, a 80.09, b 67.20
  const red = rgbToLab({ r: 255, g: 0, b: 0 });
  near(red.l, 53.24, 0.02, "red L"); near(red.a, 80.09, 0.02, "red a"); near(red.b, 67.2, 0.02, "red b");
  assert.deepEqual(rgbToLab({ r: 0, g: 0, b: 0 }), { l: 0, a: 0, b: 0 });
  // a dark grey lies below the CIELAB junction (6/29)³, on the straight part of the curve
  near(rgbToLab({ r: 2, g: 2, b: 2 }).l, 0.55, 0.01, "dark grey L");
  for (const rgb of [{ r: 58, g: 123, b: 213 }, { r: 255, g: 128, b: 0 }, { r: 2, g: 2, b: 2 }, { r: 18, g: 171, b: 156 }]) nearRgb(labToRgb(rgbToLab(rgb)), rgb, 0.01, `${rgbToHex(rgb)} round trip`);
  assert.equal(labToRgb({ l: 100, a: 0, b: 100 }), null, "a yellow brighter than sRGB can show is refused");
});

test("each model shows the colour as text that reads back to it, and its tip is a sentence", () => {
  const hsb = rgbToHsb({ r: 58, g: 123, b: 213 });
  assert.equal(formatColour("hex", hsb), "#3a7bd5");
  assert.equal(formatColour("rgb", hsb), "58, 123, 213");
  assert.equal(formatColour("hsb", hsb), "215°, 73 %, 84 %");
  // L 51.69, a 9.72, b −52.28 by the same formulas worked separately
  assert.equal(formatColour("lab", hsb), "51.7, 9.7, -52.3");
  for (const model of ["hex", "rgb", "lab"] as const) assert.equal(rgbToHex(hsbToRgb(parseColour(model, formatColour(model, hsb))!)), "#3a7bd5", `${model} reads back`);
  assert.equal(rgbToHex(hsbToRgb(parseColour("hsb", "214.84 72.77 83.53")!)), "#3a7bd5", "HSB reads back at full precision");
  for (const tip of Object.values(COLOUR_MODEL_TIPS)) assert.deepEqual(checkTipWording(tip), [], tip);
});

test("a typed colour is refused outside its model's range, and a grey keeps the hue it had", () => {
  assert.deepEqual(parseColour("rgb", "255 0 0"), { h: 0, s: 1, b: 1 });
  assert.deepEqual(parseColour("hsb", "400°, 50 %, 50 %"), { h: 40, s: 0.5, b: 0.5 }, "the hue wraps");
  assert.deepEqual(parseColour("hsb", "-30 50 50"), { h: 330, s: 0.5, b: 0.5 });
  for (const [model, text] of [["rgb", "256 0 0"], ["rgb", "1 2"], ["hsb", "0 101 50"], ["lab", "101 0 0"], ["lab", "100 0 100"], ["hex", "blue"]] as const) assert.equal(parseColour(model, text), null, `${model} ${text}`);
  const blue = { h: 215, s: 0.7, b: 0.8 };
  assert.deepEqual(parseColour("hex", "#808080", blue), { h: 215, s: 0, b: 128 / 255 }, "grey keeps the hue");
  assert.deepEqual(parseColour("hex", "#000", blue), { h: 215, s: 0.7, b: 0 }, "black keeps hue and saturation");
  assert.deepEqual(keepHue({ h: 10, s: 0.5, b: 0.5 }, blue), { h: 10, s: 0.5, b: 0.5 }, "a colour keeps its own hue");
  assert.equal(pickedColour({ h: 214.84, s: 0.7277, b: 0.8353 }).hex, "#3a7bd5");
});

const g = pickerGeometry(PICKER_SIZE_PX);

test("the ring is 18 px wide inside a 220 px picker, and the triangle's corners sit 5 px inside it", () => {
  assert.deepEqual(g, { cx: 110, cy: 110, outer: 109, inner: 91, corner: 86 });
  // the hue corner points at the hue: 0° to the right, 90° up
  const [hc0] = triangleCorners(0, g), [hc90] = triangleCorners(90, g);
  near(hc0.x, 196, 1e-9, "0° x"); near(hc0.y, 110, 1e-9, "0° y");
  near(hc90.x, 110, 1e-9, "90° x"); near(hc90.y, 24, 1e-9, "90° y");
  assert.equal(ringHue({ x: 210, y: 110 }, g), 0);
  near(ringHue({ x: 110, y: 10 }, g), 90, 1e-9, "up");
  near(ringHue({ x: 10, y: 110 }, g), 180, 1e-9, "left");
  near(ringHue({ x: 110, y: 210 }, g), 270, 1e-9, "down");
});

test("a press takes the ring from 2.5 px inside it, the triangle within that, and nothing past the circle", () => {
  const at = (r: number) => pickerRegion({ x: 110 + r, y: 110 }, g);
  assert.equal(at(0), "triangle");
  assert.equal(at(88.4), "triangle");
  assert.equal(at(88.5), "ring");
  assert.equal(at(111), "ring");
  assert.equal(at(111.1), null);
});

test("the triangle maps saturation and brightness to a point and back, and a point outside it takes the nearest edge", () => {
  const [hc, white, black] = triangleCorners(40, g);
  assert.deepEqual(trianglePoint({ h: 40, s: 1, b: 1 }, g), hc, "full colour at the hue corner");
  const w = trianglePoint({ h: 40, s: 0, b: 1 }, g), k = trianglePoint({ h: 40, s: 0.3, b: 0 }, g);
  near(w.x, white.x, 1e-9, "white x"); near(w.y, white.y, 1e-9, "white y");
  near(k.x, black.x, 1e-9, "black x"); near(k.y, black.y, 1e-9, "black y");
  for (const [s, b] of [[0.5, 0.5], [0.25, 0.9], [0.9, 0.1], [1, 0.6]]) {
    const back = triangleColour(trianglePoint({ h: 40, s, b }, g), 40, g);
    near(back.s, s, 1e-9, `s ${s}`); near(back.b, b, 1e-9, `b ${b}`);
  }
  const past = triangleColour({ x: hc.x + 10 * (hc.x - 84), y: hc.y + 10 * (hc.y - 84) }, 40, g);
  near(past.s, 1, 1e-9, "beyond the hue corner s"); near(past.b, 1, 1e-9, "beyond the hue corner b");
  assert.deepEqual(triangleColour(black, 40, g), { s: 0, b: 0 });
});

test("the hull of the samples keeps the outer points only", () => {
  const hull = convexHull([{ x: 0, y: 0 }, { x: 10, y: 0 }, { x: 10, y: 10 }, { x: 0, y: 10 }, { x: 5, y: 5 }, { x: 5, y: 0 }]);
  assert.equal(hull.length, 4);
  assert.ok(!hull.some((p) => p.x === 5), "the inner point and the point on an edge are left out");
  assert.deepEqual(convexHull([{ x: 1, y: 2 }]), [{ x: 1, y: 2 }]);
});

test("the painted picker is the hue on the ring, the corners' mix in the triangle, and clear outside the circle", () => {
  const pixels = { data: new Uint8ClampedArray(4 * 220 * 220), width: 220, height: 220 };
  paintPicker(pixels, g, 0, 1);
  const px = (x: number, y: number) => Array.from(pixels.data.slice(4 * (y * 220 + x), 4 * (y * 220 + x) + 4));
  // pixel (210, 110) has its centre at y 110.5, half a pixel below the axis: hue 359.7°, so blue is 1 and not 0
  assert.deepEqual(px(210, 110), [255, 0, 1, 255], "hue 0 to the right of the ring");
  assert.equal(px(0, 0)[3], 0, "the corner of the square is clear");
  assert.equal(px(110, 10)[3], 255, "the ring at the top is covered");
  // the centre weighs the three corners equally: red 255 / 3 + white 255 / 3 = 170, green and blue 85
  const [r, gr, b, a] = px(110, 110);
  near(r, 170, 3, "centre red"); near(gr, 85, 3, "centre green"); near(b, 85, 3, "centre blue"); assert.equal(a, 255);
  // between the triangle's corner and the ring there is a clear gap
  assert.equal(px(110 + 88, 110)[3], 0, "the gap in front of the hue corner");
});

test("arrow keys move saturation and brightness by 1 %, Page Up and Down the hue by 5°, and stop at the ends", () => {
  const c = { h: 358, s: 0.5, b: 1 };
  assert.deepEqual(pickerKey(c, "ArrowRight"), { h: 358, s: 0.51, b: 1 });
  assert.deepEqual(pickerKey(c, "ArrowLeft"), { h: 358, s: 0.49, b: 1 });
  assert.deepEqual(pickerKey(c, "ArrowUp"), { h: 358, s: 0.5, b: 1 }, "brightness stops at 100 %");
  assert.deepEqual(pickerKey(c, "ArrowDown"), { h: 358, s: 0.5, b: 0.99 });
  assert.deepEqual(pickerKey(c, "PageUp"), { h: 3, s: 0.5, b: 1 }, "the hue wraps past 360°");
  assert.deepEqual(pickerKey({ h: 2, s: 0, b: 0 }, "PageDown"), { h: 357, s: 0, b: 0 });
  assert.equal(pickerKey(c, "a"), null);
});
