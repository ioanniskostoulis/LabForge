import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const css = readFileSync(new URL("../../source/styles/shell.css", import.meta.url), "utf8");
const bottom = readFileSync(new URL("../../source/app/bottom-tabs.ts", import.meta.url), "utf8");
const rule = (selector) => css.match(new RegExp(`(?:^|\\n)${selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")} \\{([^}]*)\\}`))?.[1] ?? "";

test("the active line of the document tabs (top) and the bottom tabs (bottom) is a 2 px accent line that stays on its tab", () => {
  for (const [selector, edge] of [[".doc-tab-accent", "top"], [".tab-indicator", "bottom"]]) {
    const body = rule(selector);
    assert.match(body, new RegExp(`${edge}: 0`), `${selector} sits at the ${edge}`);
    assert.match(body, /height: 2px/);
    assert.match(body, /background: var\(--accent-light\)/);
  }
  // placed within the scrolled row, inside the tab's borders, so it stays on its tab
  assert.match(bottom, /bar\.scrollLeft \+ leftBorder/);
  assert.match(bottom, /tabRect\.width - leftBorder - rightBorder/);
});

test("a preview's focus ring is drawn above its content, so the content never covers it", () => {
  assert.match(rule(".preview-stage::after"), /z-index: 1/);
  assert.match(rule(".preview-stage::after"), /inset: 0/);
  assert.match(rule(".preview-stage:focus-visible::after"), /border-color: var\(--accent-light\)/);
});
