import assert from "node:assert/strict";
import { test } from "node:test";
import { DRAG_END_EVENTS, followPointer } from "../../source/app/pointer-drag";
import { WHEEL_STEP_PX, wheelSteps } from "../../source/app/wheel";

const moveEvent = (clientX: number) => Object.assign(new Event("pointermove"), { clientX });

test("a drag follows its moves and each way of ending it ends it exactly once", () => {
  for (const type of DRAG_END_EVENTS) {
    const target = new EventTarget();
    const moves: number[] = [];
    let ends = 0;
    assert.equal(followPointer(target, { button: 0, pointerId: 1 }, { move: (e) => moves.push(e.clientX), end: () => ends++ }), true);
    target.dispatchEvent(moveEvent(10));
    target.dispatchEvent(moveEvent(20));
    target.dispatchEvent(new Event(type));
    for (const other of DRAG_END_EVENTS) target.dispatchEvent(new Event(other));
    target.dispatchEvent(moveEvent(30));
    assert.deepEqual(moves, [10, 20], `moves after ${type} are not followed`);
    assert.equal(ends, 1, `${type} ends the drag once`);
  }
});

test("only the allowed buttons start a drag, and pointer capture is taken when there is one", () => {
  const captured: number[] = [];
  const target = Object.assign(new EventTarget(), { setPointerCapture: (id: number) => { captured.push(id); } });
  assert.equal(followPointer(target, { button: 2, pointerId: 7 }, {}), false, "a secondary press is not a drag");
  assert.equal(followPointer(target, { button: 1, pointerId: 8 }, {}), false);
  assert.equal(followPointer(target, { button: 1, pointerId: 9 }, {}, [0, 1]), true, "the middle button where it pans");
  assert.deepEqual(captured, [9]);
  const throwing = Object.assign(new EventTarget(), { setPointerCapture: () => { throw new Error("no active pointer"); } });
  assert.equal(followPointer(throwing, { button: 0, pointerId: 1 }, {}), true, "a pointer that cannot be captured is still followed");
});

test("wheel travel becomes whole steps, a fast turn passing several at once and the rest kept", () => {
  const steps: number[] = [];
  const listener = wheelSteps((n) => steps.push(n));
  const wheel = (deltaX: number, deltaY: number) => listener({ deltaX, deltaY, preventDefault() {} } as WheelEvent);
  wheel(0, -(WHEEL_STEP_PX - 1));
  assert.deepEqual(steps, [], "less than a step moves nothing");
  wheel(0, -1);
  wheel(0, -100);
  assert.deepEqual(steps, [1, 3], "up is positive, and 100 px is three steps at once");
  wheel(0, 10 + 2 * WHEEL_STEP_PX);
  assert.deepEqual(steps, [1, 3, -2], "the 10 px left over from the turn up is spent first");
  wheel(40, 5);
  assert.deepEqual(steps, [1, 3, -2, 1], "sideways travel counts when it is the larger");
});
