import assert from "node:assert/strict";
import { test } from "node:test";
import { SHEET_GRID_MIN_PITCH_PX, SHEET_GRID_TOKENS, drawSheetGrid, gridPositions, sheetGridFrom } from "../../source/app/sheet-grid";

// The values of tokens.css, as a computed style gives them (the test `the welcome grid's geometry is the tokens', ...` checks the file).
const style: Record<string, string> = {
  "--empty-sheet": "#131313", "--empty-grid-dot": "rgba(255, 255, 255, 0.08)", "--empty-grid-line": "rgba(255, 255, 255, 0.04)",
  "--empty-grid-origin": " 40px", "--empty-grid-dot-step": "16px", "--empty-grid-line-step": "128px", "--empty-grid-dot-radius": "1.1px", "--empty-grid-line-width": "1px",
};
const grid = sheetGridFrom((token) => style[token] ?? "");

test("a canvas reads the welcome grid from the same tokens as the CSS", () => {
  assert.deepEqual(grid, { sheet: "#131313", dot: "rgba(255, 255, 255, 0.08)", line: "rgba(255, 255, 255, 0.04)", originPx: 40, dotStepPx: 16, lineStepPx: 128, dotRadiusPx: 1.1, lineWidthPx: 1 });
  assert.deepEqual(Object.values(SHEET_GRID_TOKENS).sort(), Object.keys(style).sort());
  assert.throws(() => sheetGridFrom((token) => (token === "--empty-grid-origin" ? "" : style[token])), /needs --empty-grid-origin; load the shell's tokens\.css\./);
  assert.throws(() => sheetGridFrom((token) => (token === "--empty-grid-dot-step" ? "1rem" : style[token])), /--empty-grid-dot-step is 1rem, not a length in px\./);
});

test("grid positions are the origin plus whole steps, on both sides of the origin", () => {
  assert.deepEqual(gridPositions(40, 16, 0, 90), [8, 24, 40, 56, 72, 88]);
  assert.deepEqual(gridPositions(40, 128, 0, 300), [40, 168, 296]);
  assert.deepEqual(gridPositions(40, 128, 40, 168), [40], "from is included, to is not");
  assert.deepEqual(gridPositions(40, 128, 41, 168), []);
});

type Call = [string, ...number[]];
const recorder = () => {
  const calls: Call[] = [];
  const ctx = { fillStyle: "", save() {}, restore() {}, beginPath() {}, fill() { calls.push(["fill"]); },
    fillRect(...args: number[]) { calls.push([`rect ${ctx.fillStyle}`, ...args]); }, moveTo() {}, arc(x: number, y: number) { calls.push(["dot", x, y]); } };
  return { ctx: ctx as unknown as CanvasRenderingContext2D, calls };
};

test("at the default view the canvas sheet is the welcome screen: lines from 40 px every 128 px, dots on 40 px every 16 px", () => {
  const { ctx, calls } = recorder();
  drawSheetGrid(ctx, 200, 50, grid);
  assert.deepEqual(calls[0], ["rect #131313", 0, 0, 200, 50]);
  const lines = calls.filter((call) => call[0] === `rect ${grid.line}`);
  assert.deepEqual(lines, [[`rect ${grid.line}`, 40, 0, 1, 50], [`rect ${grid.line}`, 168, 0, 1, 50], [`rect ${grid.line}`, 0, 40, 200, 1]]);
  const dots = calls.filter((call) => call[0] === "dot");
  // The CSS dot tile starts at 40 − 16 / 2 = 32 px and centres its dot, so the dots fall on 8 + 16k, the lines on 40 + 128k.
  assert.deepEqual([...new Set(dots.map((call) => call[1]))], [8, 24, 40, 56, 72, 88, 104, 120, 136, 152, 168, 184, 200]);
  assert.deepEqual([...new Set(dots.map((call) => call[2]))], [8, 24, 40]);
});

test("with a view the grid follows the content, and a family too dense to read is left out", () => {
  const { ctx, calls } = recorder();
  drawSheetGrid(ctx, 300, 10, grid, { scale: 2, ox: -10, oy: 0 });
  // origin 40 × 2 − 10 = 70 px, step 128 × 2 = 256 px: one vertical line in 300 px, none across the 10 px height.
  assert.deepEqual(calls.filter((call) => call[0] === `rect ${grid.line}`), [[`rect ${grid.line}`, 70, 0, 1, 10]]);
  const sparse = recorder();
  const scale = (SHEET_GRID_MIN_PITCH_PX - 0.5) / grid.dotStepPx;
  drawSheetGrid(sparse.ctx, 100, 100, grid, { scale, ox: 0, oy: 0 });
  assert.equal(sparse.calls.filter((call) => call[0] === "dot").length, 0, `dots under ${SHEET_GRID_MIN_PITCH_PX} px apart are not drawn`);
  const edge = recorder();
  drawSheetGrid(edge.ctx, 100, 100, grid, { scale: SHEET_GRID_MIN_PITCH_PX / grid.dotStepPx, ox: 0, oy: 0 });
  assert.ok(edge.calls.some((call) => call[0] === "dot"), `dots exactly ${SHEET_GRID_MIN_PITCH_PX} px apart are drawn`);
});
