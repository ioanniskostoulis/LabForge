import assert from "node:assert/strict";
import test from "node:test";
import { createNativeMenuTemplate } from "../../source/desktop/native-menu";

test("native menus preserve commands and add the macOS app and Window menus", () => {
  const commands: string[] = [];
  const menu = createNativeMenuTemplate([
    { label: "File", submenu: [{ label: "New", id: "new", key: "CmdOrCtrl+N" }] },
    { label: "Help", submenu: [{ label: "Developer tools", role: "toggleDevTools" }] },
  ], { productName: "TestForge", isMac: true, isPackaged: true, onCommand: (id) => commands.push(id) });
  assert.deepEqual(menu.map((item) => item.label ?? item.role), ["TestForge", "File", "windowMenu", "Help"]);
  assert.deepEqual(menu[3].submenu, []);
  menu[0].submenu?.[0].click?.({}, {});
  menu[1].submenu?.[0].click?.({}, {});
  assert.deepEqual(commands, ["about", "new"]);
});

test("Settings… sits in the macOS app menu after About, and stays at the end of File where menus are drawn", () => {
  const nodes = [{ label: "File", submenu: [{ label: "New", id: "new" }, { label: "Close", id: "close" }, { separator: true, label: "" }, { label: "Settings…", id: "app.settings", key: "CmdOrCtrl+," }] }];
  const commands: string[] = [];
  const mac = createNativeMenuTemplate(nodes, { productName: "TestForge", isMac: true, isPackaged: true, onCommand: (id) => commands.push(id) });
  const app = mac[0].submenu!.map((item) => item.label ?? item.role ?? item.type);
  assert.deepEqual(app.slice(0, 4), ["About TestForge", "separator", "Settings…", "separator"]);
  assert.equal(mac[0].submenu![2].accelerator, "CmdOrCtrl+,");
  assert.deepEqual(mac.find((item) => item.label === "File")!.submenu!.map((item) => item.label ?? item.type), ["New", "Close"], "File keeps no trailing separator");
  mac[0].submenu![2].click?.({}, {});
  assert.deepEqual(commands, ["app.settings"]);
  const windows = createNativeMenuTemplate(nodes, { productName: "TestForge", isMac: false, isPackaged: true, onCommand: () => {} });
  assert.equal(windows[0].submenu!.at(-1)!.label, "Settings…");
});
