import assert from "node:assert/strict";
import { test } from "node:test";
import { grabbedEnd, inRange, moveRangeEnd, rangeSpans, rangeStep, snapToStep, stepDecimals, typedRangeEnd } from "../../source/app/range-slider";
import { editableTip } from "../../source/app/inspector-widgets";
import { checkTipWording } from "../../source/app/tips";

test("the default step is the power of ten below 1/100 of the span, shown with its decimals", () => {
  assert.equal(rangeStep(0, 255), 1);
  assert.equal(rangeStep(0, 360), 1);
  assert.equal(rangeStep(0, 100), 1, "exactly 100 steps");
  assert.equal(rangeStep(0, 99), 0.1, "just under 100 steps");
  assert.equal(rangeStep(0, 1), 0.01);
  assert.deepEqual([1, 0.01, 0.5, 10].map(stepDecimals), [0, 2, 1, 0]);
  assert.equal(snapToStep(0.123, 0, 1, 0.01), 0.12);
  assert.equal(snapToStep(0.125000001, 0, 1, 0.01), 0.13);
  assert.equal(snapToStep(254.6, 0, 255, 1), 255);
  assert.equal(snapToStep(300, 0, 255, 1), 255, "kept inside the track");
});

test("without wrap an end stops at the other end; with wrap it passes it", () => {
  assert.deepEqual(moveRangeEnd([20, 80], 0, 90, 0, 255), [80, 80], "low stops at high");
  assert.deepEqual(moveRangeEnd([20, 80], 1, 10, 0, 255), [20, 20], "high stops at low");
  assert.deepEqual(moveRangeEnd([20, 80], 0, -5, 0, 255), [0, 80], "kept inside the track");
  assert.deepEqual(moveRangeEnd([20, 80], 0, 90, 0, 360, true), [90, 80], "with wrap low passes high");
  assert.deepEqual(moveRangeEnd([20, 80], 1, 400, 0, 360, true), [20, 360]);
});

test("a press takes the nearer end, and the first movement chooses when both are as near", () => {
  assert.equal(grabbedEnd([20, 80], 30, 30), 0);
  assert.equal(grabbedEnd([20, 80], 70, 70), 1);
  assert.equal(grabbedEnd([20, 80], 50, 40), 0, "halfway, moving down: the low end");
  assert.equal(grabbedEnd([20, 80], 50, 60), 1, "halfway, moving up: the high end");
  assert.equal(grabbedEnd([50, 50], 50, 49), 0, "ends that meet come apart either way");
  assert.equal(grabbedEnd([50, 50], 50, 51), 1);
});

test("a wrapped range holds the values from its low end up and from its high end down, and fills both spans", () => {
  assert.equal(inRange(50, [20, 80]), true);
  assert.equal(inRange(20, [20, 80]), true, "the ends are inside");
  assert.equal(inRange(19.9, [20, 80]), false);
  assert.equal(inRange(330, [300, 60]), true);
  assert.equal(inRange(30, [300, 60]), true);
  assert.equal(inRange(180, [300, 60]), false);
  assert.deepEqual(rangeSpans([90, 270], 0, 360), [[0.25, 0.75]]);
  assert.deepEqual(rangeSpans([270, 90], 0, 360), [[0.75, 1], [0, 0.25]]);
});

test("a typed end is a number inside the track that does not pass the other end, unless the range wraps", () => {
  assert.equal(typedRangeEnd("40", [20, 80], 0, 0, 255), 40);
  assert.equal(typedRangeEnd("80", [20, 80], 0, 0, 255), 80, "the ends may meet");
  assert.equal(typedRangeEnd("81", [20, 80], 0, 0, 255), null);
  assert.equal(typedRangeEnd("19", [20, 80], 1, 0, 255), null);
  assert.equal(typedRangeEnd("256", [20, 80], 1, 0, 255), null);
  assert.equal(typedRangeEnd("abc", [20, 80], 1, 0, 255), null);
  assert.equal(typedRangeEnd("−5", [-10, 10], 0, -20, 20), -5, "a typographic minus");
  assert.equal(typedRangeEnd("300", [20, 80], 0, 0, 360, true), 300);
  const tip = editableTip("Enter the low end, from 0 to 255");
  assert.equal(tip, "Enter the low end, from 0 to 255.");
  assert.deepEqual(checkTipWording(tip), []);
});
