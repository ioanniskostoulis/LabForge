// The behaviour of the inspector parts. Their stylesheet rules are checked in inspector-styles.mjs, since a portable test
// (one an application bundles and runs) reads no files.
import assert from "node:assert/strict";
import { test } from "node:test";
import { createButton, createButtonGroup, createInfoLines } from "../../source/app/builders";
import { TREE_STATUS, treeBadges, type TreeFile } from "../../source/app/file-tree";
import { createViewHeader } from "../../source/app/view-header";
import { UI_ICONS } from "../../source/app/tool-icons";

class Element {
  className = ""; textContent = ""; type = ""; disabled = false; children: Element[] = []; attributes: Record<string, string> = {}; dataset: Record<string, string> = {};
  append(...items: Element[]) { this.children.push(...items); }
  replaceChildren(...items: Element[]) { this.children = items; }
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
  addEventListener() {}
}
const doc = { createElement: () => new Element() } as unknown as Pick<Document, "createElement">;

test("every file in the tree shows its status, editable or read-only or the app's own, and folders show none", () => {
  const host = { status: (file: TreeFile) => (file.path === "main.tex" ? "editable" as const : file.path.endsWith(".csv") ? { icon: UI_ICONS.lock, label: "Linked data file." } : "readOnly" as const) };
  assert.deepEqual(treeBadges(host, { path: "main.tex", kind: "tex" }), [TREE_STATUS.editable]);
  assert.deepEqual(treeBadges(host, { path: "figures/plot.png", kind: "image" }), [TREE_STATUS.readOnly]);
  assert.deepEqual(treeBadges(host, { path: "data/run.csv", kind: "data" }), [{ icon: UI_ICONS.lock, label: "Linked data file." }]);
  assert.deepEqual(treeBadges(host, { path: "figures", kind: "folder" }), [], "a folder has no status");
  assert.deepEqual(treeBadges(host, undefined), [], "nor does a folder made from a file's path");
  assert.deepEqual(TREE_STATUS, { editable: { icon: UI_ICONS.edit, label: "Editable file." }, readOnly: { icon: UI_ICONS.readOnly, label: "Read-only file." } });
  const both = { status: () => "readOnly" as const, badges: () => [{ icon: UI_ICONS.link, label: "Linked." }] };
  assert.deepEqual(treeBadges(both, { path: "a.txt", kind: "text" }).map((badge) => badge.label), ["Read-only file.", "Linked."], "the status comes first");
  assert.deepEqual(treeBadges({}, { path: "a.txt", kind: "text" }), [], "an app without statuses shows none");
});

test("info lines show the item's name, then its values, and the empty sentence when there is no item", () => {
  const info = createInfoLines("Hover or click a part.", doc);
  const shown = () => (info.element as unknown as Element).children.map((child) => [child.className, child.textContent]);
  assert.equal((info.element as unknown as Element).className, "info-lines");
  assert.deepEqual(shown(), [["muted", "Hover or click a part."]]);
  info.show(["R1", "I = 1.2 mA", "V = 3.3 V"]);
  assert.deepEqual(shown(), [["first", "R1"], ["", "I = 1.2 mA"], ["", "V = 3.3 V"]]);
  info.show([]);
  assert.deepEqual(shown(), [["muted", "Hover or click a part."]], "no lines is no item");
});

test("a button group holds its buttons in order, each primary or ordinary and enabled or disabled as given", () => {
  const group = createButtonGroup([createButton({ label: "Run", primary: true }, doc), createButton({ label: "Open PDF", disabled: true }, doc)], doc) as unknown as Element;
  assert.equal(group.className, "buttons");
  assert.deepEqual(group.children.map((button) => [button.textContent, button.className, button.disabled]), [["Run", "panel-button primary", false], ["Open PDF", "panel-button", true]]);
});

test("a file's status is shown in the tree only: a view header carries no editable or read-only icon", () => {
  class Node extends Element { innerHTML = ""; title = ""; }
  const saved = (globalThis as { document?: unknown }).document;
  (globalThis as { document?: unknown }).document = { createElement: () => new Node() };
  try {
    const kinds = (header: Element) => header.children.map((child) => child.className);
    const header = createViewHeader({ title: "main.tex", dirty: true, mode: "readOnly", onClose() {} }) as unknown as Element;
    assert.deepEqual(kinds(header), ["view-dirty on", "view-title", "view-space", "view-action view-close"], "the deprecated mode adds nothing");
    assert.ok(header.children.every((child) => !(child as Node).innerHTML.includes(UI_ICONS.edit) && !(child as Node).innerHTML.includes(UI_ICONS.readOnly)));
  } finally {
    (globalThis as { document?: unknown }).document = saved;
  }
});
