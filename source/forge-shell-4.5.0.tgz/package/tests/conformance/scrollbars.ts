import assert from "node:assert/strict";
import { test } from "node:test";
import { SCROLLBAR_MIN_LENGTH_PX, thumbGeometry } from "../../source/app/scrollbars";

test("a thumb is the view's share of the content and meets both ends of its track", () => {
  assert.deepEqual(thumbGeometry(1000, 500, 2000, 0), { lengthPx: 250, offsetPx: 0 });
  assert.deepEqual(thumbGeometry(1000, 500, 2000, 750), { lengthPx: 250, offsetPx: 375 });
  assert.deepEqual(thumbGeometry(1000, 500, 2000, 1500), { lengthPx: 250, offsetPx: 750 });
});

test("a long document holds the thumb at 24 px, and a whole-track thumb is not longer than the track", () => {
  assert.equal(thumbGeometry(200, 100, 5000, 0)?.lengthPx, SCROLLBAR_MIN_LENGTH_PX);
  assert.equal(thumbGeometry(10, 5000, 9000, 0)?.lengthPx, 10);
});

test("the thumb stays in its track when the scroll overshoots, and content that fits draws no bar", () => {
  assert.equal(thumbGeometry(1000, 500, 2000, -40)?.offsetPx, 0);
  assert.equal(thumbGeometry(1000, 500, 2000, 9999)?.offsetPx, 750);
  assert.equal(thumbGeometry(1000, 500, 500, 0), null);
  assert.equal(thumbGeometry(1000, 500, 400, 0), null);
  assert.equal(thumbGeometry(0, 500, 2000, 0), null);
});
