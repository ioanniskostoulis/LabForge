// Licensed under the GNU General Public License v2 or later. See LICENSE.
// Start a new application of the family: a complete empty app from a name, a file extension and one accent colour.
// The app has the shell's frame (menus, tool strip, panels, Terminal, Messages, status bar, welcome screen), the
// desktop main process and preload, its ASCII wordmark, a placeholder icon, the build, check and release scripts and
// the four workflows. It type-checks, builds and passes the shell check as generated.
import { spawnSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { fileURLToPath } from "node:url";
import { deflateSync } from "node:zlib";
import { deriveAccents, resolveTheme } from "./theme.mjs";
import { writeWordmark } from "./wordmark.mjs";
import { writeWorkflows } from "./workflows.mjs";

const shellRoot = fileURLToPath(new URL("..", import.meta.url));
const templateRoot = join(shellRoot, "templates", "new-app");

/** The checked inputs of a new app, with their defaults filled in. */
export function newAppOptions({ name, extension, accent = "#3fae6a", purpose, author = "", port, shellDependency, repository } = {}) {
  if (!/^[A-Z][A-Za-z0-9]*$/.test(name ?? "")) throw new Error(`An application name is one word starting with a capital letter, such as Example, not "${name ?? ""}".`);
  const id = name.toLowerCase();
  const ext = (extension ?? `${id[0]}fg`).replace(/^\./, "").toLowerCase();
  if (!/^[a-z]fg$/.test(ext)) throw new Error(`A project file's extension is one letter and fg, such as ${id[0]}fg, not "${extension}".`);
  const chosenPort = port === undefined ? 4100 + ([...id].reduce((sum, letter) => sum + letter.charCodeAt(0), 0) % 800) : Number(port);
  if (!Number.isInteger(chosenPort) || chosenPort < 1024 || chosenPort > 65535) throw new Error(`A port is a whole number from 1024 to 65535, not "${port}".`);
  if (repository !== undefined && !/^[A-Za-z0-9-]+\/[A-Za-z0-9._-]+$/.test(repository)) throw new Error(`A repository is named as owner/name, such as owner/example, not "${repository}".`);
  const version = readFileSync(join(shellRoot, "VERSION"), "utf8").trim();
  return {
    name, id, extension: ext, accent: accent.toLowerCase(), purpose: purpose ?? `${name} workspace`, author, port: chosenPort, repository,
    shellDependency: shellDependency ?? `file:source/forge-shell-${version}.tgz`,
  };
}

/** The application profile (forge.config.json) of a new app. */
export function newAppConfig(options) {
  const { name, id, extension, purpose, author, port, repository } = options;
  const year = new Date().getFullYear();
  return {
    identity: { name, id, purpose, wordmarkPath: "logo.txt", versionSource: "VERSION", port, ...(repository ? { repository } : {}) },
    document: {
      noun: "document", plural: "documents", extension, containsMultipleFiles: false,
      welcome: { title: "No document open", newLabel: "New document", openLabel: "Open…", detail: `Create or open a .${extension} document` },
      tabs: { noun: "document", newTitle: "New document", closeTitle: "Close document" },
    },
    // Both appearances are written out, so the profile shows every accent the app uses.
    theme: resolveTheme(deriveAccents(options.accent)),
    html: { center: "public/center.html", panes: "public/panes.html" },
    desktop: {
      appId: `com.${id}.app`,
      copyright: `Copyright © ${author ? `${year} ${author}` : year}. GPL-2.0-or-later.`,
      appIcon: "assets/icon.png",
      macCategory: "public.app-category.productivity",
      document: {
        name: `${name} document`, description: `${name} document`, iconStem: extension, iconSource: "assets/icon.png",
        iconLabel: extension.toUpperCase(), iconInk: options.accent, role: "Editor",
        typeIdentifier: `com.${id}.document`, conformsTo: ["public.data"], mimeType: `application/vnd.${id}.document`,
      },
    },
  };
}

/** Replace the placeholders of a template file. */
export function fillTemplate(text, options) {
  return text
    .replaceAll("__NAME__", options.name).replaceAll("__ID__", options.id).replaceAll("__EXT__", options.extension)
    .replaceAll("__PURPOSE__", options.purpose).replaceAll("__AUTHOR__", options.author).replaceAll("__PORT__", String(options.port))
    .replaceAll("__SHELL_DEP__", options.shellDependency);
}

/** A square PNG of `size` px in one colour: the placeholder app icon, until the app has its own. */
export function solidPng(colour, size = 1024) {
  const [r, g, b] = [1, 3, 5].map((start) => parseInt(colour.slice(start, start + 2), 16));
  const crcTable = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (bytes) => { let c = 0xffffffff; for (const byte of bytes) c = crcTable[(c ^ byte) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => {
    const out = Buffer.alloc(12 + data.length);
    out.writeUInt32BE(data.length, 0);
    out.write(type, 4, "ascii");
    data.copy(out, 8);
    out.writeUInt32BE(crc(out.subarray(4, 8 + data.length)), 8 + data.length);
    return out;
  };
  const header = Buffer.alloc(13);
  header.writeUInt32BE(size, 0); header.writeUInt32BE(size, 4);
  header[8] = 8; header[9] = 2; // 8-bit RGB
  const row = Buffer.alloc(1 + size * 3);
  for (let x = 0; x < size; x++) { row[1 + x * 3] = r; row[2 + x * 3] = g; row[3 + x * 3] = b; }
  const pixels = Buffer.concat(Array.from({ length: size }, () => row));
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk("IHDR", header), chunk("IDAT", deflateSync(pixels)), chunk("IEND", Buffer.alloc(0))]);
}

function templateFiles(dir = templateRoot) {
  return readdirSync(dir).flatMap((entry) => {
    const path = join(dir, entry);
    return statSync(path).isDirectory() ? templateFiles(path) : [relative(templateRoot, path)];
  });
}

/**
 * Write a new app into `target`, which must not exist or be empty. Returns the files written, relative to `target`.
 * Installing the packages and the shell archive is left to the developer (see the app's documentation/DEVELOPMENT.md).
 * The document icons in assets/icon are made when Python 3 with Pillow is installed; otherwise `missingIcons(target)` is true.
 */
export function createNewApp(target, input) {
  const options = newAppOptions(input);
  if (existsSync(target) && readdirSync(target).length) throw new Error(`${target} is not empty. Choose a new folder.`);
  const written = [];
  const write = (file, contents) => {
    const path = join(target, file);
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, contents);
    written.push(file);
  };
  for (const file of templateFiles()) {
    // npm drops files named .gitignore from packages, so the template keeps it as gitignore.
    const name = file === "gitignore" ? ".gitignore" : file;
    write(name, fillTemplate(readFileSync(join(templateRoot, file), "utf8"), options));
  }
  write("forge.config.json", `${JSON.stringify(newAppConfig(options), null, 2)}\n`);
  write("assets/icon.png", solidPng(options.accent));
  copyFileSync(join(shellRoot, "LICENSE"), join(target, "LICENSE"));
  written.push("LICENSE");
  writeWordmark(options.name, join(target, "assets", "logo.txt"));
  written.push("assets/logo.txt");
  written.push(...writeWorkflows(join(target, ".github", "workflows")).map((file) => `.github/workflows/${file}`));
  // The document icons, which packaging needs; made by the shell's file-icon.py when Python 3 with Pillow is present.
  const icons = spawnSync("python3", [join(shellRoot, "scripts", "file-icon.py")], { cwd: target, encoding: "utf8" });
  if (icons.status === 0) written.push(...["png", "icns", "ico"].map((kind) => `assets/icon/${options.extension}.${kind}`).filter((file) => existsSync(join(target, file))));
  return written.sort();
}

/** Whether a new app still lacks its document icons, which `npm run dist` needs. */
export function missingIcons(target) {
  const config = JSON.parse(readFileSync(join(target, "forge.config.json"), "utf8"));
  return !existsSync(join(target, "assets", "icon", `${config.desktop.document.iconStem}.icns`));
}
